
package cz.czechpoint.isds.v20;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for tAddDBUserInput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tAddDBUserInput"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="dbOwnerInfo" type="{http://isds.czechpoint.cz/v20}tDbOwnerInfoExt"/&gt;
 *         &lt;element name="dbUserInfo"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;extension base="{http://isds.czechpoint.cz/v20}tDbUserInfoExt"&gt;
 *                 &lt;attribute name="AIFOTicket" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="dbVirtual" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="email" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;group ref="{http://isds.czechpoint.cz/v20}gExtApproval"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tAddDBUserInput", propOrder = {
    "dbOwnerInfo",
    "dbUserInfo",
    "dbVirtual",
    "email",
    "dbApproved",
    "dbExternRefNumber"
})
public class TAddDBUserInput {

    @XmlElement(required = true)
    protected TDbOwnerInfoExt dbOwnerInfo;
    @XmlElement(required = true)
    protected TAddDBUserInput.DbUserInfo dbUserInfo;
    protected Boolean dbVirtual;
    @XmlElement(nillable = true)
    protected String email;
    @XmlElement(nillable = true)
    protected Boolean dbApproved;
    @XmlElement(nillable = true)
    protected String dbExternRefNumber;

    /**
     * Gets the value of the dbOwnerInfo property.
     * 
     * @return
     *     possible object is
     *     {@link TDbOwnerInfoExt }
     *     
     */
    public TDbOwnerInfoExt getDbOwnerInfo() {
        return dbOwnerInfo;
    }

    /**
     * Sets the value of the dbOwnerInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link TDbOwnerInfoExt }
     *     
     */
    public void setDbOwnerInfo(TDbOwnerInfoExt value) {
        this.dbOwnerInfo = value;
    }

    /**
     * Gets the value of the dbUserInfo property.
     * 
     * @return
     *     possible object is
     *     {@link TAddDBUserInput.DbUserInfo }
     *     
     */
    public TAddDBUserInput.DbUserInfo getDbUserInfo() {
        return dbUserInfo;
    }

    /**
     * Sets the value of the dbUserInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link TAddDBUserInput.DbUserInfo }
     *     
     */
    public void setDbUserInfo(TAddDBUserInput.DbUserInfo value) {
        this.dbUserInfo = value;
    }

    /**
     * Gets the value of the dbVirtual property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDbVirtual() {
        return dbVirtual;
    }

    /**
     * Sets the value of the dbVirtual property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDbVirtual(Boolean value) {
        this.dbVirtual = value;
    }

    /**
     * Gets the value of the email property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the value of the email property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmail(String value) {
        this.email = value;
    }

    /**
     * Gets the value of the dbApproved property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDbApproved() {
        return dbApproved;
    }

    /**
     * Sets the value of the dbApproved property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDbApproved(Boolean value) {
        this.dbApproved = value;
    }

    /**
     * Gets the value of the dbExternRefNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbExternRefNumber() {
        return dbExternRefNumber;
    }

    /**
     * Sets the value of the dbExternRefNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbExternRefNumber(String value) {
        this.dbExternRefNumber = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;extension base="{http://isds.czechpoint.cz/v20}tDbUserInfoExt"&gt;
     *       &lt;attribute name="AIFOTicket" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class DbUserInfo
        extends TDbUserInfoExt
    {

        @XmlAttribute(name = "AIFOTicket")
        protected String aifoTicket;

        /**
         * Gets the value of the aifoTicket property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getAIFOTicket() {
            return aifoTicket;
        }

        /**
         * Sets the value of the aifoTicket property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setAIFOTicket(String value) {
            this.aifoTicket = value;
        }

    }

}
