
package cz.czechpoint.isds.v20;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for tISDSSearchInput3 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tISDSSearchInput3"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="searchText" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="searchType"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="GENERAL"/&gt;
 *               &lt;enumeration value="ADDRESS"/&gt;
 *               &lt;enumeration value="ICO"/&gt;
 *               &lt;enumeration value="IDOVM"/&gt;
 *               &lt;enumeration value="DBID"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="searchScope"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="ALL"/&gt;
 *               &lt;enumeration value="OVM"/&gt;
 *               &lt;enumeration value="OVM_MAIN"/&gt;
 *               &lt;enumeration value="OVM_REQ"/&gt;
 *               &lt;enumeration value="OVM_NOTAR"/&gt;
 *               &lt;enumeration value="OVM_EXEKUT"/&gt;
 *               &lt;enumeration value="OVM_FO"/&gt;
 *               &lt;enumeration value="OVM_PFO"/&gt;
 *               &lt;enumeration value="OVM_PO"/&gt;
 *               &lt;enumeration value="PO"/&gt;
 *               &lt;enumeration value="PO_ZAK"/&gt;
 *               &lt;enumeration value="PO_REQ"/&gt;
 *               &lt;enumeration value="PFO"/&gt;
 *               &lt;enumeration value="PFO_ADVOK"/&gt;
 *               &lt;enumeration value="PFO_INSSPR"/&gt;
 *               &lt;enumeration value="PFO_DANPOR"/&gt;
 *               &lt;enumeration value="PFO_AUDITOR"/&gt;
 *               &lt;enumeration value="FO"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="page" type="{http://www.w3.org/2001/XMLSchema}integer"/&gt;
 *         &lt;element name="pageSize" type="{http://www.w3.org/2001/XMLSchema}integer"/&gt;
 *         &lt;element name="highlighting" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tISDSSearchInput3", propOrder = {
    "searchText",
    "searchType",
    "searchScope",
    "page",
    "pageSize",
    "highlighting"
})
public class TISDSSearchInput3 {

    @XmlElement(required = true)
    protected String searchText;
    @XmlElement(required = true, nillable = true)
    protected String searchType;
    @XmlElement(required = true, nillable = true)
    protected String searchScope;
    @XmlElement(required = true, nillable = true)
    protected BigInteger page;
    @XmlElement(required = true, nillable = true)
    protected BigInteger pageSize;
    @XmlElement(nillable = true)
    protected Boolean highlighting;

    /**
     * Gets the value of the searchText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSearchText() {
        return searchText;
    }

    /**
     * Sets the value of the searchText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSearchText(String value) {
        this.searchText = value;
    }

    /**
     * Gets the value of the searchType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSearchType() {
        return searchType;
    }

    /**
     * Sets the value of the searchType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSearchType(String value) {
        this.searchType = value;
    }

    /**
     * Gets the value of the searchScope property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSearchScope() {
        return searchScope;
    }

    /**
     * Sets the value of the searchScope property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSearchScope(String value) {
        this.searchScope = value;
    }

    /**
     * Gets the value of the page property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getPage() {
        return page;
    }

    /**
     * Sets the value of the page property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setPage(BigInteger value) {
        this.page = value;
    }

    /**
     * Gets the value of the pageSize property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getPageSize() {
        return pageSize;
    }

    /**
     * Sets the value of the pageSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setPageSize(BigInteger value) {
        this.pageSize = value;
    }

    /**
     * Gets the value of the highlighting property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isHighlighting() {
        return highlighting;
    }

    /**
     * Sets the value of the highlighting property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setHighlighting(Boolean value) {
        this.highlighting = value;
    }

}
