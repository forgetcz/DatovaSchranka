
package cz.czechpoint.isds.v20;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for tDbUsersArray complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tDbUsersArray"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence maxOccurs="unbounded" minOccurs="0"&gt;
 *         &lt;element name="dbUserInfo"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;extension base="{http://isds.czechpoint.cz/v20}tDbUserInfoExt"&gt;
 *                 &lt;attribute name="AIFOTicket" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *               &lt;/extension&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tDbUsersArray", propOrder = {
    "dbUserInfo"
})
public class TDbUsersArray {

    protected List<TDbUsersArray.DbUserInfo> dbUserInfo;

    /**
     * Gets the value of the dbUserInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the dbUserInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDbUserInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TDbUsersArray.DbUserInfo }
     * 
     * 
     */
    public List<TDbUsersArray.DbUserInfo> getDbUserInfo() {
        if (dbUserInfo == null) {
            dbUserInfo = new ArrayList<TDbUsersArray.DbUserInfo>();
        }
        return this.dbUserInfo;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;extension base="{http://isds.czechpoint.cz/v20}tDbUserInfoExt"&gt;
     *       &lt;attribute name="AIFOTicket" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
     *     &lt;/extension&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class DbUserInfo
        extends TDbUserInfoExt
    {

        @XmlAttribute(name = "AIFOTicket")
        protected String aifoTicket;

        /**
         * Gets the value of the aifoTicket property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getAIFOTicket() {
            return aifoTicket;
        }

        /**
         * Sets the value of the aifoTicket property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setAIFOTicket(String value) {
            this.aifoTicket = value;
        }

    }

}
