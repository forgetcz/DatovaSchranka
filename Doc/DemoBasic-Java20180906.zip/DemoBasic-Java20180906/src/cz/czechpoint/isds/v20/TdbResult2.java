
package cz.czechpoint.isds.v20;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for tdbResult2 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tdbResult2"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="dbID" type="{http://isds.czechpoint.cz/v20}tIdDb"/&gt;
 *         &lt;element name="dbType" type="{http://isds.czechpoint.cz/v20}tDbType"/&gt;
 *         &lt;element name="dbName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="dbAddress" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="dbBiDate" type="{http://www.w3.org/2001/XMLSchema}date"/&gt;
 *         &lt;element name="dbICO" type="{http://isds.czechpoint.cz/v20}tIdentificationNumber"/&gt;
 *         &lt;element name="dbIdOVM" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="dbSendOptions"&gt;
 *           &lt;simpleType&gt;
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *               &lt;enumeration value="DZ"/&gt;
 *               &lt;enumeration value="ALL"/&gt;
 *               &lt;enumeration value="PDZ"/&gt;
 *               &lt;enumeration value="NONE"/&gt;
 *               &lt;enumeration value="DISABLED"/&gt;
 *             &lt;/restriction&gt;
 *           &lt;/simpleType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tdbResult2", propOrder = {
    "dbID",
    "dbType",
    "dbName",
    "dbAddress",
    "dbBiDate",
    "dbICO",
    "dbIdOVM",
    "dbSendOptions"
})
public class TdbResult2 {

    @XmlElement(required = true)
    protected String dbID;
    @XmlElement(required = true)
    @XmlSchemaType(name = "string")
    protected TDbType dbType;
    @XmlElement(required = true)
    protected String dbName;
    @XmlElement(required = true)
    protected String dbAddress;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dbBiDate;
    @XmlElement(required = true, nillable = true)
    protected String dbICO;
    @XmlElement(required = true, nillable = true)
    protected String dbIdOVM;
    @XmlElement(required = true)
    protected String dbSendOptions;

    /**
     * Gets the value of the dbID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbID() {
        return dbID;
    }

    /**
     * Sets the value of the dbID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbID(String value) {
        this.dbID = value;
    }

    /**
     * Gets the value of the dbType property.
     * 
     * @return
     *     possible object is
     *     {@link TDbType }
     *     
     */
    public TDbType getDbType() {
        return dbType;
    }

    /**
     * Sets the value of the dbType property.
     * 
     * @param value
     *     allowed object is
     *     {@link TDbType }
     *     
     */
    public void setDbType(TDbType value) {
        this.dbType = value;
    }

    /**
     * Gets the value of the dbName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbName() {
        return dbName;
    }

    /**
     * Sets the value of the dbName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbName(String value) {
        this.dbName = value;
    }

    /**
     * Gets the value of the dbAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbAddress() {
        return dbAddress;
    }

    /**
     * Sets the value of the dbAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbAddress(String value) {
        this.dbAddress = value;
    }

    /**
     * Gets the value of the dbBiDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDbBiDate() {
        return dbBiDate;
    }

    /**
     * Sets the value of the dbBiDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDbBiDate(XMLGregorianCalendar value) {
        this.dbBiDate = value;
    }

    /**
     * Gets the value of the dbICO property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbICO() {
        return dbICO;
    }

    /**
     * Sets the value of the dbICO property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbICO(String value) {
        this.dbICO = value;
    }

    /**
     * Gets the value of the dbIdOVM property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbIdOVM() {
        return dbIdOVM;
    }

    /**
     * Sets the value of the dbIdOVM property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbIdOVM(String value) {
        this.dbIdOVM = value;
    }

    /**
     * Gets the value of the dbSendOptions property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbSendOptions() {
        return dbSendOptions;
    }

    /**
     * Sets the value of the dbSendOptions property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbSendOptions(String value) {
        this.dbSendOptions = value;
    }

}
