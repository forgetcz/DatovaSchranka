
package cz.czechpoint.isds.v20;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for tDTInfoOutput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tDTInfoOutput"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ActDTType" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" minOccurs="0"/&gt;
 *         &lt;element name="ActDTCapacity" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" minOccurs="0"/&gt;
 *         &lt;element name="ActDTFrom" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="ActDTTo" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="ActDTCapUsed" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" minOccurs="0"/&gt;
 *         &lt;element name="FutDTType" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" minOccurs="0"/&gt;
 *         &lt;element name="FutDTCapacity" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" minOccurs="0"/&gt;
 *         &lt;element name="FutDTFrom" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="FutDTTo" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/&gt;
 *         &lt;element name="FutDTPaid" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" minOccurs="0"/&gt;
 *         &lt;element name="dbStatus" type="{http://isds.czechpoint.cz/v20}tDbReqStatus"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tDTInfoOutput", propOrder = {
    "actDTType",
    "actDTCapacity",
    "actDTFrom",
    "actDTTo",
    "actDTCapUsed",
    "futDTType",
    "futDTCapacity",
    "futDTFrom",
    "futDTTo",
    "futDTPaid",
    "dbStatus"
})
public class TDTInfoOutput {

    @XmlElement(name = "ActDTType")
    @XmlSchemaType(name = "nonNegativeInteger")
    protected BigInteger actDTType;
    @XmlElement(name = "ActDTCapacity", nillable = true)
    @XmlSchemaType(name = "nonNegativeInteger")
    protected BigInteger actDTCapacity;
    @XmlElement(name = "ActDTFrom", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar actDTFrom;
    @XmlElement(name = "ActDTTo", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar actDTTo;
    @XmlElement(name = "ActDTCapUsed", nillable = true)
    @XmlSchemaType(name = "nonNegativeInteger")
    protected BigInteger actDTCapUsed;
    @XmlElement(name = "FutDTType")
    @XmlSchemaType(name = "nonNegativeInteger")
    protected BigInteger futDTType;
    @XmlElement(name = "FutDTCapacity", nillable = true)
    @XmlSchemaType(name = "nonNegativeInteger")
    protected BigInteger futDTCapacity;
    @XmlElement(name = "FutDTFrom", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar futDTFrom;
    @XmlElement(name = "FutDTTo", nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar futDTTo;
    @XmlElement(name = "FutDTPaid", nillable = true)
    @XmlSchemaType(name = "nonNegativeInteger")
    protected BigInteger futDTPaid;
    @XmlElement(required = true)
    protected TDbReqStatus dbStatus;

    /**
     * Gets the value of the actDTType property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getActDTType() {
        return actDTType;
    }

    /**
     * Sets the value of the actDTType property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setActDTType(BigInteger value) {
        this.actDTType = value;
    }

    /**
     * Gets the value of the actDTCapacity property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getActDTCapacity() {
        return actDTCapacity;
    }

    /**
     * Sets the value of the actDTCapacity property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setActDTCapacity(BigInteger value) {
        this.actDTCapacity = value;
    }

    /**
     * Gets the value of the actDTFrom property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getActDTFrom() {
        return actDTFrom;
    }

    /**
     * Sets the value of the actDTFrom property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setActDTFrom(XMLGregorianCalendar value) {
        this.actDTFrom = value;
    }

    /**
     * Gets the value of the actDTTo property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getActDTTo() {
        return actDTTo;
    }

    /**
     * Sets the value of the actDTTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setActDTTo(XMLGregorianCalendar value) {
        this.actDTTo = value;
    }

    /**
     * Gets the value of the actDTCapUsed property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getActDTCapUsed() {
        return actDTCapUsed;
    }

    /**
     * Sets the value of the actDTCapUsed property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setActDTCapUsed(BigInteger value) {
        this.actDTCapUsed = value;
    }

    /**
     * Gets the value of the futDTType property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getFutDTType() {
        return futDTType;
    }

    /**
     * Sets the value of the futDTType property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setFutDTType(BigInteger value) {
        this.futDTType = value;
    }

    /**
     * Gets the value of the futDTCapacity property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getFutDTCapacity() {
        return futDTCapacity;
    }

    /**
     * Sets the value of the futDTCapacity property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setFutDTCapacity(BigInteger value) {
        this.futDTCapacity = value;
    }

    /**
     * Gets the value of the futDTFrom property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getFutDTFrom() {
        return futDTFrom;
    }

    /**
     * Sets the value of the futDTFrom property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFutDTFrom(XMLGregorianCalendar value) {
        this.futDTFrom = value;
    }

    /**
     * Gets the value of the futDTTo property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getFutDTTo() {
        return futDTTo;
    }

    /**
     * Sets the value of the futDTTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setFutDTTo(XMLGregorianCalendar value) {
        this.futDTTo = value;
    }

    /**
     * Gets the value of the futDTPaid property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getFutDTPaid() {
        return futDTPaid;
    }

    /**
     * Sets the value of the futDTPaid property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setFutDTPaid(BigInteger value) {
        this.futDTPaid = value;
    }

    /**
     * Gets the value of the dbStatus property.
     * 
     * @return
     *     possible object is
     *     {@link TDbReqStatus }
     *     
     */
    public TDbReqStatus getDbStatus() {
        return dbStatus;
    }

    /**
     * Sets the value of the dbStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link TDbReqStatus }
     *     
     */
    public void setDbStatus(TDbReqStatus value) {
        this.dbStatus = value;
    }

}
