
package cz.czechpoint.isds.v20;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for tUpdDBUserInput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tUpdDBUserInput"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="dbOwnerInfo" type="{http://isds.czechpoint.cz/v20}tDbOwnerInfoExt"/&gt;
 *         &lt;element name="dbOldUserInfo" type="{http://isds.czechpoint.cz/v20}tDbUserInfoExt"/&gt;
 *         &lt;element name="dbNewUserInfo" type="{http://isds.czechpoint.cz/v20}tDbUserInfoExt"/&gt;
 *         &lt;group ref="{http://isds.czechpoint.cz/v20}gExtApproval"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tUpdDBUserInput", propOrder = {
    "dbOwnerInfo",
    "dbOldUserInfo",
    "dbNewUserInfo",
    "dbApproved",
    "dbExternRefNumber"
})
public class TUpdDBUserInput {

    @XmlElement(required = true)
    protected TDbOwnerInfoExt dbOwnerInfo;
    @XmlElement(required = true)
    protected TDbUserInfoExt dbOldUserInfo;
    @XmlElement(required = true)
    protected TDbUserInfoExt dbNewUserInfo;
    @XmlElement(nillable = true)
    protected Boolean dbApproved;
    @XmlElement(nillable = true)
    protected String dbExternRefNumber;

    /**
     * Gets the value of the dbOwnerInfo property.
     * 
     * @return
     *     possible object is
     *     {@link TDbOwnerInfoExt }
     *     
     */
    public TDbOwnerInfoExt getDbOwnerInfo() {
        return dbOwnerInfo;
    }

    /**
     * Sets the value of the dbOwnerInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link TDbOwnerInfoExt }
     *     
     */
    public void setDbOwnerInfo(TDbOwnerInfoExt value) {
        this.dbOwnerInfo = value;
    }

    /**
     * Gets the value of the dbOldUserInfo property.
     * 
     * @return
     *     possible object is
     *     {@link TDbUserInfoExt }
     *     
     */
    public TDbUserInfoExt getDbOldUserInfo() {
        return dbOldUserInfo;
    }

    /**
     * Sets the value of the dbOldUserInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link TDbUserInfoExt }
     *     
     */
    public void setDbOldUserInfo(TDbUserInfoExt value) {
        this.dbOldUserInfo = value;
    }

    /**
     * Gets the value of the dbNewUserInfo property.
     * 
     * @return
     *     possible object is
     *     {@link TDbUserInfoExt }
     *     
     */
    public TDbUserInfoExt getDbNewUserInfo() {
        return dbNewUserInfo;
    }

    /**
     * Sets the value of the dbNewUserInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link TDbUserInfoExt }
     *     
     */
    public void setDbNewUserInfo(TDbUserInfoExt value) {
        this.dbNewUserInfo = value;
    }

    /**
     * Gets the value of the dbApproved property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDbApproved() {
        return dbApproved;
    }

    /**
     * Sets the value of the dbApproved property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDbApproved(Boolean value) {
        this.dbApproved = value;
    }

    /**
     * Gets the value of the dbExternRefNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbExternRefNumber() {
        return dbExternRefNumber;
    }

    /**
     * Sets the value of the dbExternRefNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbExternRefNumber(String value) {
        this.dbExternRefNumber = value;
    }

}
