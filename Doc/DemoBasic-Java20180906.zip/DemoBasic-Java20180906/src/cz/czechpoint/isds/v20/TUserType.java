
package cz.czechpoint.isds.v20;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for tUserType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="tUserType"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="PRIMARY_USER"/&gt;
 *     &lt;enumeration value="ENTRUSTED_USER"/&gt;
 *     &lt;enumeration value="ADMINISTRATOR"/&gt;
 *     &lt;enumeration value="OFFICIAL"/&gt;
 *     &lt;enumeration value="OFFICIAL_CERT"/&gt;
 *     &lt;enumeration value="LIQUIDATOR"/&gt;
 *     &lt;enumeration value="RECEIVER"/&gt;
 *     &lt;enumeration value="GUARDIAN"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "tUserType")
@XmlEnum
public enum TUserType {

    PRIMARY_USER,
    ENTRUSTED_USER,
    ADMINISTRATOR,
    OFFICIAL,
    OFFICIAL_CERT,
    LIQUIDATOR,
    RECEIVER,
    GUARDIAN;

    public String value() {
        return name();
    }

    public static TUserType fromValue(String v) {
        return valueOf(v);
    }

}
