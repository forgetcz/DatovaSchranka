
package cz.czechpoint.isds.v20;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for tGetOwnInfoOutput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tGetOwnInfoOutput"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="dbOwnerInfo" type="{http://isds.czechpoint.cz/v20}tDbOwnerInfo"/&gt;
 *         &lt;element name="dbStatus" type="{http://isds.czechpoint.cz/v20}tDbReqStatus"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tGetOwnInfoOutput", propOrder = {
    "dbOwnerInfo",
    "dbStatus"
})
public class TGetOwnInfoOutput {

    @XmlElement(required = true)
    protected TDbOwnerInfo dbOwnerInfo;
    @XmlElement(required = true)
    protected TDbReqStatus dbStatus;

    /**
     * Gets the value of the dbOwnerInfo property.
     * 
     * @return
     *     possible object is
     *     {@link TDbOwnerInfo }
     *     
     */
    public TDbOwnerInfo getDbOwnerInfo() {
        return dbOwnerInfo;
    }

    /**
     * Sets the value of the dbOwnerInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link TDbOwnerInfo }
     *     
     */
    public void setDbOwnerInfo(TDbOwnerInfo value) {
        this.dbOwnerInfo = value;
    }

    /**
     * Gets the value of the dbStatus property.
     * 
     * @return
     *     possible object is
     *     {@link TDbReqStatus }
     *     
     */
    public TDbReqStatus getDbStatus() {
        return dbStatus;
    }

    /**
     * Sets the value of the dbStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link TDbReqStatus }
     *     
     */
    public void setDbStatus(TDbReqStatus value) {
        this.dbStatus = value;
    }

}
