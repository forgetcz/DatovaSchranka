
package cz.czechpoint.isds.v20;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for tCiRecord complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tCiRecord"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;group ref="{http://isds.czechpoint.cz/v20}gCiRecord"/&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tCiRecord", propOrder = {
    "ciEventTime",
    "ciEventType",
    "ciCreditChange",
    "ciCreditAfter",
    "ciTransID",
    "ciRecipientID",
    "ciPDZID",
    "ciNewCapacity",
    "ciNewFrom",
    "ciNewTo",
    "ciOldCapacity",
    "ciOldFrom",
    "ciOldTo",
    "ciDoneBy"
})
public class TCiRecord {

    @XmlElement(required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar ciEventTime;
    @XmlElement(required = true)
    protected BigInteger ciEventType;
    @XmlElement(required = true)
    protected BigInteger ciCreditChange;
    @XmlElement(required = true)
    protected BigInteger ciCreditAfter;
    protected String ciTransID;
    protected String ciRecipientID;
    protected String ciPDZID;
    protected BigInteger ciNewCapacity;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar ciNewFrom;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar ciNewTo;
    @XmlElement(nillable = true)
    protected BigInteger ciOldCapacity;
    @XmlElement(nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar ciOldFrom;
    @XmlElement(nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar ciOldTo;
    @XmlElement(nillable = true)
    protected String ciDoneBy;

    /**
     * Gets the value of the ciEventTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCiEventTime() {
        return ciEventTime;
    }

    /**
     * Sets the value of the ciEventTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCiEventTime(XMLGregorianCalendar value) {
        this.ciEventTime = value;
    }

    /**
     * Gets the value of the ciEventType property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCiEventType() {
        return ciEventType;
    }

    /**
     * Sets the value of the ciEventType property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCiEventType(BigInteger value) {
        this.ciEventType = value;
    }

    /**
     * Gets the value of the ciCreditChange property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCiCreditChange() {
        return ciCreditChange;
    }

    /**
     * Sets the value of the ciCreditChange property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCiCreditChange(BigInteger value) {
        this.ciCreditChange = value;
    }

    /**
     * Gets the value of the ciCreditAfter property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCiCreditAfter() {
        return ciCreditAfter;
    }

    /**
     * Sets the value of the ciCreditAfter property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCiCreditAfter(BigInteger value) {
        this.ciCreditAfter = value;
    }

    /**
     * Gets the value of the ciTransID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCiTransID() {
        return ciTransID;
    }

    /**
     * Sets the value of the ciTransID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCiTransID(String value) {
        this.ciTransID = value;
    }

    /**
     * Gets the value of the ciRecipientID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCiRecipientID() {
        return ciRecipientID;
    }

    /**
     * Sets the value of the ciRecipientID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCiRecipientID(String value) {
        this.ciRecipientID = value;
    }

    /**
     * Gets the value of the ciPDZID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCiPDZID() {
        return ciPDZID;
    }

    /**
     * Sets the value of the ciPDZID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCiPDZID(String value) {
        this.ciPDZID = value;
    }

    /**
     * Gets the value of the ciNewCapacity property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCiNewCapacity() {
        return ciNewCapacity;
    }

    /**
     * Sets the value of the ciNewCapacity property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCiNewCapacity(BigInteger value) {
        this.ciNewCapacity = value;
    }

    /**
     * Gets the value of the ciNewFrom property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCiNewFrom() {
        return ciNewFrom;
    }

    /**
     * Sets the value of the ciNewFrom property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCiNewFrom(XMLGregorianCalendar value) {
        this.ciNewFrom = value;
    }

    /**
     * Gets the value of the ciNewTo property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCiNewTo() {
        return ciNewTo;
    }

    /**
     * Sets the value of the ciNewTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCiNewTo(XMLGregorianCalendar value) {
        this.ciNewTo = value;
    }

    /**
     * Gets the value of the ciOldCapacity property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCiOldCapacity() {
        return ciOldCapacity;
    }

    /**
     * Sets the value of the ciOldCapacity property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCiOldCapacity(BigInteger value) {
        this.ciOldCapacity = value;
    }

    /**
     * Gets the value of the ciOldFrom property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCiOldFrom() {
        return ciOldFrom;
    }

    /**
     * Sets the value of the ciOldFrom property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCiOldFrom(XMLGregorianCalendar value) {
        this.ciOldFrom = value;
    }

    /**
     * Gets the value of the ciOldTo property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCiOldTo() {
        return ciOldTo;
    }

    /**
     * Sets the value of the ciOldTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCiOldTo(XMLGregorianCalendar value) {
        this.ciOldTo = value;
    }

    /**
     * Gets the value of the ciDoneBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCiDoneBy() {
        return ciDoneBy;
    }

    /**
     * Sets the value of the ciDoneBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCiDoneBy(String value) {
        this.ciDoneBy = value;
    }

}
