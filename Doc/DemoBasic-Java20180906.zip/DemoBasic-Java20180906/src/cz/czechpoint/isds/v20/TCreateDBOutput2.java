
package cz.czechpoint.isds.v20;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for tCreateDBOutput2 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tCreateDBOutput2"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="dbID" type="{http://isds.czechpoint.cz/v20}tIdDb" minOccurs="0"/&gt;
 *         &lt;element name="dbUserID" type="{http://isds.czechpoint.cz/v20}tUserID" minOccurs="0"/&gt;
 *         &lt;element name="dbAccessDataId" type="{http://isds.czechpoint.cz/v20}tDbAccessDataId" minOccurs="0"/&gt;
 *         &lt;element name="dbStatus" type="{http://isds.czechpoint.cz/v20}tDbReqStatus"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tCreateDBOutput2", propOrder = {
    "dbID",
    "dbUserID",
    "dbAccessDataId",
    "dbStatus"
})
public class TCreateDBOutput2 {

    @XmlElement(nillable = true)
    protected String dbID;
    @XmlElement(nillable = true)
    protected String dbUserID;
    @XmlElement(nillable = true)
    protected String dbAccessDataId;
    @XmlElement(required = true)
    protected TDbReqStatus dbStatus;

    /**
     * Gets the value of the dbID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbID() {
        return dbID;
    }

    /**
     * Sets the value of the dbID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbID(String value) {
        this.dbID = value;
    }

    /**
     * Gets the value of the dbUserID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbUserID() {
        return dbUserID;
    }

    /**
     * Sets the value of the dbUserID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbUserID(String value) {
        this.dbUserID = value;
    }

    /**
     * Gets the value of the dbAccessDataId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbAccessDataId() {
        return dbAccessDataId;
    }

    /**
     * Sets the value of the dbAccessDataId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbAccessDataId(String value) {
        this.dbAccessDataId = value;
    }

    /**
     * Gets the value of the dbStatus property.
     * 
     * @return
     *     possible object is
     *     {@link TDbReqStatus }
     *     
     */
    public TDbReqStatus getDbStatus() {
        return dbStatus;
    }

    /**
     * Sets the value of the dbStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link TDbReqStatus }
     *     
     */
    public void setDbStatus(TDbReqStatus value) {
        this.dbStatus = value;
    }

}
