
package cz.czechpoint.isds.v20;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for tChangeDBsTypeInput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tChangeDBsTypeInput"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="refNumber" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="newDBType" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="IDsFile" type="{http://www.w3.org/2001/XMLSchema}base64Binary"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tChangeDBsTypeInput", propOrder = {
    "refNumber",
    "newDBType",
    "iDsFile"
})
public class TChangeDBsTypeInput {

    @XmlElement(required = true)
    protected String refNumber;
    @XmlElement(required = true)
    protected String newDBType;
    @XmlElement(name = "IDsFile", required = true)
    protected byte[] iDsFile;

    /**
     * Gets the value of the refNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefNumber() {
        return refNumber;
    }

    /**
     * Sets the value of the refNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefNumber(String value) {
        this.refNumber = value;
    }

    /**
     * Gets the value of the newDBType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNewDBType() {
        return newDBType;
    }

    /**
     * Sets the value of the newDBType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNewDBType(String value) {
        this.newDBType = value;
    }

    /**
     * Gets the value of the iDsFile property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getIDsFile() {
        return iDsFile;
    }

    /**
     * Sets the value of the iDsFile property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setIDsFile(byte[] value) {
        this.iDsFile = value;
    }

}
