
package cz.czechpoint.isds.v20;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for tDbType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="tDbType"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="FO"/&gt;
 *     &lt;enumeration value="PFO"/&gt;
 *     &lt;enumeration value="PFO_ADVOK"/&gt;
 *     &lt;enumeration value="PFO_DANPOR"/&gt;
 *     &lt;enumeration value="PFO_INSSPR"/&gt;
 *     &lt;enumeration value="PFO_AUDITOR"/&gt;
 *     &lt;enumeration value="PO"/&gt;
 *     &lt;enumeration value="PO_ZAK"/&gt;
 *     &lt;enumeration value="PO_REQ"/&gt;
 *     &lt;enumeration value="OVM"/&gt;
 *     &lt;enumeration value="OVM_NOTAR"/&gt;
 *     &lt;enumeration value="OVM_EXEKUT"/&gt;
 *     &lt;enumeration value="OVM_REQ"/&gt;
 *     &lt;enumeration value="OVM_FO"/&gt;
 *     &lt;enumeration value="OVM_PFO"/&gt;
 *     &lt;enumeration value="OVM_PO"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "tDbType")
@XmlEnum
public enum TDbType {

    FO,
    PFO,
    PFO_ADVOK,
    PFO_DANPOR,
    PFO_INSSPR,
    PFO_AUDITOR,
    PO,
    PO_ZAK,
    PO_REQ,
    OVM,
    OVM_NOTAR,
    OVM_EXEKUT,
    OVM_REQ,
    OVM_FO,
    OVM_PFO,
    OVM_PO;

    public String value() {
        return name();
    }

    public static TDbType fromValue(String v) {
        return valueOf(v);
    }

}
