
package cz.czechpoint.isds.v20;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for tCreateDBInput2 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tCreateDBInput2"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="dbOwnerInfo"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;extension base="{http://isds.czechpoint.cz/v20}tDbOwnerInfoExt2"&gt;
 *                 &lt;attGroup ref="{http://isds.czechpoint.cz/v20}agCzPInfo"/&gt;
 *                 &lt;attribute name="formdataid" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *                 &lt;attribute name="identityDocumentNum" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *                 &lt;attribute name="identityDocumentType" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *                 &lt;attribute name="PDZ"&gt;
 *                   &lt;simpleType&gt;
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                       &lt;maxLength value="1"/&gt;
 *                       &lt;minLength value="1"/&gt;
 *                     &lt;/restriction&gt;
 *                   &lt;/simpleType&gt;
 *                 &lt;/attribute&gt;
 *               &lt;/extension&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="pnLastNameAtBirth" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="notifEmail" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="dbPrimaryUsers" type="{http://isds.czechpoint.cz/v20}tDbUsersArray2"/&gt;
 *         &lt;element name="dbVirtual" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/&gt;
 *         &lt;element name="email" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;group ref="{http://isds.czechpoint.cz/v20}gExtApproval"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tCreateDBInput2", propOrder = {
    "dbOwnerInfo",
    "pnLastNameAtBirth",
    "notifEmail",
    "dbPrimaryUsers",
    "dbVirtual",
    "email",
    "dbApproved",
    "dbExternRefNumber"
})
public class TCreateDBInput2 {

    @XmlElement(required = true)
    protected TCreateDBInput2 .DbOwnerInfo dbOwnerInfo;
    @XmlElement(nillable = true)
    protected String pnLastNameAtBirth;
    @XmlElement(nillable = true)
    protected String notifEmail;
    @XmlElement(required = true)
    protected TDbUsersArray2 dbPrimaryUsers;
    @XmlElement(nillable = true)
    protected Boolean dbVirtual;
    @XmlElement(nillable = true)
    protected String email;
    @XmlElement(nillable = true)
    protected Boolean dbApproved;
    @XmlElement(nillable = true)
    protected String dbExternRefNumber;

    /**
     * Gets the value of the dbOwnerInfo property.
     * 
     * @return
     *     possible object is
     *     {@link TCreateDBInput2 .DbOwnerInfo }
     *     
     */
    public TCreateDBInput2 .DbOwnerInfo getDbOwnerInfo() {
        return dbOwnerInfo;
    }

    /**
     * Sets the value of the dbOwnerInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link TCreateDBInput2 .DbOwnerInfo }
     *     
     */
    public void setDbOwnerInfo(TCreateDBInput2 .DbOwnerInfo value) {
        this.dbOwnerInfo = value;
    }

    /**
     * Gets the value of the pnLastNameAtBirth property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPnLastNameAtBirth() {
        return pnLastNameAtBirth;
    }

    /**
     * Sets the value of the pnLastNameAtBirth property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPnLastNameAtBirth(String value) {
        this.pnLastNameAtBirth = value;
    }

    /**
     * Gets the value of the notifEmail property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNotifEmail() {
        return notifEmail;
    }

    /**
     * Sets the value of the notifEmail property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNotifEmail(String value) {
        this.notifEmail = value;
    }

    /**
     * Gets the value of the dbPrimaryUsers property.
     * 
     * @return
     *     possible object is
     *     {@link TDbUsersArray2 }
     *     
     */
    public TDbUsersArray2 getDbPrimaryUsers() {
        return dbPrimaryUsers;
    }

    /**
     * Sets the value of the dbPrimaryUsers property.
     * 
     * @param value
     *     allowed object is
     *     {@link TDbUsersArray2 }
     *     
     */
    public void setDbPrimaryUsers(TDbUsersArray2 value) {
        this.dbPrimaryUsers = value;
    }

    /**
     * Gets the value of the dbVirtual property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDbVirtual() {
        return dbVirtual;
    }

    /**
     * Sets the value of the dbVirtual property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDbVirtual(Boolean value) {
        this.dbVirtual = value;
    }

    /**
     * Gets the value of the email property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the value of the email property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmail(String value) {
        this.email = value;
    }

    /**
     * Gets the value of the dbApproved property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDbApproved() {
        return dbApproved;
    }

    /**
     * Sets the value of the dbApproved property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDbApproved(Boolean value) {
        this.dbApproved = value;
    }

    /**
     * Gets the value of the dbExternRefNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbExternRefNumber() {
        return dbExternRefNumber;
    }

    /**
     * Sets the value of the dbExternRefNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbExternRefNumber(String value) {
        this.dbExternRefNumber = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;extension base="{http://isds.czechpoint.cz/v20}tDbOwnerInfoExt2"&gt;
     *       &lt;attGroup ref="{http://isds.czechpoint.cz/v20}agCzPInfo"/&gt;
     *       &lt;attribute name="formdataid" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
     *       &lt;attribute name="identityDocumentNum" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
     *       &lt;attribute name="identityDocumentType" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
     *       &lt;attribute name="PDZ"&gt;
     *         &lt;simpleType&gt;
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *             &lt;maxLength value="1"/&gt;
     *             &lt;minLength value="1"/&gt;
     *           &lt;/restriction&gt;
     *         &lt;/simpleType&gt;
     *       &lt;/attribute&gt;
     *     &lt;/extension&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class DbOwnerInfo
        extends TDbOwnerInfoExt2
    {

        @XmlAttribute(name = "formdataid")
        protected String formdataid;
        @XmlAttribute(name = "identityDocumentNum")
        protected String identityDocumentNum;
        @XmlAttribute(name = "identityDocumentType")
        protected String identityDocumentType;
        @XmlAttribute(name = "PDZ")
        protected String pdz;
        @XmlAttribute(name = "guid")
        protected String guid;
        @XmlAttribute(name = "subject")
        protected String subject;
        @XmlAttribute(name = "branch")
        protected String branch;

        /**
         * Gets the value of the formdataid property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getFormdataid() {
            return formdataid;
        }

        /**
         * Sets the value of the formdataid property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setFormdataid(String value) {
            this.formdataid = value;
        }

        /**
         * Gets the value of the identityDocumentNum property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getIdentityDocumentNum() {
            return identityDocumentNum;
        }

        /**
         * Sets the value of the identityDocumentNum property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setIdentityDocumentNum(String value) {
            this.identityDocumentNum = value;
        }

        /**
         * Gets the value of the identityDocumentType property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getIdentityDocumentType() {
            return identityDocumentType;
        }

        /**
         * Sets the value of the identityDocumentType property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setIdentityDocumentType(String value) {
            this.identityDocumentType = value;
        }

        /**
         * Gets the value of the pdz property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPDZ() {
            return pdz;
        }

        /**
         * Sets the value of the pdz property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPDZ(String value) {
            this.pdz = value;
        }

        /**
         * Gets the value of the guid property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getGuid() {
            return guid;
        }

        /**
         * Sets the value of the guid property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setGuid(String value) {
            this.guid = value;
        }

        /**
         * Gets the value of the subject property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getSubject() {
            return subject;
        }

        /**
         * Sets the value of the subject property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setSubject(String value) {
            this.subject = value;
        }

        /**
         * Gets the value of the branch property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getBranch() {
            return branch;
        }

        /**
         * Sets the value of the branch property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setBranch(String value) {
            this.branch = value;
        }

    }

}
