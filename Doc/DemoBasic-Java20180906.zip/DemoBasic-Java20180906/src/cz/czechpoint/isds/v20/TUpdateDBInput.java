
package cz.czechpoint.isds.v20;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for tUpdateDBInput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tUpdateDBInput"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="dbOldOwnerInfo" type="{http://isds.czechpoint.cz/v20}tDbOwnerInfoExt"/&gt;
 *         &lt;element name="dbNewOwnerInfo" type="{http://isds.czechpoint.cz/v20}tDbOwnerInfoExt"/&gt;
 *         &lt;group ref="{http://isds.czechpoint.cz/v20}gExtApproval"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tUpdateDBInput", propOrder = {
    "dbOldOwnerInfo",
    "dbNewOwnerInfo",
    "dbApproved",
    "dbExternRefNumber"
})
public class TUpdateDBInput {

    @XmlElement(required = true)
    protected TDbOwnerInfoExt dbOldOwnerInfo;
    @XmlElement(required = true)
    protected TDbOwnerInfoExt dbNewOwnerInfo;
    @XmlElement(nillable = true)
    protected Boolean dbApproved;
    @XmlElement(nillable = true)
    protected String dbExternRefNumber;

    /**
     * Gets the value of the dbOldOwnerInfo property.
     * 
     * @return
     *     possible object is
     *     {@link TDbOwnerInfoExt }
     *     
     */
    public TDbOwnerInfoExt getDbOldOwnerInfo() {
        return dbOldOwnerInfo;
    }

    /**
     * Sets the value of the dbOldOwnerInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link TDbOwnerInfoExt }
     *     
     */
    public void setDbOldOwnerInfo(TDbOwnerInfoExt value) {
        this.dbOldOwnerInfo = value;
    }

    /**
     * Gets the value of the dbNewOwnerInfo property.
     * 
     * @return
     *     possible object is
     *     {@link TDbOwnerInfoExt }
     *     
     */
    public TDbOwnerInfoExt getDbNewOwnerInfo() {
        return dbNewOwnerInfo;
    }

    /**
     * Sets the value of the dbNewOwnerInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link TDbOwnerInfoExt }
     *     
     */
    public void setDbNewOwnerInfo(TDbOwnerInfoExt value) {
        this.dbNewOwnerInfo = value;
    }

    /**
     * Gets the value of the dbApproved property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDbApproved() {
        return dbApproved;
    }

    /**
     * Sets the value of the dbApproved property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDbApproved(Boolean value) {
        this.dbApproved = value;
    }

    /**
     * Gets the value of the dbExternRefNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbExternRefNumber() {
        return dbExternRefNumber;
    }

    /**
     * Sets the value of the dbExternRefNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbExternRefNumber(String value) {
        this.dbExternRefNumber = value;
    }

}
