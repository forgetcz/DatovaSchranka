
package cz.czechpoint.isds.v20;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for tFindDBOuput2 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tFindDBOuput2"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="dbResults" type="{http://isds.czechpoint.cz/v20}tDbOwnersArray2" minOccurs="0"/&gt;
 *         &lt;element name="dbStatus" type="{http://isds.czechpoint.cz/v20}tDbReqStatus"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tFindDBOuput2", propOrder = {
    "dbResults",
    "dbStatus"
})
public class TFindDBOuput2 {

    @XmlElement(nillable = true)
    protected TDbOwnersArray2 dbResults;
    @XmlElement(required = true)
    protected TDbReqStatus dbStatus;

    /**
     * Gets the value of the dbResults property.
     * 
     * @return
     *     possible object is
     *     {@link TDbOwnersArray2 }
     *     
     */
    public TDbOwnersArray2 getDbResults() {
        return dbResults;
    }

    /**
     * Sets the value of the dbResults property.
     * 
     * @param value
     *     allowed object is
     *     {@link TDbOwnersArray2 }
     *     
     */
    public void setDbResults(TDbOwnersArray2 value) {
        this.dbResults = value;
    }

    /**
     * Gets the value of the dbStatus property.
     * 
     * @return
     *     possible object is
     *     {@link TDbReqStatus }
     *     
     */
    public TDbReqStatus getDbStatus() {
        return dbStatus;
    }

    /**
     * Sets the value of the dbStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link TDbReqStatus }
     *     
     */
    public void setDbStatus(TDbReqStatus value) {
        this.dbStatus = value;
    }

}
