
package cz.czechpoint.isds.v20;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for tdbResultsArray complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tdbResultsArray"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence maxOccurs="unbounded" minOccurs="0"&gt;
 *         &lt;element name="dbResult" type="{http://isds.czechpoint.cz/v20}tdbResult"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tdbResultsArray", propOrder = {
    "dbResult"
})
public class TdbResultsArray {

    protected List<TdbResult> dbResult;

    /**
     * Gets the value of the dbResult property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the dbResult property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDbResult().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TdbResult }
     * 
     * 
     */
    public List<TdbResult> getDbResult() {
        if (dbResult == null) {
            dbResult = new ArrayList<TdbResult>();
        }
        return this.dbResult;
    }

}
