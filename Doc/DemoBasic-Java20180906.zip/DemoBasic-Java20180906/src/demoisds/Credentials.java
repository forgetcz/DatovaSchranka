package demoisds;

import java.io.Console;

/**
 * Přihlašovací údaje
 *Druh prihlaseni:
 * (1) jmenem a heslem: zadejte UserID a heslo na konzoli
 * (2) systemovym certifikatem: nezadavejte UserID a heslo, 
 * 
 *  
 */

public class Credentials {

  private String LoginName1 = null;

  public String getLoginName1() {
    return LoginName1;
  }
  private String Password1 = null;

  public String getPassword1() {
    return Password1;
  }
  private String CertFilePath = null;

  public String getCertFilePath() {
    return CertFilePath;
  }
  private String CertPassword = null;

  public String getCertPassword() {
    return CertPassword;
  }

  public void loadCredentials() {
    System.out.println("Tohle je priklad nacteni prihlasovacich udaju. ");
    System.out.println("Ulozeni jmena a hesla primo ve zdrojovem kodu aplikace neni bezpecne.");
    System.out.println("Stejne tak ulozeni privatniho klice na disku neni bezpecne.");
    System.out.println("Bezpecne je ulozeni privatniho klice v ulozisti certifikatu nebo v hardwarovem zarizeni. \n\n");

    Console console = System.console();
    if (console == null) {
      throw new Error("Toto nacteni udaju je funkcni jen pri spusteni programu v prikazovem radku (cmd.exe, bash).\n");
    }

    LoginName1 = console.readLine("Zadejte uzivatelske jmeno: ");
    Password1 = new String(console.readPassword("Zadejte heslo: "));
  }
}
