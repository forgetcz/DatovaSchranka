------------------------------------------------------
TATO VERZE JE URCENA PRO ALTERNATIVNI PRISTUP K ISDS
------------------------------------------------------
verze 3.2 z 30.8.2018
- volani WS z noveho wsdl verze 2.30

verzi 3.1. z 9.3.2016
Novinky: doplneny komentare a popisy

----------------------------------------------------------------------------------------------
Soucasti projektu
----------------------------------------------------------------------------------------------

[cert] - adresar obsahuje serverove certifikaty a skript, ktery je importuje do java key store 
[src] - adresar se zdrojovymi kody prikladu
[ws] - adresar s potrebnymi wsdl a xsd soubory a skriptem, ktery z nich vygeneruje javovske tridy 
Readme.txt - tento soubor

----------------------------------------------------------------------------------------------
Instalace
----------------------------------------------------------------------------------------------

- vytvorte projekt ze zdroju v [src]
- zajistete import serverovych certifikatu do java key store pomoci skriptu v [cert],
  pripadne nahradte stavajici certifikaty ve slozce aktualnimi 

----------------------------------------------------------------------------------------------
Preklad a spusteni
----------------------------------------------------------------------------------------------

Pro spusteni demonstracniho programu budete potrebovat prihlasovaci udaje k datove schrance. 
Defaultne je nastaveno prostredi Verejneho Testu ISDS. 

Dotazy a pripominky k projektu muzete zasilat emailem na adresu technicka.podpora.ISDS@cpost.cz. 
Existuje i obdobny priklad pro PHP a dotNET.

----------------------------------------------------------------------------------------------
Moznosti prihlaseni
----------------------------------------------------------------------------------------------

Tento ukazkovy priklad umoznuje 4 zakladni druhy prihlaseni do datove schranky:

1. Jmenem a heslem - treba zadat uzivatelske jmeno a uzivatelske heslo
2. Pomoci systemoveho certifikatu - certifikat a heslo k certifikatu
3. Pomoci certifikatu hostovane spisove sluzby - misto login name se musi zadat id schranky, 
   dale pak certifikat, heslo k certifikatu
4. Jmenem, heslem a certifikatem - uzivatelske jmeno, uzivatelske heslo, certifikat a heslo 
   k certifikatu 

Priklad je pripraveny pro prihlaseni jmenem a heslem v prostredi Verejneho Testu ISDS. 
Pro odeslani datove zpravy je nutno znat ID schranky adresata, nejlepe typu OVM, abyste 
nemuseli posilat komercni zpravu. ID schranky zadejte do kodu na zacatku tridy Main.

----------------------------------------------------------------------------------------------
Moznosti demoprikladu 
----------------------------------------------------------------------------------------------

- priklad demonstruje moznou praci s datovou schrankou: prihlaseni a volani nekolika WS 
- pri volani WS se kontroluje prvni znak navratoveho kodu - "status code", zacina-li kod "0" nedoslo k chybe. Ciselnik chyb/kodu je k dispozici na vyvojarskem serveru.
- obsahuje ukazku volani zakladnich WS:

DbSearchWebService - FindDataBox - vyhledani schranky

AccessWebService - GetOwnerInfoFromLogin - informace o schrance, do ktere jsme prihlaseni
AccessWebService - GetUserInfoFromLogin - informace o prihlasenem uzivateli

OperationsWebService - CreateMessage - vytvoreni a odeslani datove zpravy
OperationsWebService - SignedMessageDownload - stazeni datove zpravy v podepsanem tvaru

InfoWebService - GetListOfReceivedMessages - vylistovani dodanych zprav
InfoWebService - GetMessageStateChanges - zjisteni zmen stavu zprav

Toto je pouze ukazka pouziti nekolika zakladnich WS. Ostatni jsou popsany v prislusne dokumentaci.
 
