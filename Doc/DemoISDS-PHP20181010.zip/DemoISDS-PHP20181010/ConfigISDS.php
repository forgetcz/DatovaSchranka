<?php
/*-----------------------------------------------------
 * Konfiguracni soubor pro komunikaci s ISDS
 *-----------------------------------------------------
 */

/*****************************************************/
/* typ portalu */
// 0 = czebox (zkusebni prostredi)
// 1 = mojedatovaschranka (ostre prostredi)
$portaltype=0;


/* konfigurace proxy */
/* proxy adresa ve tvaru xxx.xxx.xxx.xxx */
//$proxyaddress='';


/* proxy port*/
//$proxyport=80;


/* proxy login name */
//$proxylogin='';


/* proxy heslo */
//$proxypwd='';

?>