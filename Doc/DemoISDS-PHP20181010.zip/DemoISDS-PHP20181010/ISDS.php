<?php
/* Modul pro komunikaci s ISDS
 *
 * Verze 3.0
 *
 * Pripadne dotazy a pripominky zasilejte na isds@602.cz
 *
 * veskere stringy jsou ocekavany v kodovani UTF-8
 *
 * vyzaduje PHP 5 >= 5.2.13
 *
 * v php.ini je treba mit povolene nasledujici extensions: php_curl.dll, php_openssl.dll, php_soap.dll
 */ 


require_once('ConfigISDS.php');	

// service types
$OperationsService = 0;
$InfoService = 1;
$SearchService = 2;
$AccessService=3;
$StatService=4;

//sestavi URL pro danou WS
function GetServiceURL($ServiceType,$LoginType){
	global $portaltype;
	
	$res = "https://ws1";
	if ($LoginType > 0){
		$res = $res."c";
	}
	switch ($portaltype):
  	case 0:
  		$res = $res.".czebox.cz/";
  		break;
  	case 1:
  		$res = $res.".mojedatovaschranka.cz/";
  		break;
	endswitch;
	
  switch ($LoginType):
  	case 1:
  		$res = $res."cert/";
  		break;
  	case 2:
  		$res = $res."hspis/";
  		break;
  	case 2:
  		$res = $res."certds/";
  		break;	
	endswitch;
	
  $res = $res."DS/";
	
  switch ($ServiceType):
  	case 0:
  		$res = $res."dz";
  		break;
  	case 1:
  		$res = $res."dx";
  		break;
  	case 2:
  		$res = $res."df";
  		break;
  	case 3:
  		$res = $res."DsManage";
  		break;
  	case 4:	
      $res = $res."DsManage";
  		break; 
	endswitch;	
	
  return $res;
}

// vrati WSDL soubor pro danou typ WS
function GetServiceWSDL($ServiceType){
	switch ($ServiceType):
	case 0:
		return "dm_operations.wsdl";
	case 1:
		return "dm_info.wsdl";
	case 2:
		return "db_search.wsdl";
	case 3:
		return "db_access.wsdl";
	endswitch;				
}

function CreateArray($object) {
  if (count($object) != 1) {
    return $object;
  }
    return array($object);
}

class ISDSSoapClient extends SoapClient 
{
  // curl handle
	var $ch;

	function __doRequest($request, $location, $action, $version, $one_way = NULL) 
	{
		global $debug,$proxyaddress,$proxyport,$proxylogin,$proxypwd,$onlycurl,$usenss;

		$headers = array(
			'Method: POST',
			'Connection: Keep-Alive',
			'User-Agent: Demo PHP ISDS 3.0',
			'Content-Type: text/xml; charset=utf-8'
			);  
		$this->__last_request_headers = $headers;
		
		curl_setopt($this->ch, CURLOPT_URL, $location);
		curl_setopt($this->ch, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($this->ch, CURLOPT_POSTFIELDS,$request);

		$response = curl_exec($this->ch); 
			
		if (curl_errno($this->ch) != 0)
		{
			throw new exception('CurlError: '.curl_errno($this->ch).' Message:'.curl_error($this->ch));
		}
		return $response;
	}

}

// trida pro komunikaci s ISDS schrankou
class ISDSBox{
	// sluzby pro pristup ke schrance
	var $OperationsWS;
	var $InfoWS;	
	var $SearchWS;
	var $AccessWS;
	var $ch;			// curl handle

	// konstruktor
	public function __construct(
		$logintype,	// zpusob prihlaseni. 0=jmeno heslo, 1=spisovka (certifikat), 2=hostovana spisovka (jmeno, heslo, certifikat), 3 uzivatelsky certifikat
		$loginname,	// prihlasovaci jmeno
		$password,	// prihlasovaci heslo
		$certfilename, 	// cesta k certifikatu
		$passphrase){	// heslo k soukromemu klici v certifikatu	
	
		global $proxyaddress,$proxyport,$proxylogin,$proxypwd;

		$this->ch=0;
		$this->ValidLogin=false;
		
		// "prebytecne" udaje vynulujeme
		if ($logintype == 0){
			$certfilename = "";
			$passphrase = "";
		}
		else{
		  if ($logintype == 1){
				$loginname = "";
				$password = "";
			}
		}		
		try{
			$this->InitCurl($logintype,$loginname,$password,$certfilename,$passphrase);
		}
		catch (Exception $e){
			throw new Exception('Pri pripojovani ke schrance doslo k chybe. '.$e->getMessage());
		} 
		
		$this->OperationsWS = new ISDSSoapClient(GetServiceWSDL(0),array(
			'login'=>$loginname,
			'password'=>$password,
			'proxy_host'=>$proxyaddress,
			'proxy_port'=>$proxyport,
			'proxy_login'=>$proxylogin,
			'proxy_password'=>$proxypwd,
			'location'=>GetServiceURL(0,$logintype),
			'trace'=>true,
			'exceptions'=>true));
		$this->OperationsWS->ch = $this->ch;
		$this->InfoWS = new ISDSSoapClient(GetServiceWSDL(1),array(
			'login'=>$loginname,
			'password'=>$password,
			'proxy_host'=>$proxyaddress,
			'proxy_port'=>$proxyport,
			'proxy_login'=>$proxylogin,
			'proxy_password'=>$proxypwd,
			'location'=>GetServiceURL(1,$logintype),
			'trace'=>true,
			'exceptions'=>true));
		$this->InfoWS->ch = $this->ch;
		$this->SearchWS = new ISDSSoapClient(GetServiceWSDL(2),array(
			'login'=>$loginname,
			'password'=>$password,
			'proxy_host'=>$proxyaddress,
			'proxy_port'=>$proxyport,
			'proxy_login'=>$proxylogin,
			'proxy_password'=>$proxypwd,
			'location'=>GetServiceURL(2,$logintype),
			'trace'=>true,
			'exceptions'=>true));
		$this->SearchWS->ch = $this->ch;
		$this->AccessWS = new ISDSSoapClient(GetServiceWSDL(3),array(
			'login'=>$loginname,
			'password'=>$password,
			'proxy_host'=>$proxyaddress,
			'proxy_port'=>$proxyport,
			'proxy_login'=>$proxylogin,
			'proxy_password'=>$proxypwd,
			'location'=>GetServiceURL(3,$logintype),
			'trace'=>true,
			'exceptions'=>true));
		$this->AccessWS->ch = $this->ch;
		$this->ValidLogin = true;
		return true;
	}

	function InitCurl(
		$logintype,	// zpusob prihlaseni. 0=jmeno heslo, 1=spisovka (systemovy certifikat), 2=hostovana spisovka (jmeno, heslo, certifikat), 3 uzivatelsky certifikat
		$loginname,	// prihlasovaci jmeno
		$password,	// prihlasovaci heslo
		$certfilename, 	// cesta k certifikatu
		$passphrase){	// heslo k soukromemu klici v certifikatu	
	
		global $debug,$proxyaddress,$proxyport,$proxylogin,$proxypwd;
		
		$this->ch = curl_init();
		curl_setopt($this->ch, CURLOPT_POST, true);
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($this->ch, CURLOPT_FAILONERROR, true);
		curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($this->ch, CURLINFO_HEADER_OUT, true);
		curl_setopt($this->ch, CURLOPT_UNRESTRICTED_AUTH,false);
		curl_setopt($this->ch, CURLOPT_NOBODY,false);
		
    if ($loginname != ""){
			curl_setopt($this->ch, CURLOPT_USERPWD,$loginname.":".$password);
		}
		// na Linuxu nastavit verzi 3, na Windows ne !
		if (stristr(PHP_OS,'WIN') === false){
			curl_setopt($this->ch, CURLOPT_SSLVERSION,3);
		}
		if ($logintype != 0){				
			curl_setopt($this->ch, CURLOPT_SSLCERT,$certfilename);
			curl_setopt($this->ch, CURLOPT_SSLCERTPASSWD,$passphrase);				
		}
		curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, false); // ignoruji se https certy  
		if ($proxyaddress != ''){
			//PrintLine('######### PRISTUP PRES PROXY ############ '.$proxyaddress.':'.$proxyport);
			curl_setopt($this->ch, CURLOPT_PROXY, 'http://'.$proxyaddress.':'.$proxyport);
			curl_setopt($this->ch, CURLOPT_HTTPPROXYTUNNEL, true);				
			if ($proxylogin != ''){
				curl_setopt($this->ch, CURLOPT_PROXYUSERPWD, $proxylogin.':'.$proxypwd);
			}
		}		
		
		curl_setopt($this->ch, CURLOPT_URL, GetServiceURL(0,$logintype));
		curl_setopt($this->ch, CURLOPT_POSTFIELDS,
			"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n".
			"    <soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">\n".
			"  <soap:Body>\n".
			"    <DummyOperation xmlns=\"http://isds.czechpoint.cz\">\n".
			"    </DummyOperation>\n".
			"  </soap:Body>\n".
			"</soap:Envelope>\n");

		if ($logintype != 0){
			curl_setopt($this->ch, CURLOPT_SSLCERT,$certfilename);
			curl_setopt($this->ch, CURLOPT_SSLCERTPASSWD,$passphrase);				
		}
	}

  function __destruct() {		
    //PrintLine('volan destructor');
  	global $portaltype;
  		
  	if ($this->ch != 0){
  		try{
  				curl_close($this->ch);           
  		}
  		catch (Exception $e){
  		} 						
  	}
  }
	
  /****************************** VOLANI WS **********************************/
  //vyhleda datovou schranku na zaklade zadanych parametru
  function FindDataBox(){
     
    $OwnerInfo=array(
    'dbID' => null,
    'aifoIsds' => null,
    'dbType' => "OVM",
    'ic' => null,
    'pnGivenNames' => null,
    'pnLastName' => null,
    'firmName' => "Ministerstvo vnitra",
    'biDate' => null,
    'biCity' => null,
    'biCounty' => null,
    'biState' => null,
    'adCode' => null,
    'adCity' => null,
    'adDistrict' => null,
    'adStreet' => null,
    'adNumberInStreet' => null,
    'adNumberInMunicipality' => null,
    'adZipCode' => null,
    'adState' => null,
    'nationality' => null,
    'dbIdOVM' => null,
    'dbState' => null,
    'dbOpenAddressing' => null,
    'dbUpperID' => null);
    
      	
    $FindInput=array('dbOwnerInfo'=>$OwnerInfo);		
  	PrintLine('Ukazka volani WS pro vyhledani schranky.');	
  	try{
      $FindOutput=$this->SearchWS->FindDataBox2($FindInput);
  	}
  	catch (Exception $e){
  		throw new Exception('Pri volani WS pro vyhledani schranky doslo k vyjimce. '.$e->getMessage());		
  	}
  	PrintLine('Status volani: '.$FindOutput->dbStatus->dbStatusMessage);
  
    if ($FindOutput->dbStatus->dbStatusCode{0} == "0"){ //navratovy kod zacina 0 
      if($FindOutput->dbResults!==null && $Result=$FindOutput->dbResults->dbOwnerInfo !==null){
        $ResultArray = CreateArray($FindOutput->dbResults->dbOwnerInfo);
        PrintLine('Pocet vyhledanych schranek: '.count($ResultArray));
        foreach ($ResultArray as $db){
          PrintLine('Nazev: '.$db->firmName.'; ID schranky: '.$db->dbID);
        }
      } 
    }
  }

  // vypise vybrane udaje o majiteli schranky, ke ktere jsme prihlaseni
  function GetOwnerInfoFromLogin(){
  	$Input=array('dbDummy'=>"");
  	PrintLine('Ukazka volani WS pro ziskani informaci o schrance, do ktere jsme prihlaseni.');
  	try{
      $Output=$this->AccessWS->GetOwnerInfoFromLogin2($Input);
  	}
  	catch (Exception $e){
      throw new Exception('Pri volani WS pro ziskani informaci o schrance, do ktere jsme prihlaseni, doslo k vyjimce. '.$e->getMessage());
  	}
  		
  	PrintLine('Status volani: '.$Output->dbStatus->dbStatusMessage);
    if ($Output->dbStatus->dbStatusCode == "0"){ 
      PrintLine('Informace o schrance do niz jste prihlaseni:');
    	PrintLine('ID schranky: '.$Output->dbOwnerInfo->dbID);
    	PrintLine('Nazev: '.$Output->dbOwnerInfo->firmName);
      PrintLine('Typ: '.$Output->dbOwnerInfo->dbType);
    }
  }
  
  // vypise vybrane informace o prihlasenem uzivateli
  function GetUserInfoFromLogin(){
  		$Input=array('dbDummy'=>"");
  		
      PrintLine('Ukazka volani WS pro ziskani informaci o prihlasenem uzivateli.');		
  		try{
  			$Output=$this->AccessWS->GetUserInfoFromLogin2($Input);
  		}
  		catch (Exception $e){
  			throw new Exception('Pri volani WS pro ziskani informaci o prihlasenem uzivateli doslo k vyjimce. '.$e->getMessage());
  		}
  		
  	PrintLine('Status volani: '.$Output->dbStatus->dbStatusMessage);
    if ($Output->dbStatus->dbStatusCode{0} == "0"){
    	PrintLine('Informace o prihlasenem uzivateli:');
    	PrintLine('userID: '.$Output->dbUserInfo->isdsID);
    	PrintLine('pnLastName: '.$Output->dbUserInfo->pnLastName);
    	PrintLine('pnGivenNames: '.$Output->dbUserInfo->pnGivenNames);
    	PrintLine('biDate: '.$Output->dbUserInfo->biDate);	
    }
  }
  
  //vytvori a posle datovou zpravu zadanemu prijemci
  function CreateMessage($recipientId){
    //obalka datove zpravy		
    $Envelope = array(
      'dmSenderOrgUnit' => "Nase org jednotka",
    	'dmSenderOrgUnitNum' => null,
    	'dbIDRecipient' => $recipientId,
    	'dmRecipientOrgUnit' => "Vase org jednotka",
    	'dmRecipientOrgUnitNum' => null,
    	'dmToHands' => "K rukam p.Novaka",
    	'dmAnnotation' => "Testovaci zprava - PHP",
    	'dmRecipientRefNumber' => "vcj. 253",
    	'dmSenderRefNumber' => "ncj. 589",
    	'dmRecipientIdent' => "VZ-147",
    	'dmSenderIdent' => "NZ-557",
    	'dmLegalTitleLaw' => "300",
    	'dmLegalTitleYear' => "2008",
    	'dmLegalTitleSect' => "2",
    	'dmLegalTitlePar' => "1",
    	'dmLegalTitlePoint' => "a",
    	'dmPersonalDelivery' => false,
    	'dmAllowSubstDelivery' => false);
  
    //prilohy/a			
    $DmFiles = array();
    $dmFile=array(
      'dmMimeType'=>"text/plain",
    	'dmFileMetaType'=>"main",
    	'dmFileGuid'=>"",
    	'dmUpFileGuid'=>"",
    	'dmFileDescr'=>"test.txt",
    	'dmFormat'=>"",
    	'dmEncodedContent'=>"Obsah testovacihou souboru v PHP.");
    	
    $DmFiles[0]=$dmFile; 					
    $MessageCreateInput = array(
    	'dmEnvelope' => $Envelope,
    	'dmFiles' => $DmFiles);
      
    PrintLine('Ukazka volani WS pro odeslani datove zpravy.');	
    try{
       $MessageCreateOutput=$this->OperationsWS->CreateMessage($MessageCreateInput);
    }
    catch (Exception $e){
       throw new Exception('Pri volani WS pro odeslani datove zpravy doslo k vyjimce. '.$e->getMessage());
    }
    	
    PrintLine('Status volani: '.$MessageCreateOutput->dmStatus->dmStatusMessage);  
    if ($MessageCreateOutput->dmStatus->dmStatusCode{0} == "0"){
      PrintLine('Zprava odeslana. ID zpravy: '.$MessageCreateOutput->dmID);
    }
  }
  
  //vypise seznam dodanych datovych zprav za posledni tyden
  function GetListOfReceivedMessages(){
  	$ReceivedMessageID = -1;
  	$date = new DateTime();
    $toTime = $date->format("Y-m-d\TH:i:s");	
    
    $date2 = new DateTime();
    $date2->modify('-7 day');
    $fromTime = $date2->format("Y-m-d\TH:i:s");
    
  	$ListOfReceivedInput=array(
  			'dmFromTime'=>$fromTime,
  			'dmToTime'=>$toTime,
  			'dmRecipientOrgUnitNum'=>null,
  			'dmStatusFilter'=>-1,
  			'dmOffset'=>"0",
  			'dmLimit'=>"100");
  	PrintLine("Ukazka stazeni seznamu dodanych zprav.");
    PrintLine("od: ".$date2->format("d.m.Y H:i:s"));
    PrintLine("do: ".$date->format("d.m.Y H:i:s"));
    try{
      $ListOfRecOutput=$this->InfoWS->GetListOfReceivedMessages($ListOfReceivedInput);
  	}
  	catch (Exception $e){
      throw new Exception('Pri volani WS pro stazeni seznamu dodanych zprav doslo k vyjimce. '.$e->getMessage());		
  	}	
  		
    PrintLine('Status volani: '.$ListOfRecOutput->dmStatus->dmStatusMessage);
    if ($ListOfRecOutput->dmStatus->dmStatusCode{0} == "0"){
      if($ListOfRecOutput->dmRecords !== null && isset($ListOfRecOutput->dmRecords->dmRecord)){   
        $ResultArray = CreateArray($ListOfRecOutput->dmRecords->dmRecord);
        PrintLine('Pocet obdrzenych zprav: '.count($ResultArray));  
        foreach ($ResultArray as $msg){
          if($ReceivedMessageID === -1){
            $ReceivedMessageID = $msg->dmID;
          }
          PrintLine('ID zpravy '.$msg->dmID.'; stav: '.$msg->dmMessageStatus.'; adresa odesilatele: '.$msg->dmSenderAddress.'; ID odesilatele: '.$msg->dbIDSender
            .'; dorucena: '.$msg->dmAcceptanceTime.'; dodana: '.$msg->dmDeliveryTime );     
        }
      } 
      else {
        PrintLine('Pocet obdrzenych zprav: 0');
      }
    }		
    return $ReceivedMessageID;
  }
  
  // Stazeni podepsane  zpravy a jeji ulozeni do souboru
  function SignedMessageDownload($MessageID){
    $MessInput=array('dmID'=>$MessageID);
    PrintLine("Ukazka volani WS pro stazeni podepsane zpravy.");
  	try{
      $SignedMessDownOutput=$this->OperationsWS->SignedMessageDownload($MessInput);
  	}
    catch (Exception $e){
      throw new Exception('Pri volani WS pro stazeni podepsane zpravy doslo k vyjimce. '.$e->getMessage());			
  	}
  	 PrintLine('Status volani: '.$SignedMessDownOutput->dmStatus->dmStatusMessage);
  	if($SignedMessDownOutput->dmStatus->dmStatusCode{0} == "0"){
      $path = dirname(__FILE__).DIRECTORY_SEPARATOR.'podepsanaZprava.zfo';
      file_put_contents($path,$SignedMessDownOutput->dmSignature);
      PrintLine('Zprava ulozena do: '.$path);
    } 
  }
  
  //vypise seznam zmen stavu zprav za posledni tyden
  function GetMessagesStateChanges(){
  	$date = new DateTime();
    $toTime = $date->format("Y-m-d\TH:i:s");	
    
    $date2 = new DateTime();
    $date2->modify('-7 day');
    $fromTime = $date2->format("Y-m-d\TH:i:s");
  	
  	$inputParams = array('dmFromTime' => $fromTime, 'dmToTime' => $toTime);
    PrintLine("Ukazka volani WS pro zjisteni zmen stavu zprav.");	
    PrintLine("od: ".$date2->format("d.m.Y H:i:s"));
    PrintLine("do: ".$date->format("d.m.Y H:i:s"));
    		
  	try{                                    
      $result = $this->InfoWS->GetMessageStateChanges($inputParams);
    }
    catch(Exception $e){
  		throw new Exception('Pri volani WS pro zjisteni zmen stavu zprav doslo k vyjimce. '.$e->getMessage());
    }
      
    PrintLine('Status volani: '.$result->dmStatus->dmStatusMessage);
  
    if($result->dmRecords!==null && $result->dmRecords->dmRecord !==null){
      $ResultArray =  CreateArray($result->dmRecords->dmRecord);
      
      PrintLine('Změny stavu zpráv: '.count($ResultArray));
      foreach ($ResultArray as $change){
        PrintLine("ID zpavy ".$change->dmID."; cas zmeny ".$change->dmEventTime."; stav  ".$change->dmMessageStatus);
      }
    }
  }
}
?>