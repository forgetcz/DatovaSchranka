<?php

/* Ukazkovy skript pro komunikaci s ISDS
 *
 * Pripadne dotazy a pripominky zasilejte na isds@602.cz
 */  

require_once('ISDS.php');	

// pomocna funkce pro vypis
function PrintLine($s){
	echo($s."\r\n");
}

// prihlaseni k ISDS - ZDE JE TREBA DOPLNIT PRIHLASOVACI JMENO, HESLO A PRIPADNE ID SCHRANKY

$loginname="";
$password="";
$boxId="";

// pri pripojovani pomoci certifikatu je treba zadat soubor s certifikatem v PEM tvaru a pripadne heslo pro privatni klic

$cert="";
$passphrase="";

  try{
  
  //prihlaseni jmenem a heslem
  $ISDSBox=new ISDSBox(0,$loginname,$password,$cert,$passphrase);
  //$ISDSBox=new ISDSBox(1,$loginname,$password,$cert,$passphrase); //prihlaseni pomoci systemoveho certifikatu - certifikat a heslo k certifikatu
  //$ISDSBox=new ISDSBox(2,$boxId,'',$cert,$passphrase); // certifikat hostovane spisove sluzby - misto login name se musi zadat id schranky
  //$ISDSBox=new ISDSBox(3,$loginname,$password,$cert,$passphrase);
  
  
  // vyhledani datove schranky 
  $Results=$ISDSBox->FindDataBox();
  PrintLine('--------------------------------------------------------------------------');
   
  // vraceni informaci o schrance ke ktere jsme prihlaseni
  $Result=$ISDSBox->GetOwnerInfoFromLogin();
  PrintLine('--------------------------------------------------------------------------');
  
  // informace o prihlasenem uzivateli
  $Result=$ISDSBox->GetUserInfoFromLogin();
  PrintLine('--------------------------------------------------------------------------');
  
  // vytvoreni zpravy
  $ISDSBox->CreateMessage("sem doplnte ID prijemce");
  PrintLine('--------------------------------------------------------------------------');
  
  // nacteni seznamu prijatych zasilek
  $ReceivedMessageID = -1; //nedefinovano                
  $ReceivedMessageID = $ISDSBox->GetListOfReceivedMessages();
  PrintLine('--------------------------------------------------------------------------');
  
  if($ReceivedMessageID != -1){
    // stazeni zpravy v podepsanem tvaru
    $Message=$ISDSBox->SignedMessageDownload($ReceivedMessageID);
    PrintLine('--------------------------------------------------------------------------');
  }
  
  //stazeni seznamu zmen stavu zprav
  $ISDSBox->GetMessagesStateChanges();
  }catch(Exception $e){
     PrintLine($e->getMessage());   
  }
PrintLine('Konec');

?>