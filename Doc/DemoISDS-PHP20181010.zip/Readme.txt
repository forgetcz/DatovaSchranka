**********************************************************************************************
*              TATO VERZE JE URCENA PRO ALTERNATIVNI PRISTUP K ISDS                          *
**********************************************************************************************

----------------------------------------------------------------------------------------------
Soucasti projektu
----------------------------------------------------------------------------------------------

ConfigISDS.php - konfigurace programu (proxy atp.)
ISDS.php - ukazky volani WS
test.php - spustitelny skript - pouziti volani WS
db_access.wsdl, db_search.wsdl, dm_info.wsdl, dm_operations.wsdl, isds_stat.wsdl dbTypes.xsd,
dmBaseTypes.xsd, IsdsStat.xsd - wsdl a xsd soubory k pouzivanym WS 
Readme.txt - tento soubor

----------------------------------------------------------------------------------------------
Spusteni
----------------------------------------------------------------------------------------------
Vyvijeno s PHP 7.1.21.

Tento priklad vola WS na prostredi Verejneho Testu (nikoli na produkcnim).

Pro spusteni demonstracniho programu budete potrebovat prihlasovaci udaje k datove schrance.
Ty pote doplnte do souboru test.php (promenne $loginname, $password a $boxId). Pro uspesne
volani WS CreateMessage je treba nahradit v test.php retezec "sem doplnte ID prijemce" platnym 
ID schranky adresata.  

Toto je pouze ukazkovy priklad. Nedoporucuje se ukladat uzivatelske jmeno a heslo primo do skriptu. 

Dotazy a pripominky k projektu muzete zasilat emailem na adresu isds@602.cz

----------------------------------------------------------------------------------------------
Moznosti prihlaseni
----------------------------------------------------------------------------------------------

Tento ukazkovy priklad umoznuje 4 druhy prihlaseni do datove schranky:

1. Jmenem a heslem - treba zadat uzivatelske jmeno a uzivatelske heslo
2. Pomoci systemoveho certifikatu - certifikat a heslo k certifikatu
3. Pomoci certifikatu hostovane spisove sluzby - misto login name se musi zadat id schranky, 
   dale pak certifikat, heslo k certifikatu
4. Jmenem, heslem a certifikatem - uzivatelske jmeno, uzivatelske heslo, certifikat a heslo 
   k certifikatu 

----------------------------------------------------------------------------------------------
Novinky ve verzi z 3.2.2012
----------------------------------------------------------------------------------------------

- priklad demostruje moznou praci s datovou schrankou 
- pri volani WS se kontroluje prvni znak navratoveho kodu - "status code",
  zacina-li kod "0" nedoslo k chybe. Ciselnik chyb/kodu je k dispozici na vyvojarskem 
  serveru.
- obsahuje ukazku volani zakladnich WS:

DbSearchWebService - FindDataBox2 - vyhledani schranky

IsdsStatService - NumOfMessages - statistika dodanych zprav systemem ISDS

AccessWebService - GetOwnerInfoFromLogin2 - informace o schrance, do ktere jsme prihlaseni
AccessWebService - GetUserInfoFromLogin2 - informace o prihlasenem uzivateli

OperationsWebService - CreateMessage - vytvoreni a odeslani datove zpravy
OperationsWebService - SignedMessageDownload - stazeni datove zpravy v podepsanem tvaru

InfoWebService - GetListOfReceivedMessages - vylistovani dodanych zprav
InfoWebService - GetMessageStateChanges - zjisteni zmen stavu zprav

Toto je pouze ukazka pouziti nekolika zakladnich WS. Ostatni jsou popsany v 
prislusne dokumentaci. 