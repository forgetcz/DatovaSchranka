--------------------------------------------------------------------------
TATO DEMOVERZE JE URCENA PRO ALTERNATIVNI PRISTUP K ISDS (verze pro DotNET)
--------------------------------------------------------------------------

--------------------------------------------------------------------------------
Soucasti projektu
--------------------------------------------------------------------------------

ISDSBox.cs - trida reprezentujici datavou schranku - obsahuje ukazky volani WS
Program.cs - testovaci konzolova aplikace
app.Config, AssemblyInfo.cs, DemoISDS.csproj - standardni soucasti C# projektu
DataBoxSearch.cs, DataBoxAccess.cs, dmInfoWebService.cs, dmOperationsWebService.cs 
a IsdsStat.cs - vygenerovane proxy tridy pro jednotlivé služby
Readme.txt - tento soubor

--------------------------------------------------------------------------------
Instalace
--------------------------------------------------------------------------------

- vytvorte adresar
- nakopirujte do neho soucasti projektu
- ve Visual studiu otevrete DemoISDS.csproj

--------------------------------------------------------------------------------
Preklad a spusteni
--------------------------------------------------------------------------------

Pro spusteni demonstracniho programu budete potrebovat prihlasovaci udaje k datove schrance. Primarne jsou cesty upraveny pro prostredi Verejneho testu, lze v kodu prepnout i pro Produkcni prostredi.

Pripadne dotazy a pripominky smerujte na: https://www.datoveschranky.info/kontakty/eporadna

--------------------------------------------------------------------------------
Moznosti prihlaseni
--------------------------------------------------------------------------------

Tento ukazkovy priklad demonstruje 3 zpusoby prihlaseni do datove schranky:

1. Jmenem a heslem - treba zadat uzivatelske jmeno a uzivatelske heslo
2. Jmenem, heslem a certifikatem - treba zadat uzivatelske jmeno, uzivatelske heslo a vybrat klientsky komercni ostry certifikat (ulozeny ve Windows store) 
3. Pomoci systemoveho certifikatu - je treba vybrat komercni ostry certifikat (ulozeny ve Windows store)

--------------------------------------------------------------------------------
Verze 3.3 z 18.11.2021
--------------------------------------------------------------------------------
- pridabo Expect100Continue = false pro odstranení problemu s komunikaci u velkých pozadavku po upgrade Apache na verzi 2.4.51  

--------------------------------------------------------------------------------
Verze 3.2 z 30.8.2018
--------------------------------------------------------------------------------
- pridano volani novych WS z wsdl 2.30 

--------------------------------------------------------------------------------
Verze 3.1
--------------------------------------------------------------------------------
- Přidáno vynucení komunikace přes TLS 1.2 pro bezproblémovou funkci pod Windows 7
- Aktualizováno pro .NET 4.7

--------------------------------------------------------------------------------
Verze z 17.6.2014
--------------------------------------------------------------------------------
- pridana ukazka prihlaeni pomoci klientskeho certfikatu
- obsahuje ukazku volani zakladnich WS v prostredi Verejneho testu:

DbSearchWebService - FindDataBox - vyhledani schranky
IsdsStatService - NumOfMessages - statistika dodanych zprav systemem ISDS
AccessWebService - GetOwnerInfoFromLogin - informace o schrance, do ktere jsme prihlaseni
AccessWebService - GetUserInfoFromLogin - informace o prihlasenem uzivateli
OperationsWebService - CreateMessage - vytvoreni a odeslani datove zpravy
OperationsWebService - SignedMessageDownload - stazeni datove zpravy v podepsanem tvaru
InfoWebService - GetListOfReceivedMessages - vylistovani dodanych zprav
InfoWebService - GetMessageStateChanges - zjisteni zmen stavu zprav

Toto je pouze ukazka pouziti nekolika zakladnich WS. Ostatni jsou popsany v 
prislusne dokumentaci.