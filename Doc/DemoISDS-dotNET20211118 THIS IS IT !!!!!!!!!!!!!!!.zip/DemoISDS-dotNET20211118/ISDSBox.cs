﻿/* Soucast ukazkoveho programu demonstrujiciho moznosti prace s datovymi schrankami v 3.3
*
* Pripadne dotazy a pripominky smerujte na: https://www.datoveschranky.info/kontakty/eporadna
*
* Tento soubor obsahuje zapouzdreni proxy trid pro praci s datovymi schrankami
*/

using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.IO;
using System.Threading;
using System.Security.Cryptography.X509Certificates;
using System.Web.Services.Protocols;

namespace ISDS {

    public enum PortalType {
        CZebox,
        Prod
    }

    public enum LoginType {
        Password,
        Cert,
        HostCert,
        UserCert
    }

    public enum ISDSServiceType {
        DmOperation,
        DmInfo,
        DbSearch,
        DbAccess,
        ISDSStat
    }

    /// <summary>
    /// Trida reprezentujici datovou schranku
    /// </summary>
    public class ISDSBox {
        private string LoginName = "";
        private string Password = "";
        private string CertFileName = "";
        private X509Certificate Certificate = null;

        private bool Connected = false;

        private dmInfoWebService InfoWebService;
        private dmOperationsWebService OperationsWebService;
        private DataBoxSearch DbSearchWebService;
        private DataBoxAccess AccessWebService;

        private LoginType loginType;
        private PortalType portalType = PortalType.CZebox;

        public static string BaseURI(PortalType PT, LoginType LT) {
            switch (PT) {
                case PortalType.Prod:
                    if (LT == LoginType.Password) {
                        return "ws1.mojedatovaschranka.cz";
                    }
                    else {
                        return "ws1c.mojedatovaschranka.cz";
                    }
                default:
                    if (LT == LoginType.Password) {
                        return "ws1.czebox.cz";
                    }
                    else {
                        return "ws1c.czebox.cz";
                    }
            }
        }

        private static string LoginSuffix(LoginType LT) {
            switch (LT) {
                case LoginType.Cert:
                    return "cert";
                case LoginType.HostCert:
                    return "hspis";
                case LoginType.UserCert:
                    return "certds";
                default:
                    return "";
            }
        }

        private static string ServiceSuffix(ISDSServiceType ST) {
            switch (ST) {
                case ISDSServiceType.DmInfo:
                    return "dx";
                case ISDSServiceType.DmOperation:
                    return "dz";
                case ISDSServiceType.DbSearch:
                    return "df";
                default:
                    return "DsManage";
            }
        }

        public static string GetISDSServiceURL(PortalType PT, LoginType LT, ISDSServiceType ST) {
            string S = LoginSuffix(LT);
            if (S == "") {
                return "https://" + BaseURI(PT, LT) + "/DS/" + ServiceSuffix(ST);
            }
            else {
                return "https://" + BaseURI(PT, LT) + "/" + S + "/DS/" + ServiceSuffix(ST);
            }
        }

        /// <summary>
        /// Adresa proxy serveru pokud se pouziva pro pripojeni (napr. 192.168.14.10)
        /// </summary>
        public string ProxyAddress = "";
        /// <summary>
        /// Pokud proxy server vyzaduje autentizaci, tak musi obsahovat prihlasovaci jmeno
        /// </summary>
        public string ProxyLoginName = "";
        /// <summary>
        /// Pokud proxy server vyzaduje autentizaci, tak musi obsahovat prihlasovaci heslo
        /// </summary>
        public string ProxyPassword = "";

        /// <summary>
        /// Univerzalni konstruktor pro testovaci aplikace
        /// </summary>
        /// <param name="LT">Typ pripojeni</param>
        /// <param name="PT">Portal ke kteremu se pripojujeme</param>
        /// <param name="LoginName">Prihlasovaci jmeno</param>
        /// <param name="Password">Heslo</param>
        /// <param name="CertFileName">Soubor s certifikatem</param>
        /// <param name="Certificate">Certifikat</param>
        public ISDSBox(LoginType LT, PortalType PT, string LoginName, string Password, string CertFileName, X509Certificate Certificate) {
            loginType = LT;
            portalType = PT;
            this.LoginName = LoginName;
            this.Password = Password;
            this.CertFileName = CertFileName;
            this.Certificate = Certificate;
        }

        /// <summary>
        /// Inicializacni procedura pro jednotlivou sluzbu
        /// </summary>
        /// <param name="WS"></param>
        private void InitializeService(SoapHttpClientProtocol WS, string URL) {
            WS.Url = URL;
            // Pri prihlasovani k ISDS dochazi k presmerovavani - to je treba povolit
            WS.AllowAutoRedirect = true;
            WS.UserAgent = "ISDS Basic .NET Sample 3.0";

            // Na Windows 7 je treba aplikaci zapnout TLS 1.2, pro Windows 10 komunikuje pres TLS 1.2 automaticky
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
			
			// Odstraneni problemoveho chovani Expect 100 continue - resí problem Apache 2.4.51 (listopad 2021)
			ServicePointManager.Expect100Continue = false;

            // vytvoreni cache pro povereni
            WS.Credentials = new NetworkCredential(LoginName, Password);
            WS.PreAuthenticate = true;

            // podpora proxy serveru
            if (ProxyAddress != "") {
                WebProxy WP = new WebProxy(ProxyAddress);
                if (ProxyLoginName != "") {
                    WP.Credentials = new NetworkCredential(ProxyLoginName, ProxyPassword);
                }
                WS.Proxy = WP;
            }

            if ((loginType == LoginType.Cert) || (loginType == LoginType.UserCert) || (loginType == LoginType.HostCert)) {
                if (Certificate == null) {
                    Certificate = X509Certificate.CreateFromCertFile(CertFileName);
                }
                WS.ClientCertificates.Add(Certificate);
            }
        }

        /// <summary>
        /// Inicializacni procedura
        /// </summary>
        public void Connect() {
            string InfoURL;
            string OperationURL;
            string AccessURL;
            string ManipulationURL;
            string ISDSStatUrl;
            Connect(out InfoURL, out OperationURL, out AccessURL, out ManipulationURL, out ISDSStatUrl);
        }

        public string[] GetServicesURL() {
            return new string[] {GetISDSServiceURL(portalType, loginType, ISDSServiceType.DmInfo),
                GetISDSServiceURL(portalType, loginType, ISDSServiceType.DmOperation),
                GetISDSServiceURL(portalType, loginType, ISDSServiceType.DbAccess),
                GetISDSServiceURL(portalType,loginType,ISDSServiceType.DbSearch),
                GetISDSServiceURL(portalType,loginType,ISDSServiceType.ISDSStat)
            };
        }

        public void Connect(out string InfoURL, out string OperationURL, out string AccessURL, out string ManipulationURL, out string ISDSStatUrl) {
            // system pouziva 5 webovych sluzeb
            InfoWebService = new dmInfoWebService();
            OperationsWebService = new dmOperationsWebService();
            AccessWebService = new DataBoxAccess();
            DbSearchWebService = new DataBoxSearch();

            InfoURL = GetISDSServiceURL(portalType, loginType, ISDSServiceType.DmInfo);
            OperationURL = GetISDSServiceURL(portalType, loginType, ISDSServiceType.DmOperation);
            AccessURL = GetISDSServiceURL(portalType, loginType, ISDSServiceType.DbAccess);
            ManipulationURL = GetISDSServiceURL(portalType, loginType, ISDSServiceType.DbSearch);
            ISDSStatUrl = GetISDSServiceURL(portalType, loginType, ISDSServiceType.ISDSStat);

            // inicializace jednotlivych sluzeb
            InitializeService(InfoWebService, InfoURL);
            InitializeService(OperationsWebService, OperationURL);
            InitializeService(AccessWebService, AccessURL);
            InitializeService(DbSearchWebService, ManipulationURL);

            Connected = true;
        }

        private void VerifyConnect() {
            if (!Connected) {
                Connect();
            }
        }

        /// <summary>
        /// Vyhleda schranku podle ukazkove struktury dbOwnerInfo, kde vyplni jen polozku nazev firmy a typ schranky.
        /// Nazev firmy musi mit alespon 3 pismena.
        /// </summary>
        public void FindDataBox() {
            VerifyConnect();
            
            //owner info pro vyhledani
            tDbOwnerInfoExt2 OwnerInfo = PrepareWantedOwnerInfo();
            tFindDBInput2 FindDBInput = new tFindDBInput2();
            tFindDBOuput2 FindDBOutput = new tFindDBOuput2();
            FindDBInput.dbOwnerInfo = OwnerInfo;
            

            Console.WriteLine("Ukazka volani WS pro vyhledani schranky.");
            try {
                FindDBOutput = DbSearchWebService.FindDataBox2(FindDBInput);
            }
            catch (Exception ex) {
                throw new Exception(string.Format("Pri volani metody FindDataBox webove sluzby ManipulationWebService doslo k vyjimce: {0}", ex.Message));
            }
            Console.WriteLine("Status volani: " + FindDBOutput.dbStatus.dbStatusMessage);
            if (FindDBOutput.dbStatus.dbStatusCode.StartsWith("0")) {
                PrintFindDbResult(FindDBOutput.dbResults.dbOwnerInfo);
            }
        }
        
        /// <summary>
        /// Vypise vybrane informace o datove schrance, do ktere jsme prihlaseni
        /// </summary>
        /// <returns></returns>
        public void GetOwnerInfoFromLogin2() {
            VerifyConnect();

            tDummyInput GetOwnInfoInput = new tDummyInput();
            tGetOwnInfoOutput2 GetOwnInfoOutput = new tGetOwnInfoOutput2();
            GetOwnInfoInput.dbDummy = "";
            

            Console.WriteLine("Ukazka volani WS pro ziskani informaci o schrance, do ktere jsme prihlaseni.");
            try {
                GetOwnInfoOutput = AccessWebService.GetOwnerInfoFromLogin2(GetOwnInfoInput);
            }
            catch (Exception ex) {
                throw new Exception(string.Format("Pri volani metody GetOwnerInfoFromLogin webove sluzby AccessWebService doslo k vyjimce: {0}", ex.Message));
            }
            Console.WriteLine("Status volani: " + GetOwnInfoOutput.dbStatus.dbStatusMessage);
            if (GetOwnInfoOutput.dbStatus.dbStatusCode.StartsWith("0")) {
                Console.WriteLine("Informace o schrance do niz jste prihlaseni:");
                tDbOwnerInfoExt2 owner = GetOwnInfoOutput.dbOwnerInfo;
                Console.WriteLine("ID schranky: " + owner.dbID);
                Console.WriteLine("Nazev: " + owner.firmName);
                Console.WriteLine("Typ: " + owner.dbType);
            }
        }

        /// <summary>
        /// Vypise vybrane informace o prihlasenem uzivateli
        /// </summary>
        /// <returns></returns>
        public void GetUserInfoFromLogin2() {
            VerifyConnect();

            tDummyInput UserInfoFromLoginDummyInput = new tDummyInput();
            tGetUserInfoOutput2 GetUserInfoFromLoginOutput = new tGetUserInfoOutput2();
            UserInfoFromLoginDummyInput.dbDummy = "";
            
            Console.WriteLine("Ukazka volani WS pro ziskani informaci o prihlasenem uzivateli.");
            try {
                GetUserInfoFromLoginOutput = AccessWebService.GetUserInfoFromLogin2(UserInfoFromLoginDummyInput);
            }
            catch (Exception ex) {
                throw new Exception(string.Format("Pri volani metody GetUserInfoFromLogin webove sluzby AccessWebService doslo k vyjimce: {0}", ex.Message));
            }
            Console.WriteLine("Status volani: " + GetUserInfoFromLoginOutput.dbStatus.dbStatusMessage);
            if (GetUserInfoFromLoginOutput.dbStatus.dbStatusCode.StartsWith("0")) {
                Console.WriteLine("Informace o prihlasenem uzivateli:");
                tDbUserInfoExt2 user = GetUserInfoFromLoginOutput.dbUserInfo;
                Console.WriteLine("ISDS ID uzivatele: " + user.isdsID);
                Console.WriteLine("Prijmeni: " + user.pnLastName);
                Console.WriteLine("Jmena: " + user.pnGivenNames);
                Console.WriteLine("Datum narozeni: " + user.biDate);
            }
        }

        /// <summary>
        /// Vytvori datovou zpravu a odesle ji do dane schranky
        /// </summary>
        /// <param name="RecipientId">ID datove schranky prijemce zpravy</param>
        public void createMessage(string RecipientId) {
            VerifyConnect();

            tMessageCreateInput CreateMessageInput = new tMessageCreateInput();
            tMessageCreateOutput CreateMessageOutput = new tMessageCreateOutput();

            CreateMessageInput.dmFiles = PrepareMessageEnclosureFiles();
            CreateMessageInput.dmEnvelope = PrepareMessageEnvelope(RecipientId);
            
            Console.WriteLine("Ukazka volani WS pro vytvoreni datove zpravy.");
            try {
                CreateMessageOutput = OperationsWebService.CreateMessage(CreateMessageInput);
            }
            catch (Exception ex) {
                throw new Exception(string.Format("Pri volani metody CreateMessage webove sluzby OperationsWebService doslo k vyjimce: {0}", ex.Message));
            }
            Console.WriteLine("Status volani: " + CreateMessageOutput.dmStatus.dmStatusMessage);
            if (CreateMessageOutput.dmStatus.dmStatusCode.StartsWith("0")) {
                Console.WriteLine("Zprava odeslana. ID zpravy: " + CreateMessageOutput.dmID);
            }
        }

        /// <summary>
        /// Stazeni seznamu doslych zprav urceneho casovym intervalem, 
        /// zpresnenim organizacni jednotky adresata (pouze ESS), filtrem na stav zprav 
        /// a usekem poradovych cisel zaznamu
        /// <returns>Id prvni zpravy ze seznamu dodanych zprav</returns>
        public string GetListOfReceivedMessages() {
            VerifyConnect();

            tListOfFReceivedInput ListOfRecivedMessagesInput = new tListOfFReceivedInput();
            tListOfMessOutput ListOfMessagesOutput = new tListOfMessOutput();

            //Konec casoveho intervalu z nehoz maji byt zpravy nacteny - "ted"
            ListOfRecivedMessagesInput.dmToTime = DateTime.Now;
            //Pocatek casoveho intervalu z nehoz maji byt zpravy nacteny - "pred tydnem"
            ListOfRecivedMessagesInput.dmFromTime = DateTime.Now.AddDays(-7); ;
            //Cislo prvniho pozadovaneho zaznamu
            ListOfRecivedMessagesInput.dmOffset = "1";
            //Filtr na stav zpravy. Hodnota -1 vrati vsechny zpravy.
            ListOfRecivedMessagesInput.dmStatusFilter = "-1";
            //Pocet pozadovanych zaznamu
            ListOfRecivedMessagesInput.dmLimit = "100";
            ListOfRecivedMessagesInput.dmRecipientOrgUnitNum = null;
            
            Console.WriteLine("Ukazka stazeni seznamu dodanych zprav.");
            Console.WriteLine("od: " + ListOfRecivedMessagesInput.dmFromTime);
            Console.WriteLine("do: " + ListOfRecivedMessagesInput.dmToTime);
            
            try {
                ListOfMessagesOutput = InfoWebService.GetListOfReceivedMessages(ListOfRecivedMessagesInput);
            }
            catch (Exception ex) {
                throw new Exception(string.Format("Pri volani metody GetListOfReceivedMessages webove sluzby InfoWebService doslo k vyjimce: {0}", ex.Message));
            }
            string firstMessageId = null;
            Console.WriteLine("Status volani: " + ListOfMessagesOutput.dmStatus.dmStatusMessage);
            if (ListOfMessagesOutput.dmStatus.dmStatusCode.StartsWith("0")) {
                firstMessageId = PrintRecivedMessages(ListOfMessagesOutput.dmRecords.dmRecord);
            }
            return firstMessageId;
        }

        /// <summary>
        /// Stazeni podepsane prijate zpravy
        /// </summary>
        /// <param name="MessageID">Identifikace zpravym kterou chceme stahnout</param>
        public void SignedMessageDownload(string MessageID) {
            VerifyConnect();

            tIDMessInput MessageIDInput = new tIDMessInput();
            tSignedMessDownOutput SignedMsgOutput = new tSignedMessDownOutput();
            MessageIDInput.dmID = MessageID;
            
            Console.WriteLine("Ukazka volani WS pro stazeni podepsane zpravy.");
            try {
                SignedMsgOutput = OperationsWebService.SignedMessageDownload(MessageIDInput);
            }
            catch (Exception ex) {
                throw new Exception(string.Format("Pri volani metody SignedMessageDownload webove sluzby OperationsWebService doslo k vyjimce: {0}", ex.Message));
            }
            Console.WriteLine("Status volani: " + SignedMsgOutput.dmStatus.dmStatusMessage);
            if (SignedMsgOutput.dmStatus.dmStatusCode.StartsWith("0")) {
                string fileName = "message_content_net.zfo";
                string curDir = Directory.GetCurrentDirectory();
                File.WriteAllBytes(fileName, SignedMsgOutput.dmSignature);
                Console.WriteLine("Zprava ulozena do: " + curDir + "\\" + fileName);
            }
        }

        /// <summary>
        /// Vrati seznam zmen stavu odeslanych zprav za urcite obdobi.
        /// </summary>
        public void GetMessagesChanges() {
            VerifyConnect();

            tGetStateChangesInput StateChangesInput = new tGetStateChangesInput();
            tGetStateChangesOutput StateChanegesOutput = new tGetStateChangesOutput();
            StateChangesInput.dmToTime = DateTime.Now;
            StateChangesInput.dmFromTime = DateTime.Now.AddDays(-7);

            Console.WriteLine("Ukazka volani WS pro zjisteni zmen stavu zprav.");
            Console.WriteLine("od: " + StateChangesInput.dmFromTime);
            Console.WriteLine("do: " + StateChangesInput.dmToTime);
            try {
                StateChanegesOutput = InfoWebService.GetMessageStateChanges(StateChangesInput);
            }
            catch (Exception ex) {
                throw new Exception(string.Format("Pri volani metody GetMessageStateChanges webove sluzby OperationWebService doslo k vyjimce: {0}", ex.Message));
            }
            Console.WriteLine("Status volani: " + StateChanegesOutput.dmStatus.dmStatusMessage);
            if (StateChanegesOutput.dmStatus.dmStatusCode.StartsWith("0")) {
                PrintMsgsStateChanges(StateChanegesOutput.dmRecords.dmRecord);
            }
        }

        /*
         * POMOCNE METODY
         */
        /// <summary>
        /// Pripravi OwnerInfo pro vyhledani.
        /// </summary>
        /// <returns>Owner info schranky pro vyhledani</returns>
        public static tDbOwnerInfoExt2 PrepareWantedOwnerInfo() {
            tDbOwnerInfoExt2 OwnerInfo = new tDbOwnerInfoExt2();
            //informace pro vyhledani
            OwnerInfo.dbType = tDbType.OVM;
            OwnerInfo.firmName = "Ministerstvo vnitra"; OwnerInfo.adCity = "";
            
            //ostatni prazdne
            OwnerInfo.adNumberInMunicipality = "";
            OwnerInfo.adNumberInStreet = "";
            OwnerInfo.adState = "";
            OwnerInfo.adStreet = "";
            OwnerInfo.adZipCode = "";
            OwnerInfo.biCity = "";
            OwnerInfo.biCounty = "";
            OwnerInfo.biState = "";
            OwnerInfo.dbID = "";
            OwnerInfo.ic = "";
            OwnerInfo.nationality = "";
            OwnerInfo.pnGivenNames = "";
            OwnerInfo.pnLastName = "";

            return OwnerInfo;
        }

        /// <summary>
        /// Vypise vybrane informace o vyhledanych schrankach.
        /// </summary>
        public static void PrintFindDbResult(tDbOwnerInfoExt2[] result) {
            if (result != null) {
                Console.WriteLine("Pocet vyhledanych schranek: " + result.Length);
                foreach (tDbOwnerInfoExt2 OwnInfo in result) {
                    Console.WriteLine("Nazev: " + OwnInfo.firmName + ", ID schranky: " + OwnInfo.dbID);
                }
            }
            else {
                Console.WriteLine("Pocet vyhledanych schranek: 0");
            }
        }

        /// <summary>
        /// Pripravi prilohu pro datovou zpravu.
        /// </summary>
        /// <returns>Priloha datove zpravy</returns>
        public static tFilesArrayDmFile[] PrepareMessageEnclosureFiles() {
            tFilesArrayDmFile DmFile = new tFilesArrayDmFile();
            DmFile.dmFileDescr = "test.txt";
            DmFile.dmFileGuid = "";
            DmFile.dmFileMetaType = tFilesArrayDmFileDmFileMetaType.main;
            DmFile.dmFormat = "";
            DmFile.dmMimeType = "text/plain";
            DmFile.dmFileGuid = "";
            DmFile.Item = Encoding.UTF8.GetBytes("Obsah testovaciho souboru v UTF-8.");
            tFilesArrayDmFile[] FilesArray = { DmFile };
            return FilesArray;
        }

        /// <summary>
        /// Pripravy obalku datove zpravy.
        /// </summary>
        /// <returns>Obalka datove zpravy</returns>
        public static tMessageCreateInputDmEnvelope PrepareMessageEnvelope(string RecipientId) {
            tMessageCreateInputDmEnvelope MessageEnvelope = new tMessageCreateInputDmEnvelope();

            MessageEnvelope.dbIDRecipient = RecipientId;
            MessageEnvelope.dmAllowSubstDelivery = false;
            MessageEnvelope.dmAnnotation = "Testovaci zprava";
            MessageEnvelope.dmLegalTitleLaw = "677";
            MessageEnvelope.dmLegalTitlePar = "231";
            MessageEnvelope.dmLegalTitlePoint = "179";
            MessageEnvelope.dmLegalTitleSect = "331";
            MessageEnvelope.dmLegalTitleYear = "2010";
            MessageEnvelope.dmPersonalDelivery = false;
            MessageEnvelope.dmRecipientIdent = "VZ-147";
            MessageEnvelope.dmRecipientOrgUnit = "Vase org. jednotka";
            MessageEnvelope.dmRecipientOrgUnitNum = "-1";
            MessageEnvelope.dmRecipientRefNumber = "vcj. 253";
            MessageEnvelope.dmSenderIdent = "NZ-557";
            MessageEnvelope.dmSenderOrgUnit = "Nase org. jednotka";
            MessageEnvelope.dmSenderRefNumber = "ncj. 589";
            MessageEnvelope.dmToHands = "K rukam p. Novaka";

            return MessageEnvelope;
        }

        /// <summary>
        /// Vypise seznam zmen stavu odeslanych zprav.
        /// </summary>
        public static void PrintMsgsStateChanges(tStateChangesRecord[] changes) {
            if (changes != null) {
                Console.WriteLine("Pocet obdrzenych zmen stavu zprav: " + changes.Length);
                foreach (tStateChangesRecord change in changes) {
                    Console.WriteLine("ID zpravy " + change.dmID + "; cas zmeny " + change.dmEventTime + "; stav " + change.dmMessageStatus);
                }
            }
            else {
                Console.WriteLine("Pocet obdrzenych zmen stavu zprav: 0");
            }
        }
        /// <summary>
        /// Vypise seznam dodanych zprav.
        /// </summary>
        /// <param name="dmRecords">Pole zaznamu - dodanych zprav</param>
        /// <returns>id 1. zpravy v seznamu</returns>
        public static string PrintRecivedMessages(tRecord[] dmRecords) {
            string firstMessageId = null;
            if (dmRecords != null) {
                Console.WriteLine("Pocet dodanych zprav: " + dmRecords.Length);
                foreach (tRecord record in dmRecords) {
                    if (firstMessageId == null) {
                        firstMessageId = record.dmID;
                    }

                    Console.WriteLine("ID : " + record.dmID + "; stav: " + record.dmMessageStatus +
                        "; adresa odesilatele: " + record.dmSenderAddress + "; ID odesilatele: " + record.dbIDSender +
                        "; dorucena: " + record.dmAcceptanceTime + "; dodana: " + record.dmDeliveryTime
                        );
                }
            }
            else {
                Console.WriteLine("Pocet dodanych zprav: 0");
            }
            return firstMessageId;
        }
    }
}
