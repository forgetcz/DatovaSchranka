﻿/* Ukazkovy program (konzolova aplikace) demonstrujici moznosti prace s datovymi schrankami v 3.2
 *
 * Pripadne dotazy a pripominky smerujte na: https://www.datoveschranky.info/kontakty/eporadna
 */
using System;
using System.Text;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using ISDS;

namespace DemoISDS {
    class Program {
        /// <summary>
        /// Objekt reprezentujici pripojeni k prvni datove schrance
        /// </summary>
        static ISDSBox DataBox = null;
        static string LoginName1 = "";
        static string Password1 = "";
        static X509Certificate Certificate1 = null;

        /// <summary>
        /// Pomocna metoda
        /// </summary>
        static void Exit() {
            Console.WriteLine("Pro ukonceni programu stisknete <ENTER>");
            Console.ReadLine();
        }

        /// <summary>
        /// Pomocna metoda
        /// </summary>
        static void Separator() {
            Console.WriteLine("--------------------------------------------------------------------------");
        }

        /// <summary>
        /// Vyber certifikatu z uloziste
        /// </summary>
        /// <returns></returns>
        static X509Certificate SelectX509Certificate() {
            X509Store Store = new X509Store();
            Store.Open(OpenFlags.ReadOnly);
            X509CertificateCollection StoreCollection = (X509CertificateCollection)Store.Certificates;
            int NumOf = StoreCollection.Count;
            Console.WriteLine("Ve Vasem úlozisti se nachazeji tyto certifikaty:");
            for (int i = 0; i < NumOf; i++) {
                writeGreen(""+i);
                Console.WriteLine("{0}", StoreCollection[i].Subject);
            }
            Console.WriteLine();
            int CertNum = -1;
            do {
                Console.WriteLine("Zadejte cislo certifikatu se kterym se chcete pripojit a stisknete <Enter>");
                try {
                    CertNum = Convert.ToInt32(Console.ReadLine());
                }
                catch {
                }
            } while ((CertNum < 0) || (CertNum >= NumOf));
            return StoreCollection[CertNum];
        }

        static LoginType SelectLoginTyperNr() {
            writeGreen("0");
            Console.WriteLine("uzivatelskym jmenem a heslem");
            writeGreen("1");
            Console.WriteLine("klientskym certifikatem, jmenem a heslem");
            writeGreen("2");
            Console.WriteLine("systemovym certifikatem");
            Console.WriteLine();
            int logTypeNr = -1;
            do {
                Console.WriteLine("Zadejte cislo zpusobu, kterym se chcete prihlasit a stisknete <Enter>");
                try {
                    logTypeNr = Convert.ToInt32(Console.ReadLine());
                }
                catch {
                }
            } while ((logTypeNr < 0) || (logTypeNr >= 3));

            switch (logTypeNr) {
                case 0: return LoginType.Password;
                case 1: return LoginType.UserCert;
                case 2: return LoginType.Cert;
                default: return LoginType.Password; // nikdy nenastane
            }
        }

        static void writeGreen(String str){
                        ConsoleColor CC = Console.ForegroundColor;
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("{0} ", str);
                Console.ForegroundColor = CC;
        }

        /// <summary>
        /// Hlavni procedura programu
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args) {
            Console.WriteLine("Ukazkovy program demonstrujici moznosti prace s datovymi schrankami");
            Console.WriteLine("Mozne zpusoby pro prihlaseni do datove schranky jsou nasledujici:");
            LoginType LT = SelectLoginTyperNr();

            if (LT != LoginType.Cert) { // je treba jmeno a heslo
                Console.WriteLine();
                Console.Write("Zadejte prihlasovaci jmeno k datove schrance a stisknete <Enter>: ");
                LoginName1 = Console.ReadLine();
                Console.Write("Zadejte heslo k datove schrance a stisknete <Enter>: ");
                ConsoleColor CC = Console.ForegroundColor;
                Console.ForegroundColor = ConsoleColor.Black;
                Console.CursorVisible = false;
                Password1 = Console.ReadLine();
                Console.ForegroundColor = CC;
                Console.CursorVisible = true;
            }
            if (LT != LoginType.Password) { // je treba certifikat
                Console.WriteLine();
                Certificate1 = SelectX509Certificate();
            }

            try {
                Console.WriteLine("Probiha nastaveni parametru pro pripojeni k datove schrance...");
                DataBox = new ISDSBox(LT, PortalType.CZebox, LoginName1, Password1, "", Certificate1);
                DataBox.Connect();
                Console.WriteLine("Nastaveni probehlo v poradku.\n");
            }
            catch (Exception ex) {
                Console.WriteLine("Behem nastavovani parametru doslo k vyjimce: " + ex.Message);
                Exit();
                return;
            }

            //ukazky volani WS
            try {
                //vyhledani schranky
                DataBox.FindDataBox();
                Separator();


                //informace o schrance do niz jsme prihlaseni.
                DataBox.GetOwnerInfoFromLogin2();
                Separator();

                //informace o prihlasenem uzivateli
                DataBox.GetUserInfoFromLogin2();
                Separator();

                //vytvori a odesle datovou zpravu
                DataBox.createMessage("sem doplnte ID schranky prijemce");
                Separator();

                //vylistuje seznam dodanych zprav za posledni tyden
                string MessId = DataBox.GetListOfReceivedMessages();
                Separator();

                //ulozi zpravu v podepsanem tvaru do souboru
                if (MessId != null) {
                    DataBox.SignedMessageDownload(MessId);
                    Separator();
                }

                //zmeny stavu zprav za posledni tyden
                DataBox.GetMessagesChanges();
            }
            catch (Exception ex) {
                Console.WriteLine(ex.Message);
                Exit();
                return;
            }
        }
    }
}
