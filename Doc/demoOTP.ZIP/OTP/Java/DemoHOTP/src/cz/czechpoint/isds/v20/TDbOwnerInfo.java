
package cz.czechpoint.isds.v20;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * typ pro ve�ker� informace o DS, pro n�kter� typy budou n�kter� elementy nevypln�n�
 * 
 * <p>Java class for tDbOwnerInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tDbOwnerInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="dbID" type="{http://isds.czechpoint.cz/v20}tIdDb"/>
 *         &lt;element name="dbType" type="{http://isds.czechpoint.cz/v20}tDbType"/>
 *         &lt;element name="ic" type="{http://isds.czechpoint.cz/v20}tIdentificationNumber"/>
 *         &lt;group ref="{http://isds.czechpoint.cz/v20}gPersonName"/>
 *         &lt;element name="firmName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;group ref="{http://isds.czechpoint.cz/v20}gBirthInfo"/>
 *         &lt;group ref="{http://isds.czechpoint.cz/v20}gAddress"/>
 *         &lt;element name="nationality" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="email" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="telNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="identifier">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="registryCode">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="5"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="dbState" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *         &lt;element name="dbEffectiveOVM" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="dbOpenAddressing" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tDbOwnerInfo", propOrder = {
    "dbID",
    "dbType",
    "ic",
    "pnFirstName",
    "pnMiddleName",
    "pnLastName",
    "pnLastNameAtBirth",
    "firmName",
    "biDate",
    "biCity",
    "biCounty",
    "biState",
    "adCity",
    "adStreet",
    "adNumberInStreet",
    "adNumberInMunicipality",
    "adZipCode",
    "adState",
    "nationality",
    "email",
    "telNumber",
    "identifier",
    "registryCode",
    "dbState",
    "dbEffectiveOVM",
    "dbOpenAddressing"
})
public class TDbOwnerInfo {

    @XmlElement(required = true, nillable = true)
    protected String dbID;
    @XmlElement(required = true, nillable = true)
    protected TDbType dbType;
    @XmlElement(required = true, nillable = true)
    protected String ic;
    @XmlElement(required = true, nillable = true)
    protected String pnFirstName;
    @XmlElement(required = true, nillable = true)
    protected String pnMiddleName;
    @XmlElement(required = true, nillable = true)
    protected String pnLastName;
    @XmlElement(required = true, nillable = true)
    protected String pnLastNameAtBirth;
    @XmlElement(required = true, nillable = true)
    protected String firmName;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar biDate;
    @XmlElement(required = true, nillable = true)
    protected String biCity;
    @XmlElement(required = true, nillable = true)
    protected String biCounty;
    @XmlElement(required = true, nillable = true)
    protected String biState;
    @XmlElement(required = true, nillable = true)
    protected String adCity;
    @XmlElement(required = true, nillable = true)
    protected String adStreet;
    @XmlElement(required = true, nillable = true)
    protected String adNumberInStreet;
    @XmlElement(required = true, nillable = true)
    protected String adNumberInMunicipality;
    @XmlElement(required = true, nillable = true)
    protected String adZipCode;
    @XmlElement(required = true, nillable = true)
    protected String adState;
    @XmlElement(required = true, nillable = true)
    protected String nationality;
    @XmlElement(nillable = true)
    protected String email;
    @XmlElement(nillable = true)
    protected String telNumber;
    @XmlElement(required = true, nillable = true)
    protected String identifier;
    @XmlElement(required = true, nillable = true)
    protected String registryCode;
    @XmlElement(required = true, nillable = true)
    protected BigInteger dbState;
    @XmlElement(required = true, type = Boolean.class, nillable = true)
    protected Boolean dbEffectiveOVM;
    @XmlElement(required = true, type = Boolean.class, nillable = true)
    protected Boolean dbOpenAddressing;

    /**
     * Gets the value of the dbID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbID() {
        return dbID;
    }

    /**
     * Sets the value of the dbID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbID(String value) {
        this.dbID = value;
    }

    /**
     * Gets the value of the dbType property.
     * 
     * @return
     *     possible object is
     *     {@link TDbType }
     *     
     */
    public TDbType getDbType() {
        return dbType;
    }

    /**
     * Sets the value of the dbType property.
     * 
     * @param value
     *     allowed object is
     *     {@link TDbType }
     *     
     */
    public void setDbType(TDbType value) {
        this.dbType = value;
    }

    /**
     * Gets the value of the ic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIc() {
        return ic;
    }

    /**
     * Sets the value of the ic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIc(String value) {
        this.ic = value;
    }

    /**
     * Gets the value of the pnFirstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPnFirstName() {
        return pnFirstName;
    }

    /**
     * Sets the value of the pnFirstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPnFirstName(String value) {
        this.pnFirstName = value;
    }

    /**
     * Gets the value of the pnMiddleName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPnMiddleName() {
        return pnMiddleName;
    }

    /**
     * Sets the value of the pnMiddleName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPnMiddleName(String value) {
        this.pnMiddleName = value;
    }

    /**
     * Gets the value of the pnLastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPnLastName() {
        return pnLastName;
    }

    /**
     * Sets the value of the pnLastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPnLastName(String value) {
        this.pnLastName = value;
    }

    /**
     * Gets the value of the pnLastNameAtBirth property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPnLastNameAtBirth() {
        return pnLastNameAtBirth;
    }

    /**
     * Sets the value of the pnLastNameAtBirth property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPnLastNameAtBirth(String value) {
        this.pnLastNameAtBirth = value;
    }

    /**
     * Gets the value of the firmName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFirmName() {
        return firmName;
    }

    /**
     * Sets the value of the firmName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFirmName(String value) {
        this.firmName = value;
    }

    /**
     * Gets the value of the biDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getBiDate() {
        return biDate;
    }

    /**
     * Sets the value of the biDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setBiDate(XMLGregorianCalendar value) {
        this.biDate = value;
    }

    /**
     * Gets the value of the biCity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBiCity() {
        return biCity;
    }

    /**
     * Sets the value of the biCity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBiCity(String value) {
        this.biCity = value;
    }

    /**
     * Gets the value of the biCounty property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBiCounty() {
        return biCounty;
    }

    /**
     * Sets the value of the biCounty property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBiCounty(String value) {
        this.biCounty = value;
    }

    /**
     * Gets the value of the biState property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBiState() {
        return biState;
    }

    /**
     * Sets the value of the biState property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBiState(String value) {
        this.biState = value;
    }

    /**
     * Gets the value of the adCity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdCity() {
        return adCity;
    }

    /**
     * Sets the value of the adCity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdCity(String value) {
        this.adCity = value;
    }

    /**
     * Gets the value of the adStreet property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdStreet() {
        return adStreet;
    }

    /**
     * Sets the value of the adStreet property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdStreet(String value) {
        this.adStreet = value;
    }

    /**
     * Gets the value of the adNumberInStreet property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdNumberInStreet() {
        return adNumberInStreet;
    }

    /**
     * Sets the value of the adNumberInStreet property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdNumberInStreet(String value) {
        this.adNumberInStreet = value;
    }

    /**
     * Gets the value of the adNumberInMunicipality property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdNumberInMunicipality() {
        return adNumberInMunicipality;
    }

    /**
     * Sets the value of the adNumberInMunicipality property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdNumberInMunicipality(String value) {
        this.adNumberInMunicipality = value;
    }

    /**
     * Gets the value of the adZipCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdZipCode() {
        return adZipCode;
    }

    /**
     * Sets the value of the adZipCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdZipCode(String value) {
        this.adZipCode = value;
    }

    /**
     * Gets the value of the adState property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdState() {
        return adState;
    }

    /**
     * Sets the value of the adState property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdState(String value) {
        this.adState = value;
    }

    /**
     * Gets the value of the nationality property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNationality() {
        return nationality;
    }

    /**
     * Sets the value of the nationality property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNationality(String value) {
        this.nationality = value;
    }

    /**
     * Gets the value of the email property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the value of the email property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmail(String value) {
        this.email = value;
    }

    /**
     * Gets the value of the telNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTelNumber() {
        return telNumber;
    }

    /**
     * Sets the value of the telNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTelNumber(String value) {
        this.telNumber = value;
    }

    /**
     * Gets the value of the identifier property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdentifier() {
        return identifier;
    }

    /**
     * Sets the value of the identifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdentifier(String value) {
        this.identifier = value;
    }

    /**
     * Gets the value of the registryCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegistryCode() {
        return registryCode;
    }

    /**
     * Sets the value of the registryCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegistryCode(String value) {
        this.registryCode = value;
    }

    /**
     * Gets the value of the dbState property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getDbState() {
        return dbState;
    }

    /**
     * Sets the value of the dbState property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setDbState(BigInteger value) {
        this.dbState = value;
    }

    /**
     * Gets the value of the dbEffectiveOVM property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDbEffectiveOVM() {
        return dbEffectiveOVM;
    }

    /**
     * Sets the value of the dbEffectiveOVM property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDbEffectiveOVM(Boolean value) {
        this.dbEffectiveOVM = value;
    }

    /**
     * Gets the value of the dbOpenAddressing property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDbOpenAddressing() {
        return dbOpenAddressing;
    }

    /**
     * Sets the value of the dbOpenAddressing property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDbOpenAddressing(Boolean value) {
        this.dbOpenAddressing = value;
    }

}
