
package cz.czechpoint.isds.v20;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for tChngPasswInput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tChngPasswInput">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="dbOldPassword" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="dbNewPassword" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tChngPasswInput", propOrder = {
    "dbOldPassword",
    "dbNewPassword"
})
public class TChngPasswInput {

    @XmlElement(required = true)
    protected String dbOldPassword;
    @XmlElement(required = true)
    protected String dbNewPassword;

    /**
     * Gets the value of the dbOldPassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbOldPassword() {
        return dbOldPassword;
    }

    /**
     * Sets the value of the dbOldPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbOldPassword(String value) {
        this.dbOldPassword = value;
    }

    /**
     * Gets the value of the dbNewPassword property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbNewPassword() {
        return dbNewPassword;
    }

    /**
     * Sets the value of the dbNewPassword property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbNewPassword(String value) {
        this.dbNewPassword = value;
    }

}
