package demohotp;

import java.io.Console;

/**
 * Trida pro uchovani uzivatelskeho jmena, hesla a HOTP kodu
 */
public class Credentials {

  private String login = "";
  private String password = "";
  private String hotpCode = "";

  /**
   * @return the login
   */
  public String getLogin() {
    return login;
  }

  /**
   * @return the password
   */
  public String getPassword() {
    return password;
  }

  /**
   * @return the HOTP Code
   */
  public String getHotpCode() {
    return hotpCode;
  }

  public void readCredentials() {
    System.out.println("\r\nTohle je priklad nacteni prihlasovacich udaju. " +
            "Ulozeni jmena a hesla primo ve zdrojovem kodu aplikace neni bezpecne.\r\n");

    Console console = System.console();
    if (console == null) {
      throw new Error("Toto nacteni udaju funguje jen pri spusteni programu " +
              "v prikazovem radku (cmd.exe, bash).\r\n");
    }

    login = console.readLine("Zadejte prihlasovaci jmeno: ");
    password = new String(console.readPassword("Zadejte heslo: "));
    hotpCode = console.readLine("Zadejte HOTP kod: ");

  }
}
