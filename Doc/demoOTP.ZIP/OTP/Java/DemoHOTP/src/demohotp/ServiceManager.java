package demohotp;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.*;
import java.util.List;
import javax.net.ssl.HttpsURLConnection;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.MessageContext;


public class ServiceManager {

  private final int MAX_REDIRECT_CNT = 20;
  // timeout cookie, po nem je treba znovu cookie ziskat. Nastaven na 30 minut
  private static final int COOKIE_TIMEOUT_MS = 30 * 60 * 1000;
  private String reqBaseURI = null;
  // kontejner pro cookie ziskanych pri prihlasovani
  private CookiesContainer cookiesContainer = new CookiesContainer();
  //auth. cookie
  private String authCookie = null;
  private Date authCookieTime = null;

  public ServiceManager(String uri) {
    this.reqBaseURI = uri;
  }

  /**
   * Provede pozadavek pomoci http knihovny a ziska autentizacni cookie a ulozi ji do <code>authCookie</code> jako
   * retezec. Postup je nasledujici:
   * 1. Zasle http pozadavek s modifikovanou basic autentizaci (jmeno + heslo + hotp kod)
   * 2. Ziska auth. cookie a ulozi ji pro dalsi pouziti
   * @param cr credentials
   * @throws MalformedURLException
   * @throws IOException
   * @throws URISyntaxException
   */
  public void obtainAuthCookie(Credentials cr, String serviceSuffix) throws MalformedURLException, IOException, URISyntaxException {

    //url pro presmerovani
    String redirectUrl = null;
    int responseCode = 0;
    //mnozina jiz navsivenych URL - pro detekci cyklickeho presmerovavani
    HashSet<String> usedUrls = new HashSet<String>();

    //url pro pozadavek na autentizaci HOTP kodem
    URL requestUrl = new URL(reqBaseURI + "/as/processLogin?type=hotp&uri=" + reqBaseURI + serviceSuffix);

    // najdi cookie platne pro dane url
    String cookies = cookiesContainer.getCookieHeaderValueForUrl(requestUrl);

    //HTTPS connection
    HttpsURLConnection connection = (HttpsURLConnection) requestUrl.openConnection();


    //autentizacni hlavicka modifikovane basic autentizace s HOTP kodem
    //Basic autentizace BASE64 z retezce"login:heslo+HOTPkod"

    //jmeno:heslo+hotpCode
    String basicPwd = cr.getLogin() + ":" + cr.getPassword() + cr.getHotpCode();
    //vytvoreni stringu autentizacni hlavicky ve tvaru: Basic + prevod do BASE64
    String basicAuthStr = "Basic " + new sun.misc.BASE64Encoder().encode(basicPwd.getBytes());

    for (int i = 0; i < MAX_REDIRECT_CNT; i++) {

      //HTTPS connection
      connection = (HttpsURLConnection) requestUrl.openConnection();
      //nastaveni basic autentizace pozadavku o kodem
      connection.setRequestProperty("Authorization", basicAuthStr);
      connection.setRequestProperty("Content-Type", "text/xml");
      connection.setRequestProperty("Content-Length", "0");
      connection.setRequestProperty("Cache-Control", "no-cache");

      try {
        //sestaveni POST pozadavku
        connection.setRequestMethod("POST");
        connection.setDoOutput(true);
        connection.setInstanceFollowRedirects(false);

        // najdi cookie platne pro dane url
        cookies = cookiesContainer.getCookieHeaderValueForUrl(requestUrl);

        //jestli jsou, tak nastav
        if (cookies != null) {
          connection.setRequestProperty("Cookie", cookies);
        }

        //precteni hlavicek odpovedi
        //presmerovani
        redirectUrl = connection.getHeaderField("Location");

        //uchovej si prijate cookie
        List<String> sclist = connection.getHeaderFields().get("Set-Cookie");
        if (sclist != null) {
          for (String setCookieValue : sclist) {
            if (setCookieValue != null) {
              Cookie cookie = new Cookie(setCookieValue);
              cookiesContainer.addCookie(cookie);
            }
          }
        }

        //kod odpovedi
        responseCode = connection.getResponseCode();
        if (responseCode == 200 || cookiesContainer.getCookie("IPCZ") != null) { //OK nebo jsme jiz obdrzeli auth cookie
          break;
        } else if ((responseCode == 302 || responseCode == 301) && redirectUrl != null) { //redirect
          requestUrl = new URL(redirectUrl);

          //byli jsme presmerovani na jiz navstivenou URL
          if (usedUrls.contains(redirectUrl)) {
            System.out.println("Cyklicky redirect.");
          }
          usedUrls.add(redirectUrl);
        } else if (responseCode == 401) { // unauthorized
          System.out.println("Unathorized (401)");
          break;
        } else { //ostatni
          System.out.println("Neocekavana odpoved.");
          break;
        }
      } finally {
        if (connection != null) {
          connection.disconnect();
        }
      }
      //nastavime URL pozadavku na presmerovanou URL
      requestUrl = new URL(redirectUrl);
    }

    // z kontejneru si vyjmeme auth. cookie a upravime ji pro vkladani do hlavicek dalsich requestu
    Cookie ipcz = cookiesContainer.getCookie("IPCZ");
    //ulozime ji do authCookie pro dalsi pouziti
    authCookie = ipcz.name + "=" + ipcz.value;
  }

  /**
   * Prida k webove sluzbe do request hlavicek autentizacni cookie.
   * @param provider port webove sluzby.
   */
  private void addAuthCookie(BindingProvider provider) {
    Map requestContext = provider.getRequestContext();
    requestContext.put(BindingProvider.SESSION_MAINTAIN_PROPERTY, true);

    Map<String, List> requestHeaders = new HashMap<String, List>();
    List cookies = new ArrayList();

    String cs = authCookie;
    cookies.add(cs);

    List accept = new ArrayList();
    accept.add("text/xml");

    requestHeaders.put("Cookie", cookies);
    requestContext.put(MessageContext.HTTP_REQUEST_HEADERS, requestHeaders);
  }

  /**
   * Nastavi autentizacni cookie. Pro autentizaci vyuzije jmeno, heslo a HOTP kod.
   * @param provider proxy webove sluzby.
   * @param cr pristupove udaje
   * @throws java.lang.Exception
   */
  public void authenticate(BindingProvider provider, Credentials cr, String serviceSuffix)
          throws NoSuchAlgorithmException, KeyStoreException, FileNotFoundException, IOException,
          CertificateException, UnrecoverableKeyException, KeyManagementException,
          MalformedURLException, ServiceException, URISyntaxException {

    Date now = new Date();
    if (authCookie == null ||
            cookiesContainer == null ||
            authCookieTime == null ||
            authCookieTime.getTime() + COOKIE_TIMEOUT_MS < now.getTime()) {
      obtainAuthCookie(cr, serviceSuffix);
      authCookieTime = now;
    }

    if (provider != null) {
      addAuthCookie(provider);
    }
  }

  /**
   * Nastavi klientovi webove sluzby adresu, kam se ma pripojovat.
   * @param provider proxy webove sluzby.
   * @param uri uri pripojeni.
   * @throws java.net.URISyntaxException
   */
  public void setServiceUri(BindingProvider provider, String uri) throws URISyntaxException {
    System.out.println("Setting service uri to: " + uri);
    provider.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, uri);
  }

  /**
   * Provede zneplatneni obdrzene auth. cookie
   */
  public void logout() {
    if (cookiesContainer == null) {
      return; //nejsme prihlaseni - neni zadna cookie pro zneplatneni
    }

    try {
      String logoutUriStr = reqBaseURI + "/as/processLogout?uri=" + reqBaseURI + "/apps/DS/DsManage";
      URL logoutUrl = new URL(logoutUriStr);
      HttpsURLConnection con = null;
      int responseCode = 0;
      try {
        con = (HttpsURLConnection) logoutUrl.openConnection();
        String cookies = cookiesContainer.getCookieHeaderValueForUrl(logoutUrl);
        con.setRequestProperty("Cookie", cookies); //nastavuje autentifikační cookie

        con.setRequestMethod("GET");
        con.setDoOutput(true);
        responseCode = con.getResponseCode();
      } finally {
        if (con != null) {
          con.disconnect();
        }
      }

      if (responseCode == 200) {
        System.out.println("Uspesne odhlaseno.");
      } else {
        System.out.println("Chyba pri odhlasovani: http code: " + responseCode);
      }
    } catch (Exception ex) {
      System.out.println("Pri odhlasovani doslo k vyjimce: " + ex);
    }
  }
}
