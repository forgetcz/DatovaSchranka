package demohotp;

import java.net.URL;
import java.util.ArrayList;

/**
 * Trida obsahuje seznam cookie a umi generovat pro dane url spravne cookie hlavicky.
 * @author Jan Vávra, isds@software602.cz
 */
public class CookiesContainer {

  private ArrayList<Cookie> list = new ArrayList<Cookie>();

  /**
   * Prida cookie do seznamu.
   * @param toAdd pridavana cookie.
   */
  public void addCookie(Cookie toAdd) {
    for (int i = 0; i < list.size(); i++) {
      Cookie item = list.get(i);
      if (item.name.compareToIgnoreCase(toAdd.name) == 0 &&
              item.domain.compareToIgnoreCase(toAdd.domain) == 0 &&
              item.path.compareToIgnoreCase(toAdd.path) == 0) {
        list.set(i, toAdd);
        return;
      }
    }
    list.add(list.size(), toAdd);
  }

  /**
   * Vrati cookie s prefixem jmena.
   * @param nameprefix prefix jmena.
   * @return cookie
   */
  public Cookie getCookie(String nameprefix) {
    for (int i = 0; i < list.size(); i++) {
      Cookie item = list.get(i);
      if (item.name.startsWith(nameprefix)) {
        return item;
      }
    }
    return null;
  }

  /**
   * Vrati cookie oddelene strednikem, ktere jsou platne pro danou url.
   * @param url dana url.
   * @return retezec s cookies.
   */
  public String getCookieHeaderValueForUrl(URL url) {
    String cookies = "";
    String host = url.getHost().toLowerCase();
    String path = url.getPath().toLowerCase();
    Boolean isHttps = url.getProtocol().equalsIgnoreCase("https");

    for (int i = 0; i < list.size(); i++) {
      Cookie cookie = list.get(i);
      if (cookie.domain.length() > 0 &&
              !host.endsWith(cookie.domain.toLowerCase())) //nesplnuje podminku na domenu
      {
        continue;
      }

      if (!path.startsWith(cookie.path.toLowerCase())) //nesplnuje podminku na cestu
      {
        continue;
      }

      if (cookie.secure && !isHttps) //cookie jen pro https
      {
        continue;
      }

      if (cookies.length() > 0) {
        cookies += "; ";
      }
      cookies += cookie.name + "=" + cookie.value;
    }

    if (cookies.length() == 0) {
      return null;
    } else {
      return cookies;
    }
  }

  /**
   * @return vypis celeho seznamu cookie.
   */
  @Override
  public String toString() {
    String s = "cookies container: \n";
    for (int i = 0; i < list.size(); i++) {
      Cookie cookie = list.get(i);
      s += cookie.name + "=" + cookie.value +
              "; domain=" + cookie.domain +
              "; path=" + cookie.path +
              (cookie.secure ? "; secure" : "") +
              "\n";
    }
    return s;
  }

}
