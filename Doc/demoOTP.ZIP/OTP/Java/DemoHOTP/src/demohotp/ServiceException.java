package demohotp;

/**
 * Výjimka, kterou mohou generovat třídy z příkladu
 * @author Jan Vávra, isds@software602.cz
 */
public class ServiceException extends Exception {

  public ServiceException(String message) {
    super(message);
  }
}
