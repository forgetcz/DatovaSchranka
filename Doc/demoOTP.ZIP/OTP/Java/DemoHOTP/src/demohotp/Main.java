package demohotp;

import cz.czechpoint.isds.v20.DataBoxSearch;
import cz.czechpoint.isds.v20.DataBoxSearchPortType;
import cz.czechpoint.isds.v20.DmInfoPortType;
import cz.czechpoint.isds.v20.DmInfoWebService;
import cz.czechpoint.isds.v20.DmOperationsPortType;
import cz.czechpoint.isds.v20.DmOperationsWebService;
import cz.czechpoint.isds.v20.TDbOwnerInfo;
import cz.czechpoint.isds.v20.TDbOwnersArray;
import cz.czechpoint.isds.v20.TDbReqStatus;
import cz.czechpoint.isds.v20.TDbType;
import java.util.Iterator;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Holder;

/**
 * Program vyzve uzivatele k zadani PU, pote se prihlasi pomoci HOTP, vyhleda
 * schranku "Ministerstvo vnitra" a odhlasi se.
 *
 * Priklad je psan pro VEREJNY TEST (https://www.czebox.cz)
 * Pro produkcni prostredi je treba nastavit destURI na "www.mojedatovaschranka.cz"
 *
 * Pro uspesne prihlaseni je treba nejprve nastavit prislusny typ prihlasovani(SMS/HOTP) v datove schrance
 *
 * Pro pouziti tohoto prikladu musi mit ucet, ke kteremu se prihlasujete, povoleno vyhledavat schranky
 *
 * Pro uspesne volani WS v tomto prikladu je nutne mit naimportovane https serverove certifikaty z
 * http://vca.postsignum.cz/www/authorities.php do java key store kvuli dostupnosti WSDL 
 *
 * Pokud bude kod pouzivat proti produkcnimu prostredi, pak zajistete spravnou
 * hodnotu anotaci wsdlLocation. Ty jsou nyni nasmerovany na verejny test.
 *
 */
public class Main {

  //URI pouzivaneho prostredi
  private static final String destURI = "https://www.czebox.cz";
  //suffixy jednotlivych sluzeb
  private static final String infoServisUriSuffix = "/apps/DS/dx";
  private static final String operationServiceUriSuffix = "/apps/DS/dz";
  private static final String searchServiceUriSuffix = "/apps/DS/df";

  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) throws Exception {

    System.out.println("Pouzivane prostredi: " + destURI);

    //init
    Credentials credentials = new Credentials();
    ServiceManager smng = new ServiceManager(destURI);

    //nacteni jmena, hesla a HOTP kodu z konzole
    credentials.readCredentials();

    // uri jednotlivych sluzeb
    String dmInfoServiceUri = destURI + infoServisUriSuffix;
    String dmOperationsServiceUri = destURI + operationServiceUriSuffix;
    String dbSearchServiceUri = destURI + searchServiceUriSuffix;

    // ziskame remote interface pro dmInfoPortType
    DmInfoWebService dmInfoService = new DmInfoWebService();
    DmInfoPortType dmInfoPort = dmInfoService.getDmInfoPortType();

    // nastavime uri pro pripojeni (null, vezme se default hodnota) a autentizujeme sluzbu
    smng.setServiceUri((BindingProvider) dmInfoPort, dmInfoServiceUri);
    smng.authenticate((BindingProvider) dmInfoPort, credentials, infoServisUriSuffix);

    //ziskame remote interface pro dataBoxSearchService
    DataBoxSearch dataBoxSearchService = new DataBoxSearch();
    DataBoxSearchPortType dataBoxSearchPort = dataBoxSearchService.getDataBoxSearchPortType();
    //nastavime uri pro pripojeni
    smng.setServiceUri((BindingProvider) dataBoxSearchPort, dbSearchServiceUri);
    smng.authenticate((BindingProvider) dataBoxSearchPort, credentials, searchServiceUriSuffix);

    // ziskame remote interface pro dmOperationsWebService
    DmOperationsWebService dmOperationsService = new DmOperationsWebService();
    DmOperationsPortType dmOperationsPort = dmOperationsService.getDmOperationsPortType();

    // nastavime uri pro pripojeni 
    smng.setServiceUri((BindingProvider) dmOperationsPort, dmOperationsServiceUri);
    smng.authenticate((BindingProvider) dmOperationsPort, credentials, operationServiceUriSuffix);

    //vyhledej schranku
    findDatabox(dataBoxSearchPort);

    //zneplatneni auth. cookie
    smng.logout();
  }

  /**
   * Vyhleda schranku podle ukazkove struktury dbOwnerInfo, kde vyplni jen polozku nazev firmy.
   * Nazev firmy musi mit alespon 3 pismena.
   * @param dataBoxSearchPort
   * @throws java.lang.Exception
   */
  private static void findDatabox(DataBoxSearchPortType dataBoxSearchPort) throws Exception {
    TDbOwnerInfo dbOwnerInfo = new TDbOwnerInfo();
    dbOwnerInfo.setAdCity("");
    dbOwnerInfo.setAdNumberInMunicipality("");
    dbOwnerInfo.setAdNumberInStreet("");
    dbOwnerInfo.setAdState("");
    dbOwnerInfo.setAdStreet("");
    dbOwnerInfo.setAdZipCode("");

    DatatypeFactory dataTypeFactory = DatatypeFactory.newInstance();
    XMLGregorianCalendar bidate = dataTypeFactory.newXMLGregorianCalendar(
            1981, 3, 7, //rok, mesic, den
            0, 0, 0, 0, //hod, min, sec, msec
            0); //zone offset

    dbOwnerInfo.setBiCity("");
    dbOwnerInfo.setBiCounty("");
    dbOwnerInfo.setBiState("");
    dbOwnerInfo.setPnFirstName("");
    dbOwnerInfo.setPnLastName("");
    //Vyhledame DS MV
    dbOwnerInfo.setDbType(TDbType.OVM);
    dbOwnerInfo.setFirmName("Ministerstvo vnitra");
    //dbOwnerInfo.setBiDate(bidate);

    Holder<TDbOwnersArray> dbResults = new Holder<TDbOwnersArray>();
    Holder<TDbReqStatus> dbStatus = new Holder<TDbReqStatus>();
    dataBoxSearchPort.findDataBox(dbOwnerInfo, dbResults, dbStatus);
    System.out.println("searchDatabox status: " + dbStatus.value.getDbStatusMessage());
    if (dbStatus.value.getDbStatusCode().startsWith("0")) {
      Iterator<TDbOwnerInfo> it = dbResults.value.getDbOwnerInfo().iterator();
      while (it.hasNext()) {
        TDbOwnerInfo owner = it.next();
        System.out.println("firmname: " + owner.getFirmName() + ", dbid: " + owner.getDbID());
      }
    }
  }
}
