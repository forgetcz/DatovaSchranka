package demosms;

import java.io.Console;

/**
 *
 * Trida pro uchovani uzivatelskeho jmena a hesla
 */
public class Credentials {

  private String login = "";
  private String password = "";
  private String SMSCode = "";

  /**
   * @return the login
   */
  public String getLogin() {
    return login;
  }

  /**
   * @return the password
   */
  public String getPassword() {
    return password;
  }

  /**
   * @return the SMSCode
   */
  public String getSMSCode() {
    return SMSCode;
  }

  public void readCredentials() {
    System.out.println("\r\nTohle je priklad nacteni prihlasovacich udaju. " +
            "Ulozeni jmena a hesla primo ve zdrojovem kodu aplikace neni bezpecne.\r\n");

    Console console = System.console();
    if (console == null) {
      throw new Error("Toto nacteni udaju funguje jen pri spusteni programu " +
              "v prikazovem radku (cmd.exe, bash).\r\n");
    }

    login = console.readLine("Zadejte uzivatelske jmeno: ");
    password = new String(console.readPassword("Zadejte heslo: "));

  }

  public void readSMSCode() {

    Console console = System.console();
    if (console == null) {
      throw new Error("Toto nacteni SMS kodu funguje jen pri spusteni programu " +
              "v prikazovem radku (cmd.exe, bash).\r\n");
    }
    SMSCode = console.readLine("Zadejte SMS kod: ");
  }
}
