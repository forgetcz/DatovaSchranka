package demosms;

/**
 * Trida obsahujici naparsovane informace o jedne http cookie.
 * @author Jan Vávra, isds@software602.cz
 */
public class Cookie {

    String name = "";
    String value = "";
    String domain = "";
    String path = "/";
    Boolean secure = false;
    //expires ignored

    /**
     * Naparsuje cookie z obsahu http hlavicky Set-Cookie
     * @param set_cookie_header_value obsah http hlavicky.
     */
    public Cookie(String set_cookie_header_value) {
        String[] p = set_cookie_header_value.split(";");
        if (p.length > 0) {
            p[0] = p[0].trim();
            String[] cp = p[0].split("=");
            if (cp.length > 0) {
                name = cp[0];
            }
            if (cp.length > 1) {
                value = cp[1];
            }
        }
        for (int i = 1; i < p.length; i++) {
            p[i]=p[i].trim();
            String part_lcase = p[i].toLowerCase();
            if (part_lcase.startsWith("domain")) {
                domain = p[i].substring("domain=".length());
            } else if (part_lcase.startsWith("path")) {
                path = p[i].substring("path=".length());
            } else if (part_lcase.startsWith("secure")) {
                secure = true;
            }
        }
    }
}
