/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package demosms;

/**
 * Výjimka, kterou mohou generovat třídy z příkladu
 * @author Jan Vávra, isds@software602.cz
 */
public class ServiceException extends Exception {

  public ServiceException(String message) {
    super(message);
  }
}
