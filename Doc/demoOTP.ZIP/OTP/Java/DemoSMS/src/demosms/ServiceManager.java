package demosms;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.*;
import java.util.List;
import javax.net.ssl.HttpsURLConnection;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.MessageContext;

public class ServiceManager {

  private final int MAX_REDIRECT_CNT = 20;
  // timeout cookie, po nem je treba znovu cookie ziskat. Nastaven na 30 minut
  private static final int COOKIE_TIMEOUT_MS = 30 * 60 * 1000;
  private String reqBaseURI = null;
  // kontejner pro cookie ziskanych pri prihlasovani
  private CookiesContainer cookiesContainer = new CookiesContainer();
  //auth. cookie
  private String authCookie = null;
  private Date authCookieTime = null;

  public ServiceManager(String uri) {
    this.reqBaseURI = uri;
  }
/**
 * Zasle celkem 2 http pozadavky a ulozi auth. cookie do <code>authCookie</code> jako
 * retezec. Postup je nasledujici:
 * 1. Zasle pozadavek o SMS s basic autentizaci (jmeno + heslo)
 * 2. Zasle pozadavek o auth. cookie s modifikovanou basic autentizaci (jmeno + heslo + sms kod)
 * 3. Ziska auth. cookie a ulozi ji pro dalsi pouziti
 * @param cr pristupove udaje
 * @throws MalformedURLException
 * @throws IOException
 * @throws URISyntaxException
 * @throws ServiceException
 */
  public void obtainAuthCookie(Credentials cr, String serviceSuffix) throws MalformedURLException, IOException, URISyntaxException, ServiceException {

    String redirectUrl = null;
    int responseCode = 0;
    HashSet<String> usedUrls = new HashSet<String>();

    /***** 1. pozadavek o SMS *****/
    //hlavicka basic autentizace
    String basicPwd = cr.getLogin() + ":" + cr.getPassword();
    String basicAuthStr = "Basic " + new sun.misc.BASE64Encoder().encode(basicPwd.getBytes());
    //url pro pozadavek na zaslani SMS zpravy
    URL requestUrl = new URL(reqBaseURI + "/as/processLogin?type=totp&sendSms=true&uri=" + reqBaseURI + serviceSuffix);

    //HTTPS connection
    HttpsURLConnection connection = (HttpsURLConnection) requestUrl.openConnection();
    //nastaveni basic autentizace pozadavku o SMS kod
    connection.setRequestProperty("Authorization", basicAuthStr);
    connection.setRequestProperty("Content-Type", "text/xml");
    connection.setRequestProperty("Content-Length", "0");
    connection.setRequestProperty("Cache-Control", "no-cache");

    //sestaveni POST pozadavku
    connection.setRequestMethod("POST");
    connection.setDoOutput(true);
    connection.setInstanceFollowRedirects(false);

    // najdi cookie platne pro dane url
    String cookies = cookiesContainer.getCookieHeaderValueForUrl(requestUrl);

    if (cookies != null) {
      connection.setRequestProperty("Cookie", cookies);
    }

    //precteni hlavicek odpovedi
    //url kam budeme zasilat pozadavek jiz se SMS kodem

    if (connection.getResponseCode() == 302) {
      redirectUrl = connection.getHeaderField("Location");
    } else {
      throw new ServiceException("Nedoslo k predpokladanemu presmerovani. Server odpovedel error code " + connection.getResponseCode());
    }
    /***** konec 1. pozadavku o SMS *****/


    //odeslan poyadavek o SMS - nacteme kod prijaty v SMS
    cr.readSMSCode();

    /***** 2. pozadavek o auth. cookie *****/
    //zasleme pozadavek jiz se SMS kodem
    //hlavicka modifikovane basic autentizace se SMS kodem
    String basicPwd2 = cr.getLogin() + ":" + cr.getPassword() + cr.getSMSCode();
    String basicAuthStr2 = "Basic " + new sun.misc.BASE64Encoder().encode(basicPwd2.getBytes());
    requestUrl = new URL(redirectUrl);

    //muzeme byt redirectovani - MAX 20krat
    for (int i = 0; i < MAX_REDIRECT_CNT; i++) {
      //HTTPS connection
      connection = (HttpsURLConnection) requestUrl.openConnection();
      //nastaveni basic autentizace pozadavku o SMS kod
      connection.setRequestProperty("Authorization", basicAuthStr2);
      try {
        //sestaveni POST pozadavku
        connection.setRequestMethod("POST");
        connection.setDoOutput(true);
        connection.setInstanceFollowRedirects(false);

        // najdi cookie platne pro dane url
        cookies = cookiesContainer.getCookieHeaderValueForUrl(requestUrl);

        if (cookies != null) {
          connection.setRequestProperty("Cookie", cookies);
        }

        //precteni hlavicek odpovedi
        //uchovej si prijate cookie
        List<String> sclist = connection.getHeaderFields().get("Set-Cookie");
        if (sclist != null) {
          for (String set_cookie_value : sclist) {
            if (set_cookie_value != null) {
              Cookie cookie = new Cookie(set_cookie_value);
              cookiesContainer.addCookie(cookie);
            }
          }
        }

        //kod odpovedi serveru
        responseCode = connection.getResponseCode();
        if (responseCode == 200 || cookiesContainer.getCookie("IPCZ-X-COOKIE") != null) { //OK nebo jsme jiz obdrzeli auth cookie
          break;
        } else //redirect
        if ((responseCode == 302 || responseCode == 301) && redirectUrl != null) {
          requestUrl = new URL(redirectUrl);

          if (usedUrls.contains(redirectUrl)) {
            System.out.println("Cyklicky redirect");
          }
          usedUrls.add(redirectUrl);
          //presmerovani
          redirectUrl = connection.getHeaderField("Location");
        } else if (responseCode == 401) {
          System.out.println("Unathorized (401)");
          break;
        } else {
          System.out.println("Neocekavana odpoved.");
          break;
        }
      } finally {
        if (connection != null) {
          connection.disconnect();
        }
      }
    }

    // z kontejneru si vyjmeme auth. cookie a upravime ji pro vkladani do hlavicek dalsich requestu
    Cookie ipcz = cookiesContainer.getCookie("IPCZ");
    //ulozime ji do authCookie pro dalsi pouziti
    authCookie = ipcz.name + "=" + ipcz.value;
  }

  /**
   * Prida k webove sluzbe do request hlavicek autentizacni cookie.
   * @param provider port webove sluzby.
   */
  private void addAuthCookie(BindingProvider provider) {
    Map requestContext = provider.getRequestContext();
    requestContext.put(BindingProvider.SESSION_MAINTAIN_PROPERTY, true);

    Map<String, List> requestHeaders = new HashMap<String, List>();
    List cookies = new ArrayList();

    String cs = authCookie;
    cookies.add(cs);

    List accept = new ArrayList();
    accept.add("text/xml");

    requestHeaders.put("Cookie", cookies);
    requestContext.put(MessageContext.HTTP_REQUEST_HEADERS, requestHeaders);
  }

  /**
   * Nastavi autentizacni cookie. Pro autentizaci vyuzije jmeno, heslo a HOTP kod.
   * @param provider proxy webove sluzby.
   * @param cr pristupove udaje
   * @throws java.lang.Exception
   */
  public void authenticate(BindingProvider provider, Credentials cr, String serviceSuffix)
          throws NoSuchAlgorithmException, KeyStoreException, FileNotFoundException, IOException,
          CertificateException, UnrecoverableKeyException, KeyManagementException,
          MalformedURLException, ServiceException, URISyntaxException {

    Date now = new Date();
    if (authCookie == null ||
            cookiesContainer == null ||
            authCookieTime == null ||
            authCookieTime.getTime() + COOKIE_TIMEOUT_MS < now.getTime()) {
      obtainAuthCookie(cr, serviceSuffix);
      authCookieTime = now;
    }

    if (provider != null) {
      addAuthCookie(provider);
    }
  }

  /**
   * Nastavi klientovi webove sluzby adresu, kam se ma pripojovat.
   * @param provider proxy webove sluzby.
   * @param uri uri pripojeni.
   * @throws java.net.URISyntaxException
   */
  public void setServiceUri(BindingProvider provider, String uri) throws URISyntaxException {
    System.out.println("Setting service uri to: " + uri);
    provider.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, uri);
  }

  /**
   * Provede zneplatneni obdrzene auth. cookie
   */
  public void logout() {
    if (cookiesContainer == null) {
      return; //nejsme prihlaseni - neni zadna cookie pro zneplatneni
    }

    try {
      String logoutUriStr = reqBaseURI + "/as/processLogout?uri=" + reqBaseURI + "/apps/DS/DsManage";
      URL logoutUrl = new URL(logoutUriStr);
      HttpsURLConnection con = null;
      int responseCode = 0;
      try {
        con = (HttpsURLConnection) logoutUrl.openConnection();
        String cookies = cookiesContainer.getCookieHeaderValueForUrl(logoutUrl);
        con.setRequestProperty("Cookie", cookies); //nastavuje autentifikační cookie

        con.setRequestMethod("GET");
        con.setDoOutput(true);
        responseCode = con.getResponseCode();
      } finally {
        if (con != null) {
          con.disconnect();
        }
      }

      if (responseCode == 200) {
        System.out.println("Uspesne odhlaseno.");
      } else {
        System.out.println("Chyba pri odhlasovani: http code: " + responseCode);
      }
    } catch (Exception ex) {
      System.out.println("Pri odhlasovani doslo k vyjimce: " + ex);
    }
  }
}
