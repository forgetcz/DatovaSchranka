﻿using System;

namespace DemoHOTP
{
    //trida obsahujici konstanty
    class Constants
    {
        //URI pouzivaneho prostredi
        public static string DestURI = "https://www.czebox.cz";

        //zakladni cast URI pro prihlaseni pomoci HOTP
        public static string LoginUriBase = DestURI + "/as/processLogin?type=hotp&uri=";
        //zakladni cast URI pro zneplatneni cookie - odhlaseni
        public static string LogoutUriBase = DestURI + "/as/processLogout?uri=";
        
        //suffixy jednotlivych sluzeb
        public static string InfoServisUriSuffix = "/apps/DS/dx";
        public static string OperationServiceUriSuffix = "/apps/DS/dz";
        public static string SearchServiceUriSuffix = "/apps/DS/DsManage";

        private Constants()
        {

        }
    }

    
}
