﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.IO;
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Serialization;

namespace DemoHOTP
{
    /// <summary>
    /// Trida reprezentujici dat. schranku, se kterou budeme pracovat.
    /// </summary>
    class ISDSBox
        {
        private dmInfoWebService InfoWebService;
        private dmOperationsWebService OperationsWebService;
        private DataBoxAccess AccessWebService;
        private DataBoxManipulation ManipulationWebService;
        private CookieContainer CookieCont = new CookieContainer();

        //pristupove udaje pro schranku
        private Credentials CR = null;

       
        public enum ISDSServiceType
        {
            Operation,
            Info,
            Manipulation,
            Access
        }

        /// <summary>
        /// Konstruktor
        /// </summary>
        public ISDSBox(Credentials Cred) 
        {
            this.CR = Cred;
        }

        /// <summary>
        /// Inicializacni procedura
        /// </summary>
        public void Connect()
        {
            string InfoURL;
            string OperationURL;
            string AccessURL;
            string ManipulationURL;
            Connect(out InfoURL, out OperationURL, out AccessURL, out ManipulationURL);
        }
        public void Connect(out string InfoURL, out string OperationURL, out string AccessURL, out string ManipulationURL)
        {
            // system pouziva 4 webove sluzby
            InfoWebService = new dmInfoWebService();
            OperationsWebService = new dmOperationsWebService();
            AccessWebService = new DataBoxAccess();
            ManipulationWebService = new DataBoxManipulation();

            InfoURL = GetISDSServiceURL(ISDSServiceType.Info);
            OperationURL = GetISDSServiceURL(ISDSServiceType.Operation);
            AccessURL = GetISDSServiceURL(ISDSServiceType.Access);
            ManipulationURL = GetISDSServiceURL(ISDSServiceType.Manipulation);

            // inicializace jednotlivych sluzeb
            InitializeService(InfoWebService, InfoURL);
            InitializeService(OperationsWebService, OperationURL);
            InitializeService(AccessWebService, AccessURL);
            InitializeService(ManipulationWebService, ManipulationURL);
        }

        /// <summary>
        /// Vrati URL dane sluzby.
        /// </summary>
        public static string GetISDSServiceURL(ISDSServiceType SType)
        {
            switch (SType)
            {
                case ISDSServiceType.Info:
                    return Constants.DestURI + Constants.InfoServisUriSuffix;
                case ISDSServiceType.Operation:
                    return Constants.DestURI + Constants.OperationServiceUriSuffix;
                default:
                    return Constants.DestURI + Constants.SearchServiceUriSuffix;
            }
        }
        /// <summary>
        /// Inicializacni procedura pro jednotlive sluzby.
        /// </summary>
        private void InitializeService(ISDSService WS, string URL)
        {
            WS.Url = URL;
            // Pri prihlasovani k ISDS dochazi k presmerovavani - to je treba implicitne povolit
            WS.AllowAutoRedirect = true;
            WS.UserAgent = "ISDS .NET Sample HOTP";
            // Pri autorizaci do ISDS se pouziva cookie - je treba tuto cookie "uskladnit"
            WS.CookieContainer = new CookieContainer();

            //nemame auth. cookie
            if (!ContainAuthCookie(this.CookieCont))
            {
                //sestavime autentizacni retezec ze jmena a hesla a HOTP kodu
                string AuthStr = CR.GetLogin() + ":" + CR.GetPassword() + CR.GgetHOTPCode();
                string AuthStrB64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(AuthStr));

                // zaslani pozadavku - pro obdrzeni cookie
                WS.ObtainAuthCookie(AuthStrB64, Constants.LoginUriBase + URL);

                //uchovame si cookie cont.
                this.CookieCont = WS.CookieContainer;
            }
            else {
                //cookie cont s auth. cookie predame i dalsim WS
                WS.CookieContainer = this.CookieCont;
            }
        }
        /// <summary>
        /// pomocna metoda k overeni zda mame v kontejneru auth. cookie
        /// </summary>
        public bool ContainAuthCookie(CookieContainer CContainer) {

            foreach (Cookie CurCookie in CookieCont.GetCookies(new Uri(Constants.DestURI))) {
                if (CurCookie.Name.StartsWith("IPCZ-X-")) {
                    return true;
                }
            }
            return false;
        }
        /// <summary>
        ///Zasle pozadavky na zneplatneni auth. cookie pro zneplatneni cookie.
        /// </summary>
        public void Logout() {
            if (ContainAuthCookie(InfoWebService.CookieContainer))
            {
                InfoWebService.Logout(Constants.LogoutUriBase + InfoWebService.Url);
            }
            if (ContainAuthCookie(OperationsWebService.CookieContainer))
            {
                OperationsWebService.Logout(Constants.LogoutUriBase + OperationsWebService.Url);
            }
            if (ContainAuthCookie(AccessWebService.CookieContainer))
            {
                AccessWebService.Logout(Constants.LogoutUriBase + AccessWebService.Url);
            }
            if (ContainAuthCookie(ManipulationWebService.CookieContainer))
            {
                ManipulationWebService.Logout(Constants.LogoutUriBase + ManipulationWebService.Url);
            }
            Console.Out.WriteLine("Úspěšně odhlášeno.");
        }

        /// <summary>
        /// Vyhleda schranky OVM obsahujici v nazvu "Ministerstvo vnitra" a vypise jejich nazev.
        /// </summary>
        public void FindDataBox()
        {

            tFindDBInput FDBI = new tFindDBInput();
            FDBI.dbOwnerInfo = PrepareMVOwnerInfo();
            tFindDBOuput FDBO = new tFindDBOuput();
            try
            {
                FDBO = ManipulationWebService.FindDataBox(FDBI);
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Při volání metody FindDataBox webové služby DataBoxSearchWebService došlo k výjimce: {0}", ex.Message));
            }

            string StatusCode = FDBO.dbStatus.dbStatusCode;
            string StatusMessage = FDBO.dbStatus.dbStatusMessage;
            if (StatusCode.StartsWith("0"))
            {
                foreach (tDbOwnerInfo OwnInfo in FDBO.dbResults.dbOwnerInfo){
                    Console.Out.WriteLine(OwnInfo.firmName);
                }
            }
        }

        /// <summary>
        /// Pripravi tDbOwnerInfo pro OVM obsahujici v nazvu "Ministerstvo vnitra"
        /// </summary>
        /// <returns></returns>
        private tDbOwnerInfo PrepareMVOwnerInfo()
        {
            tDbOwnerInfo MVBox = new tDbOwnerInfo();
            MVBox.dbType = tDbType.OVM;
            MVBox.firmName = "Ministerstvo vnitra";
            
            return MVBox;
        }


        }

}
