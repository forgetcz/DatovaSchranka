﻿using System;

namespace DemoHOTP
{
    ///<summary>
    ///trida pro uchovani pristupovych udaji ke schrance
    ///</summary>
    class Credentials
    {
        private string Login = "";
        private string Password = "";
        private string SMSCode = "";

        public string GetLogin()
        {
            return Login;
        }
        public string GetPassword()
        {
            return Password;
        }
        public string GetSMSCode()
        {
            return SMSCode;
        }

        ///<summary>
        ///nacte pristupove udaje (jmeno, heslo a HOTP kod) z konzole       
        /// </summary>
        public void ReadCredentials()
        {
            Console.WriteLine();
            Console.Write("Zadejte přihlašovací jméno k první datové schránce a stiskněte <Enter>: ");
            Login = Console.ReadLine();
            Console.Write("Zadejte heslo k první datové schránce a stiskněte <Enter>: ");
            ConsoleColor CC = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.CursorVisible = false;
            Password = Console.ReadLine();
            Console.ForegroundColor = CC;
            Console.CursorVisible = true;

        }
        public void ReadSMSCode()
        {
            Console.Write("Zadejte HOTP kód a stiskněte <Enter>: ");
            SMSCode = Console.ReadLine();
        }
    }
}