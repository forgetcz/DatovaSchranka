﻿using System;

namespace DemoHOTP
{
    class Constants
    {
        //URI pouzivaneho prostredi
        public static string DestURI = "https://www.czebox.cz";

        //zakladni cast URI pro prihlaseni pomoci SMS
        public static string LoginUriBase = DestURI + "/as/processLogin?type=totp&uri=";
        //zakladni cast URI pro zneplatneni cookie - odhlaseni
        public static string LogoutUriBase = DestURI + "/as/processLogout?uri=";
        //zakladni cast URI pro zaslani pozadavku o SMS 
        public static string SMSUriBase = DestURI + "/as/processLogin?type=totp&sendSms=true&uri=";
        
        //suffixy jednotlivych sluzeb
        public static string InfoServisUriSuffix = "/apps/DS/dx";
        public static string OperationServiceUriSuffix = "/apps/DS/dz";
        public static string SearchServiceUriSuffix = "/apps/DS/DsManage";

        private Constants()
        {

        }
    }

    
}
