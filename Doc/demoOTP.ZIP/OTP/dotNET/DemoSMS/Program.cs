using System;

namespace DemoHOTP
{
    class Program
    {
        /*
        * Program vyzve uzivatele k zadani PU, pote se prihlasi pomoci HOTP, stahne info o schrance MV a odhlasi se.
        *
        * Priklad je psan pro VEREJNY TEST (https://www.czebox.cz)
        * Pro produkcni prostredi je treba nastavit adresu na "https://www.mojedatovaschranka.cz" ve tride Constants
        *
        * Pro uspesne prihlaseni je treba nejprve nastavit prislusny typ prihlasovani(SMS) v datove schrance
        */
        static void Main(string[] args)
                {
            //nacteme pristupove udaje z konzole
            Credentials CR = new Credentials();
            CR.ReadCredentials();

            //schranka ke ktere se budeme prihlasovat
            ISDSBox Box = new ISDSBox(CR);
            
            try
            {
                //prihlaseni
                Box.Connect();
            }
            catch (Exception ex){
                Console.Out.WriteLine("Při připojování ke schránce došlo k chybě.");
                Console.Out.WriteLine(ex.Message);
                return;
            }

            //info o schrance Ministerstva vnitra
            Box.FindDataBox();
            //odhlaseni
            Box.Logout();
           



        }
    }
}
