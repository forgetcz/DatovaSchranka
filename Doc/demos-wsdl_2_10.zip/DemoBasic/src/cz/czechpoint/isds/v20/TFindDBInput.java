
package cz.czechpoint.isds.v20;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for tFindDBInput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tFindDBInput">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="dbOwnerInfo" type="{http://isds.czechpoint.cz/v20}tDbOwnerInfo"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tFindDBInput", propOrder = {
    "dbOwnerInfo"
})
public class TFindDBInput {

    @XmlElement(required = true)
    protected TDbOwnerInfo dbOwnerInfo;

    /**
     * Gets the value of the dbOwnerInfo property.
     * 
     * @return
     *     possible object is
     *     {@link TDbOwnerInfo }
     *     
     */
    public TDbOwnerInfo getDbOwnerInfo() {
        return dbOwnerInfo;
    }

    /**
     * Sets the value of the dbOwnerInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link TDbOwnerInfo }
     *     
     */
    public void setDbOwnerInfo(TDbOwnerInfo value) {
        this.dbOwnerInfo = value;
    }

}
