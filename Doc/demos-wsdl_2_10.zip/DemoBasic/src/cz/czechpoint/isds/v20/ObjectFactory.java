
package cz.czechpoint.isds.v20;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the cz.czechpoint.isds.v20 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _DeleteDataBoxUserResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "DeleteDataBoxUserResponse");
    private final static QName _DeleteDataBoxResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "DeleteDataBoxResponse");
    private final static QName _DisableDataBoxExternallyResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "DisableDataBoxExternallyResponse");
    private final static QName _ClearEffectiveOVMResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "ClearEffectiveOVMResponse");
    private final static QName _SetEffectiveOVM_QNAME = new QName("http://isds.czechpoint.cz/v20", "SetEffectiveOVM");
    private final static QName _DisableOwnDataBox_QNAME = new QName("http://isds.czechpoint.cz/v20", "DisableOwnDataBox");
    private final static QName _FindDataBoxResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "FindDataBoxResponse");
    private final static QName _GetPasswordInfoResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "GetPasswordInfoResponse");
    private final static QName _CheckDataBox_QNAME = new QName("http://isds.czechpoint.cz/v20", "CheckDataBox");
    private final static QName _FindDataBox_QNAME = new QName("http://isds.czechpoint.cz/v20", "FindDataBox");
    private final static QName _ChangeISDSPasswordResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "ChangeISDSPasswordResponse");
    private final static QName _ChangeISDSPassword_QNAME = new QName("http://isds.czechpoint.cz/v20", "ChangeISDSPassword");
    private final static QName _GetOwnerInfoFromLoginResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "GetOwnerInfoFromLoginResponse");
    private final static QName _DeleteDataBox_QNAME = new QName("http://isds.czechpoint.cz/v20", "DeleteDataBox");
    private final static QName _CheckDataBoxResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "CheckDataBoxResponse");
    private final static QName _ClearOpenAddressing_QNAME = new QName("http://isds.czechpoint.cz/v20", "ClearOpenAddressing");
    private final static QName _GetDataBoxList_QNAME = new QName("http://isds.czechpoint.cz/v20", "GetDataBoxList");
    private final static QName _Activate_QNAME = new QName("http://isds.czechpoint.cz/v20", "Activate");
    private final static QName _UpdateDataBoxDescr_QNAME = new QName("http://isds.czechpoint.cz/v20", "UpdateDataBoxDescr");
    private final static QName _ActivateResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "ActivateResponse");
    private final static QName _UpdateDataBoxDescrResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "UpdateDataBoxDescrResponse");
    private final static QName _DisableOwnDataBoxResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "DisableOwnDataBoxResponse");
    private final static QName _GetDataBoxUsers_QNAME = new QName("http://isds.czechpoint.cz/v20", "GetDataBoxUsers");
    private final static QName _GetUserInfoFromLoginResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "GetUserInfoFromLoginResponse");
    private final static QName _DbStatus_QNAME = new QName("http://isds.czechpoint.cz/v20", "dbStatus");
    private final static QName _NewAccessDataResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "NewAccessDataResponse");
    private final static QName _SetOpenAddressingResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "SetOpenAddressingResponse");
    private final static QName _UpdateDataBoxUser_QNAME = new QName("http://isds.czechpoint.cz/v20", "UpdateDataBoxUser");
    private final static QName _NewAccessData_QNAME = new QName("http://isds.czechpoint.cz/v20", "NewAccessData");
    private final static QName _CreateDataBoxPFOInfoResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "CreateDataBoxPFOInfoResponse");
    private final static QName _GetPasswordInfo_QNAME = new QName("http://isds.czechpoint.cz/v20", "GetPasswordInfo");
    private final static QName _AddDataBoxUser_QNAME = new QName("http://isds.czechpoint.cz/v20", "AddDataBoxUser");
    private final static QName _DisableDataBoxExternally_QNAME = new QName("http://isds.czechpoint.cz/v20", "DisableDataBoxExternally");
    private final static QName _CreateDataBoxPFOInfo_QNAME = new QName("http://isds.czechpoint.cz/v20", "CreateDataBoxPFOInfo");
    private final static QName _CreateDataBoxResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "CreateDataBoxResponse");
    private final static QName _CreateDataBox_QNAME = new QName("http://isds.czechpoint.cz/v20", "CreateDataBox");
    private final static QName _GetUserInfoFromLogin_QNAME = new QName("http://isds.czechpoint.cz/v20", "GetUserInfoFromLogin");
    private final static QName _DeleteDataBoxUser_QNAME = new QName("http://isds.czechpoint.cz/v20", "DeleteDataBoxUser");
    private final static QName _GetOwnerInfoFromLogin_QNAME = new QName("http://isds.czechpoint.cz/v20", "GetOwnerInfoFromLogin");
    private final static QName _ClearOpenAddressingResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "ClearOpenAddressingResponse");
    private final static QName _AddDataBoxUserResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "AddDataBoxUserResponse");
    private final static QName _GetDataBoxListResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "GetDataBoxListResponse");
    private final static QName _SetOpenAddressing_QNAME = new QName("http://isds.czechpoint.cz/v20", "SetOpenAddressing");
    private final static QName _EnableOwnDataBox_QNAME = new QName("http://isds.czechpoint.cz/v20", "EnableOwnDataBox");
    private final static QName _UpdateDataBoxUserResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "UpdateDataBoxUserResponse");
    private final static QName _ClearEffectiveOVM_QNAME = new QName("http://isds.czechpoint.cz/v20", "ClearEffectiveOVM");
    private final static QName _EnableOwnDataBoxResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "EnableOwnDataBoxResponse");
    private final static QName _SetEffectiveOVMResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "SetEffectiveOVMResponse");
    private final static QName _GetDataBoxUsersResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "GetDataBoxUsersResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: cz.czechpoint.isds.v20
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link TChngPasswInput }
     * 
     */
    public TChngPasswInput createTChngPasswInput() {
        return new TChngPasswInput();
    }

    /**
     * Create an instance of {@link TUpdDBUserInput }
     * 
     */
    public TUpdDBUserInput createTUpdDBUserInput() {
        return new TUpdDBUserInput();
    }

    /**
     * Create an instance of {@link TAddDBUserInput }
     * 
     */
    public TAddDBUserInput createTAddDBUserInput() {
        return new TAddDBUserInput();
    }

    /**
     * Create an instance of {@link TAddDBUserOutput }
     * 
     */
    public TAddDBUserOutput createTAddDBUserOutput() {
        return new TAddDBUserOutput();
    }

    /**
     * Create an instance of {@link TCheckDBOutput }
     * 
     */
    public TCheckDBOutput createTCheckDBOutput() {
        return new TCheckDBOutput();
    }

    /**
     * Create an instance of {@link TDbOwnerInfo }
     * 
     */
    public TDbOwnerInfo createTDbOwnerInfo() {
        return new TDbOwnerInfo();
    }

    /**
     * Create an instance of {@link TActivateInput }
     * 
     */
    public TActivateInput createTActivateInput() {
        return new TActivateInput();
    }

    /**
     * Create an instance of {@link TDeleteDBInput }
     * 
     */
    public TDeleteDBInput createTDeleteDBInput() {
        return new TDeleteDBInput();
    }

    /**
     * Create an instance of {@link TGetDBUsersOutput }
     * 
     */
    public TGetDBUsersOutput createTGetDBUsersOutput() {
        return new TGetDBUsersOutput();
    }

    /**
     * Create an instance of {@link TGetDBListOutput }
     * 
     */
    public TGetDBListOutput createTGetDBListOutput() {
        return new TGetDBListOutput();
    }

    /**
     * Create an instance of {@link TReqStatusOutput }
     * 
     */
    public TReqStatusOutput createTReqStatusOutput() {
        return new TReqStatusOutput();
    }

    /**
     * Create an instance of {@link TDummyInput }
     * 
     */
    public TDummyInput createTDummyInput() {
        return new TDummyInput();
    }

    /**
     * Create an instance of {@link TCreateDBInput }
     * 
     */
    public TCreateDBInput createTCreateDBInput() {
        return new TCreateDBInput();
    }

    /**
     * Create an instance of {@link TDbOwnersArray }
     * 
     */
    public TDbOwnersArray createTDbOwnersArray() {
        return new TDbOwnersArray();
    }

    /**
     * Create an instance of {@link TDbUserInfo }
     * 
     */
    public TDbUserInfo createTDbUserInfo() {
        return new TDbUserInfo();
    }

    /**
     * Create an instance of {@link TDbUsersArray }
     * 
     */
    public TDbUsersArray createTDbUsersArray() {
        return new TDbUsersArray();
    }

    /**
     * Create an instance of {@link TFindDBOuput }
     * 
     */
    public TFindDBOuput createTFindDBOuput() {
        return new TFindDBOuput();
    }

    /**
     * Create an instance of {@link TGetUserInfoOutput }
     * 
     */
    public TGetUserInfoOutput createTGetUserInfoOutput() {
        return new TGetUserInfoOutput();
    }

    /**
     * Create an instance of {@link TNewAccDataInput }
     * 
     */
    public TNewAccDataInput createTNewAccDataInput() {
        return new TNewAccDataInput();
    }

    /**
     * Create an instance of {@link TIdDbInput }
     * 
     */
    public TIdDbInput createTIdDbInput() {
        return new TIdDbInput();
    }

    /**
     * Create an instance of {@link TCreateDBPFOInfoInput }
     * 
     */
    public TCreateDBPFOInfoInput createTCreateDBPFOInfoInput() {
        return new TCreateDBPFOInfoInput();
    }

    /**
     * Create an instance of {@link TOwnerInfoInput }
     * 
     */
    public TOwnerInfoInput createTOwnerInfoInput() {
        return new TOwnerInfoInput();
    }

    /**
     * Create an instance of {@link TDisableExternallyInput }
     * 
     */
    public TDisableExternallyInput createTDisableExternallyInput() {
        return new TDisableExternallyInput();
    }

    /**
     * Create an instance of {@link TCreateDBOutput }
     * 
     */
    public TCreateDBOutput createTCreateDBOutput() {
        return new TCreateDBOutput();
    }

    /**
     * Create an instance of {@link TGetPasswInfoOutput }
     * 
     */
    public TGetPasswInfoOutput createTGetPasswInfoOutput() {
        return new TGetPasswInfoOutput();
    }

    /**
     * Create an instance of {@link TDelDBUserInput }
     * 
     */
    public TDelDBUserInput createTDelDBUserInput() {
        return new TDelDBUserInput();
    }

    /**
     * Create an instance of {@link TUpdateDBInput }
     * 
     */
    public TUpdateDBInput createTUpdateDBInput() {
        return new TUpdateDBInput();
    }

    /**
     * Create an instance of {@link TGetOwnInfoOutput }
     * 
     */
    public TGetOwnInfoOutput createTGetOwnInfoOutput() {
        return new TGetOwnInfoOutput();
    }

    /**
     * Create an instance of {@link TCreateDBPFOInfoOutput }
     * 
     */
    public TCreateDBPFOInfoOutput createTCreateDBPFOInfoOutput() {
        return new TCreateDBPFOInfoOutput();
    }

    /**
     * Create an instance of {@link TNewAccDataOutput }
     * 
     */
    public TNewAccDataOutput createTNewAccDataOutput() {
        return new TNewAccDataOutput();
    }

    /**
     * Create an instance of {@link TFindDBInput }
     * 
     */
    public TFindDBInput createTFindDBInput() {
        return new TFindDBInput();
    }

    /**
     * Create an instance of {@link TGetDBListInput }
     * 
     */
    public TGetDBListInput createTGetDBListInput() {
        return new TGetDBListInput();
    }

    /**
     * Create an instance of {@link TActivateOutput }
     * 
     */
    public TActivateOutput createTActivateOutput() {
        return new TActivateOutput();
    }

    /**
     * Create an instance of {@link TDbReqStatus }
     * 
     */
    public TDbReqStatus createTDbReqStatus() {
        return new TDbReqStatus();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TReqStatusOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "DeleteDataBoxUserResponse")
    public JAXBElement<TReqStatusOutput> createDeleteDataBoxUserResponse(TReqStatusOutput value) {
        return new JAXBElement<TReqStatusOutput>(_DeleteDataBoxUserResponse_QNAME, TReqStatusOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TReqStatusOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "DeleteDataBoxResponse")
    public JAXBElement<TReqStatusOutput> createDeleteDataBoxResponse(TReqStatusOutput value) {
        return new JAXBElement<TReqStatusOutput>(_DeleteDataBoxResponse_QNAME, TReqStatusOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TReqStatusOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "DisableDataBoxExternallyResponse")
    public JAXBElement<TReqStatusOutput> createDisableDataBoxExternallyResponse(TReqStatusOutput value) {
        return new JAXBElement<TReqStatusOutput>(_DisableDataBoxExternallyResponse_QNAME, TReqStatusOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TReqStatusOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "ClearEffectiveOVMResponse")
    public JAXBElement<TReqStatusOutput> createClearEffectiveOVMResponse(TReqStatusOutput value) {
        return new JAXBElement<TReqStatusOutput>(_ClearEffectiveOVMResponse_QNAME, TReqStatusOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TIdDbInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "SetEffectiveOVM")
    public JAXBElement<TIdDbInput> createSetEffectiveOVM(TIdDbInput value) {
        return new JAXBElement<TIdDbInput>(_SetEffectiveOVM_QNAME, TIdDbInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TOwnerInfoInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "DisableOwnDataBox")
    public JAXBElement<TOwnerInfoInput> createDisableOwnDataBox(TOwnerInfoInput value) {
        return new JAXBElement<TOwnerInfoInput>(_DisableOwnDataBox_QNAME, TOwnerInfoInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TFindDBOuput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "FindDataBoxResponse")
    public JAXBElement<TFindDBOuput> createFindDataBoxResponse(TFindDBOuput value) {
        return new JAXBElement<TFindDBOuput>(_FindDataBoxResponse_QNAME, TFindDBOuput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TGetPasswInfoOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "GetPasswordInfoResponse")
    public JAXBElement<TGetPasswInfoOutput> createGetPasswordInfoResponse(TGetPasswInfoOutput value) {
        return new JAXBElement<TGetPasswInfoOutput>(_GetPasswordInfoResponse_QNAME, TGetPasswInfoOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TIdDbInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "CheckDataBox")
    public JAXBElement<TIdDbInput> createCheckDataBox(TIdDbInput value) {
        return new JAXBElement<TIdDbInput>(_CheckDataBox_QNAME, TIdDbInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TFindDBInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "FindDataBox")
    public JAXBElement<TFindDBInput> createFindDataBox(TFindDBInput value) {
        return new JAXBElement<TFindDBInput>(_FindDataBox_QNAME, TFindDBInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TReqStatusOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "ChangeISDSPasswordResponse")
    public JAXBElement<TReqStatusOutput> createChangeISDSPasswordResponse(TReqStatusOutput value) {
        return new JAXBElement<TReqStatusOutput>(_ChangeISDSPasswordResponse_QNAME, TReqStatusOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TChngPasswInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "ChangeISDSPassword")
    public JAXBElement<TChngPasswInput> createChangeISDSPassword(TChngPasswInput value) {
        return new JAXBElement<TChngPasswInput>(_ChangeISDSPassword_QNAME, TChngPasswInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TGetOwnInfoOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "GetOwnerInfoFromLoginResponse")
    public JAXBElement<TGetOwnInfoOutput> createGetOwnerInfoFromLoginResponse(TGetOwnInfoOutput value) {
        return new JAXBElement<TGetOwnInfoOutput>(_GetOwnerInfoFromLoginResponse_QNAME, TGetOwnInfoOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TDeleteDBInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "DeleteDataBox")
    public JAXBElement<TDeleteDBInput> createDeleteDataBox(TDeleteDBInput value) {
        return new JAXBElement<TDeleteDBInput>(_DeleteDataBox_QNAME, TDeleteDBInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TCheckDBOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "CheckDataBoxResponse")
    public JAXBElement<TCheckDBOutput> createCheckDataBoxResponse(TCheckDBOutput value) {
        return new JAXBElement<TCheckDBOutput>(_CheckDataBoxResponse_QNAME, TCheckDBOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TIdDbInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "ClearOpenAddressing")
    public JAXBElement<TIdDbInput> createClearOpenAddressing(TIdDbInput value) {
        return new JAXBElement<TIdDbInput>(_ClearOpenAddressing_QNAME, TIdDbInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TGetDBListInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "GetDataBoxList")
    public JAXBElement<TGetDBListInput> createGetDataBoxList(TGetDBListInput value) {
        return new JAXBElement<TGetDBListInput>(_GetDataBoxList_QNAME, TGetDBListInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TActivateInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "Activate")
    public JAXBElement<TActivateInput> createActivate(TActivateInput value) {
        return new JAXBElement<TActivateInput>(_Activate_QNAME, TActivateInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TUpdateDBInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "UpdateDataBoxDescr")
    public JAXBElement<TUpdateDBInput> createUpdateDataBoxDescr(TUpdateDBInput value) {
        return new JAXBElement<TUpdateDBInput>(_UpdateDataBoxDescr_QNAME, TUpdateDBInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TActivateOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "ActivateResponse")
    public JAXBElement<TActivateOutput> createActivateResponse(TActivateOutput value) {
        return new JAXBElement<TActivateOutput>(_ActivateResponse_QNAME, TActivateOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TReqStatusOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "UpdateDataBoxDescrResponse")
    public JAXBElement<TReqStatusOutput> createUpdateDataBoxDescrResponse(TReqStatusOutput value) {
        return new JAXBElement<TReqStatusOutput>(_UpdateDataBoxDescrResponse_QNAME, TReqStatusOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TReqStatusOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "DisableOwnDataBoxResponse")
    public JAXBElement<TReqStatusOutput> createDisableOwnDataBoxResponse(TReqStatusOutput value) {
        return new JAXBElement<TReqStatusOutput>(_DisableOwnDataBoxResponse_QNAME, TReqStatusOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TIdDbInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "GetDataBoxUsers")
    public JAXBElement<TIdDbInput> createGetDataBoxUsers(TIdDbInput value) {
        return new JAXBElement<TIdDbInput>(_GetDataBoxUsers_QNAME, TIdDbInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TGetUserInfoOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "GetUserInfoFromLoginResponse")
    public JAXBElement<TGetUserInfoOutput> createGetUserInfoFromLoginResponse(TGetUserInfoOutput value) {
        return new JAXBElement<TGetUserInfoOutput>(_GetUserInfoFromLoginResponse_QNAME, TGetUserInfoOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TDbReqStatus }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbStatus")
    public JAXBElement<TDbReqStatus> createDbStatus(TDbReqStatus value) {
        return new JAXBElement<TDbReqStatus>(_DbStatus_QNAME, TDbReqStatus.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TNewAccDataOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "NewAccessDataResponse")
    public JAXBElement<TNewAccDataOutput> createNewAccessDataResponse(TNewAccDataOutput value) {
        return new JAXBElement<TNewAccDataOutput>(_NewAccessDataResponse_QNAME, TNewAccDataOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TReqStatusOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "SetOpenAddressingResponse")
    public JAXBElement<TReqStatusOutput> createSetOpenAddressingResponse(TReqStatusOutput value) {
        return new JAXBElement<TReqStatusOutput>(_SetOpenAddressingResponse_QNAME, TReqStatusOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TUpdDBUserInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "UpdateDataBoxUser")
    public JAXBElement<TUpdDBUserInput> createUpdateDataBoxUser(TUpdDBUserInput value) {
        return new JAXBElement<TUpdDBUserInput>(_UpdateDataBoxUser_QNAME, TUpdDBUserInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TNewAccDataInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "NewAccessData")
    public JAXBElement<TNewAccDataInput> createNewAccessData(TNewAccDataInput value) {
        return new JAXBElement<TNewAccDataInput>(_NewAccessData_QNAME, TNewAccDataInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TCreateDBPFOInfoOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "CreateDataBoxPFOInfoResponse")
    public JAXBElement<TCreateDBPFOInfoOutput> createCreateDataBoxPFOInfoResponse(TCreateDBPFOInfoOutput value) {
        return new JAXBElement<TCreateDBPFOInfoOutput>(_CreateDataBoxPFOInfoResponse_QNAME, TCreateDBPFOInfoOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TDummyInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "GetPasswordInfo")
    public JAXBElement<TDummyInput> createGetPasswordInfo(TDummyInput value) {
        return new JAXBElement<TDummyInput>(_GetPasswordInfo_QNAME, TDummyInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TAddDBUserInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "AddDataBoxUser")
    public JAXBElement<TAddDBUserInput> createAddDataBoxUser(TAddDBUserInput value) {
        return new JAXBElement<TAddDBUserInput>(_AddDataBoxUser_QNAME, TAddDBUserInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TDisableExternallyInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "DisableDataBoxExternally")
    public JAXBElement<TDisableExternallyInput> createDisableDataBoxExternally(TDisableExternallyInput value) {
        return new JAXBElement<TDisableExternallyInput>(_DisableDataBoxExternally_QNAME, TDisableExternallyInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TCreateDBPFOInfoInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "CreateDataBoxPFOInfo")
    public JAXBElement<TCreateDBPFOInfoInput> createCreateDataBoxPFOInfo(TCreateDBPFOInfoInput value) {
        return new JAXBElement<TCreateDBPFOInfoInput>(_CreateDataBoxPFOInfo_QNAME, TCreateDBPFOInfoInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TCreateDBOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "CreateDataBoxResponse")
    public JAXBElement<TCreateDBOutput> createCreateDataBoxResponse(TCreateDBOutput value) {
        return new JAXBElement<TCreateDBOutput>(_CreateDataBoxResponse_QNAME, TCreateDBOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TCreateDBInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "CreateDataBox")
    public JAXBElement<TCreateDBInput> createCreateDataBox(TCreateDBInput value) {
        return new JAXBElement<TCreateDBInput>(_CreateDataBox_QNAME, TCreateDBInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TDummyInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "GetUserInfoFromLogin")
    public JAXBElement<TDummyInput> createGetUserInfoFromLogin(TDummyInput value) {
        return new JAXBElement<TDummyInput>(_GetUserInfoFromLogin_QNAME, TDummyInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TDelDBUserInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "DeleteDataBoxUser")
    public JAXBElement<TDelDBUserInput> createDeleteDataBoxUser(TDelDBUserInput value) {
        return new JAXBElement<TDelDBUserInput>(_DeleteDataBoxUser_QNAME, TDelDBUserInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TDummyInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "GetOwnerInfoFromLogin")
    public JAXBElement<TDummyInput> createGetOwnerInfoFromLogin(TDummyInput value) {
        return new JAXBElement<TDummyInput>(_GetOwnerInfoFromLogin_QNAME, TDummyInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TReqStatusOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "ClearOpenAddressingResponse")
    public JAXBElement<TReqStatusOutput> createClearOpenAddressingResponse(TReqStatusOutput value) {
        return new JAXBElement<TReqStatusOutput>(_ClearOpenAddressingResponse_QNAME, TReqStatusOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TAddDBUserOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "AddDataBoxUserResponse")
    public JAXBElement<TAddDBUserOutput> createAddDataBoxUserResponse(TAddDBUserOutput value) {
        return new JAXBElement<TAddDBUserOutput>(_AddDataBoxUserResponse_QNAME, TAddDBUserOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TGetDBListOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "GetDataBoxListResponse")
    public JAXBElement<TGetDBListOutput> createGetDataBoxListResponse(TGetDBListOutput value) {
        return new JAXBElement<TGetDBListOutput>(_GetDataBoxListResponse_QNAME, TGetDBListOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TIdDbInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "SetOpenAddressing")
    public JAXBElement<TIdDbInput> createSetOpenAddressing(TIdDbInput value) {
        return new JAXBElement<TIdDbInput>(_SetOpenAddressing_QNAME, TIdDbInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TOwnerInfoInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "EnableOwnDataBox")
    public JAXBElement<TOwnerInfoInput> createEnableOwnDataBox(TOwnerInfoInput value) {
        return new JAXBElement<TOwnerInfoInput>(_EnableOwnDataBox_QNAME, TOwnerInfoInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TReqStatusOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "UpdateDataBoxUserResponse")
    public JAXBElement<TReqStatusOutput> createUpdateDataBoxUserResponse(TReqStatusOutput value) {
        return new JAXBElement<TReqStatusOutput>(_UpdateDataBoxUserResponse_QNAME, TReqStatusOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TIdDbInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "ClearEffectiveOVM")
    public JAXBElement<TIdDbInput> createClearEffectiveOVM(TIdDbInput value) {
        return new JAXBElement<TIdDbInput>(_ClearEffectiveOVM_QNAME, TIdDbInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TReqStatusOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "EnableOwnDataBoxResponse")
    public JAXBElement<TReqStatusOutput> createEnableOwnDataBoxResponse(TReqStatusOutput value) {
        return new JAXBElement<TReqStatusOutput>(_EnableOwnDataBoxResponse_QNAME, TReqStatusOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TReqStatusOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "SetEffectiveOVMResponse")
    public JAXBElement<TReqStatusOutput> createSetEffectiveOVMResponse(TReqStatusOutput value) {
        return new JAXBElement<TReqStatusOutput>(_SetEffectiveOVMResponse_QNAME, TReqStatusOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TGetDBUsersOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "GetDataBoxUsersResponse")
    public JAXBElement<TGetDBUsersOutput> createGetDataBoxUsersResponse(TGetDBUsersOutput value) {
        return new JAXBElement<TGetDBUsersOutput>(_GetDataBoxUsersResponse_QNAME, TGetDBUsersOutput.class, null, value);
    }

}
