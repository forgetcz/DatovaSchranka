
package cz.czechpoint.isds.v20;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for tAddDBUserInput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tAddDBUserInput">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="dbOwnerInfo" type="{http://isds.czechpoint.cz/v20}tDbOwnerInfo"/>
 *         &lt;element name="dbUserInfo" type="{http://isds.czechpoint.cz/v20}tDbUserInfo"/>
 *         &lt;element name="dbVirtual" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="email" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;group ref="{http://isds.czechpoint.cz/v20}gExtApproval"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tAddDBUserInput", propOrder = {
    "dbOwnerInfo",
    "dbUserInfo",
    "dbVirtual",
    "email",
    "dbApproved",
    "dbExternRefNumber"
})
public class TAddDBUserInput {

    @XmlElement(required = true)
    protected TDbOwnerInfo dbOwnerInfo;
    @XmlElement(required = true)
    protected TDbUserInfo dbUserInfo;
    protected Boolean dbVirtual;
    @XmlElement(nillable = true)
    protected String email;
    @XmlElement(nillable = true)
    protected Boolean dbApproved;
    @XmlElement(nillable = true)
    protected String dbExternRefNumber;

    /**
     * Gets the value of the dbOwnerInfo property.
     * 
     * @return
     *     possible object is
     *     {@link TDbOwnerInfo }
     *     
     */
    public TDbOwnerInfo getDbOwnerInfo() {
        return dbOwnerInfo;
    }

    /**
     * Sets the value of the dbOwnerInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link TDbOwnerInfo }
     *     
     */
    public void setDbOwnerInfo(TDbOwnerInfo value) {
        this.dbOwnerInfo = value;
    }

    /**
     * Gets the value of the dbUserInfo property.
     * 
     * @return
     *     possible object is
     *     {@link TDbUserInfo }
     *     
     */
    public TDbUserInfo getDbUserInfo() {
        return dbUserInfo;
    }

    /**
     * Sets the value of the dbUserInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link TDbUserInfo }
     *     
     */
    public void setDbUserInfo(TDbUserInfo value) {
        this.dbUserInfo = value;
    }

    /**
     * Gets the value of the dbVirtual property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDbVirtual() {
        return dbVirtual;
    }

    /**
     * Sets the value of the dbVirtual property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDbVirtual(Boolean value) {
        this.dbVirtual = value;
    }

    /**
     * Gets the value of the email property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the value of the email property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmail(String value) {
        this.email = value;
    }

    /**
     * Gets the value of the dbApproved property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDbApproved() {
        return dbApproved;
    }

    /**
     * Sets the value of the dbApproved property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDbApproved(Boolean value) {
        this.dbApproved = value;
    }

    /**
     * Gets the value of the dbExternRefNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbExternRefNumber() {
        return dbExternRefNumber;
    }

    /**
     * Sets the value of the dbExternRefNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbExternRefNumber(String value) {
        this.dbExternRefNumber = value;
    }

}
