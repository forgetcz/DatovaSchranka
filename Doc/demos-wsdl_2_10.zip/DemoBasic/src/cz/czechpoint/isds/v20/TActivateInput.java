
package cz.czechpoint.isds.v20;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for tActivateInput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tActivateInput">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="dbAccessDataId" type="{http://isds.czechpoint.cz/v20}tDbAccessDataId"/>
 *         &lt;element name="dbID" type="{http://isds.czechpoint.cz/v20}tIdDb"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tActivateInput", propOrder = {
    "dbAccessDataId",
    "dbID"
})
public class TActivateInput {

    @XmlElement(required = true)
    protected String dbAccessDataId;
    @XmlElement(required = true)
    protected String dbID;

    /**
     * Gets the value of the dbAccessDataId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbAccessDataId() {
        return dbAccessDataId;
    }

    /**
     * Sets the value of the dbAccessDataId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbAccessDataId(String value) {
        this.dbAccessDataId = value;
    }

    /**
     * Gets the value of the dbID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbID() {
        return dbID;
    }

    /**
     * Sets the value of the dbID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbID(String value) {
        this.dbID = value;
    }

}
