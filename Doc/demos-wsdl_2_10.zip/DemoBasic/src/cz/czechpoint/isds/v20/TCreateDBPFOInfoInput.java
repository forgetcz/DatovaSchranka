
package cz.czechpoint.isds.v20;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for tCreateDBPFOInfoInput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tCreateDBPFOInfoInput">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="dbOwnerInfo" type="{http://isds.czechpoint.cz/v20}tDbOwnerInfo"/>
 *         &lt;element name="dbPrimaryUsers" type="{http://isds.czechpoint.cz/v20}tDbUsersArray"/>
 *         &lt;element name="dbFormerNames" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dbUpperDBId" type="{http://isds.czechpoint.cz/v20}tIdDb" minOccurs="0"/>
 *         &lt;element name="dbCEOLabel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;group ref="{http://isds.czechpoint.cz/v20}gExtApproval"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tCreateDBPFOInfoInput", propOrder = {
    "dbOwnerInfo",
    "dbPrimaryUsers",
    "dbFormerNames",
    "dbUpperDBId",
    "dbCEOLabel",
    "dbApproved",
    "dbExternRefNumber"
})
public class TCreateDBPFOInfoInput {

    @XmlElement(required = true)
    protected TDbOwnerInfo dbOwnerInfo;
    @XmlElement(required = true)
    protected TDbUsersArray dbPrimaryUsers;
    @XmlElement(nillable = true)
    protected String dbFormerNames;
    @XmlElement(nillable = true)
    protected String dbUpperDBId;
    @XmlElement(nillable = true)
    protected String dbCEOLabel;
    @XmlElement(nillable = true)
    protected Boolean dbApproved;
    @XmlElement(nillable = true)
    protected String dbExternRefNumber;

    /**
     * Gets the value of the dbOwnerInfo property.
     * 
     * @return
     *     possible object is
     *     {@link TDbOwnerInfo }
     *     
     */
    public TDbOwnerInfo getDbOwnerInfo() {
        return dbOwnerInfo;
    }

    /**
     * Sets the value of the dbOwnerInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link TDbOwnerInfo }
     *     
     */
    public void setDbOwnerInfo(TDbOwnerInfo value) {
        this.dbOwnerInfo = value;
    }

    /**
     * Gets the value of the dbPrimaryUsers property.
     * 
     * @return
     *     possible object is
     *     {@link TDbUsersArray }
     *     
     */
    public TDbUsersArray getDbPrimaryUsers() {
        return dbPrimaryUsers;
    }

    /**
     * Sets the value of the dbPrimaryUsers property.
     * 
     * @param value
     *     allowed object is
     *     {@link TDbUsersArray }
     *     
     */
    public void setDbPrimaryUsers(TDbUsersArray value) {
        this.dbPrimaryUsers = value;
    }

    /**
     * Gets the value of the dbFormerNames property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbFormerNames() {
        return dbFormerNames;
    }

    /**
     * Sets the value of the dbFormerNames property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbFormerNames(String value) {
        this.dbFormerNames = value;
    }

    /**
     * Gets the value of the dbUpperDBId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbUpperDBId() {
        return dbUpperDBId;
    }

    /**
     * Sets the value of the dbUpperDBId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbUpperDBId(String value) {
        this.dbUpperDBId = value;
    }

    /**
     * Gets the value of the dbCEOLabel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbCEOLabel() {
        return dbCEOLabel;
    }

    /**
     * Sets the value of the dbCEOLabel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbCEOLabel(String value) {
        this.dbCEOLabel = value;
    }

    /**
     * Gets the value of the dbApproved property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDbApproved() {
        return dbApproved;
    }

    /**
     * Sets the value of the dbApproved property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDbApproved(Boolean value) {
        this.dbApproved = value;
    }

    /**
     * Gets the value of the dbExternRefNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbExternRefNumber() {
        return dbExternRefNumber;
    }

    /**
     * Sets the value of the dbExternRefNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbExternRefNumber(String value) {
        this.dbExternRefNumber = value;
    }

}
