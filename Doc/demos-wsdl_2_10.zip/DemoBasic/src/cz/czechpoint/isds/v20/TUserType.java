
package cz.czechpoint.isds.v20;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for tUserType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="tUserType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="PRIMARY_USER"/>
 *     &lt;enumeration value="ENTRUSTED_USER"/>
 *     &lt;enumeration value="ADMINISTRATOR"/>
 *     &lt;enumeration value="OFFICIAL"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "tUserType")
@XmlEnum
public enum TUserType {

    PRIMARY_USER,
    ENTRUSTED_USER,
    ADMINISTRATOR,
    OFFICIAL;

    public String value() {
        return name();
    }

    public static TUserType fromValue(String v) {
        return valueOf(v);
    }

}
