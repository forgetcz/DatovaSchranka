package demoisds;

import cz.czechpoint.isds.v20.DataBoxSearch;
import cz.czechpoint.isds.v20.DataBoxSearchPortType;
import cz.czechpoint.isds.v20.DmInfoPortType;
import cz.czechpoint.isds.v20.DmInfoWebService;
import cz.czechpoint.isds.v20.DmOperationsPortType;
import cz.czechpoint.isds.v20.DmOperationsWebService;
import cz.czechpoint.isds.v20.TDbOwnerInfo;
import cz.czechpoint.isds.v20.TDbOwnersArray;
import cz.czechpoint.isds.v20.TDbReqStatus;
import cz.czechpoint.isds.v20.TDbType;
import cz.czechpoint.isds.v20.TFilesArray;
import cz.czechpoint.isds.v20.THash;
import cz.czechpoint.isds.v20.TMessageEnvelopeSub;
import cz.czechpoint.isds.v20.TRecord;
import cz.czechpoint.isds.v20.TRecordsArray;
import cz.czechpoint.isds.v20.TStateChangesArray;
import cz.czechpoint.isds.v20.TStateChangesRecord;
import cz.czechpoint.isds.v20.TStatus;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Holder;

/**
 * Hlavni trida pro testovani zprav.
 * 20.12.2010
 * @author Jan Vávra, isds@software602.cz
 */
public class Main {

  /**
   * Priklad je konstruovan pro pouziti s testovacim rozhranim.
   * Pokud bude kod pouzivat proti produkcnimu prostredi, pak zajistete spravnou
   * hodnotu anotaci wsdlLocation. Ty jsou nyni nasmerovany na test a neni zaruceno,
   * ze tam budou.
   *
   * Url pro produkcni prostedi budou oznameny.
   */
  public static final String APP_TEST_BASIC = "https://ws1.czebox.cz";
  public static final String APP_TEST_SYSTEM_CERT = "https://ws1c.czebox.cz/cert";
  public static final String APP_TEST_BASIC_AND_CERT = "https://ws1c.czebox.cz/certds";
  public static final String APP_TEST_HSPIS = "https://ws1c.czebox.cz/hspis";

  /**
   * Stahne zpravu s podpisem.
   * @param port port webove sluzby.
   * @param message_id id zpravy
   * @throws java.lang.Exception
   */
  private static void download_signed_message(DmOperationsPortType port, String message_id) throws Exception {
    Holder<byte[]> dmSignature = new Holder<byte[]>();
    Holder<TStatus> dmStatus = new Holder<TStatus>();

    port.signedMessageDownload(message_id, dmSignature, dmStatus);
    System.out.println("Signed message download status: " + dmStatus.value.getDmStatusMessage());
    if (dmStatus.value.getDmStatusCode().compareTo("0000") == 0) {
      // Create file
      FileOutputStream fstream = new FileOutputStream("message_content.zfo");
      fstream.write(dmSignature.value);
      fstream.close();

      System.out.println("message content written to " +
              new File(".").getCanonicalPath() + File.separator +
              "message_content.zfo file");
    }
  }

  public static void check_databox(DataBoxSearchPortType dataBoxSearchPort, String dbID) throws Exception {
    Boolean dbApproved = null;
    String dbExternRefNumber = null;
    Holder<Integer> dbState = new Holder<Integer>();
    Holder<TDbReqStatus> dbStatus = new Holder<TDbReqStatus>();

    dataBoxSearchPort.checkDataBox(dbID, dbApproved, dbExternRefNumber, dbState, dbStatus);
    System.out.println("status: " + dbStatus.value.getDbStatusMessage());
    if (dbStatus.value.getDbStatusCode().compareTo("0000") == 0) {
      System.out.println("state of box " + dbID + " is: " + dbState.value.toString());
    }

  }

  /**
   * Vyhleda schranku podle ukazkove struktury dbOwnerInfo, kde vyplni jen polozku nazev firmy.
   * Nazev firmy musi mit alespon 3 pismena.
   * @param dataBoxSearchPort
   * @throws java.lang.Exception
   */
  private static void search_databox(DataBoxSearchPortType dataBoxSearchPort) throws Exception {
    TDbOwnerInfo dbOwnerInfo = new TDbOwnerInfo();
    dbOwnerInfo.setAdCity("");
    dbOwnerInfo.setAdNumberInMunicipality("");
    dbOwnerInfo.setAdNumberInStreet("");
    dbOwnerInfo.setAdState("");
    dbOwnerInfo.setAdStreet("");
    dbOwnerInfo.setAdZipCode("");

    DatatypeFactory dataTypeFactory = DatatypeFactory.newInstance();
    XMLGregorianCalendar bidate = dataTypeFactory.newXMLGregorianCalendar(
            1981, 3, 7, //rok, mesic, den
            0, 0, 0, 0, //hod, min, sec, msec
            0); //zone offset

    dbOwnerInfo.setBiDate(bidate);
    dbOwnerInfo.setBiCity("");
    dbOwnerInfo.setBiCounty("");
    dbOwnerInfo.setBiState("");
    dbOwnerInfo.setPnFirstName("");
    dbOwnerInfo.setPnLastName("");
    dbOwnerInfo.setDbType(TDbType.OVM);
    dbOwnerInfo.setFirmName("Ministerstvo vnitra");

    Holder<TDbOwnersArray> dbResults = new Holder<TDbOwnersArray>();
    Holder<TDbReqStatus> dbStatus = new Holder<TDbReqStatus>();
    dataBoxSearchPort.findDataBox(dbOwnerInfo, dbResults, dbStatus);
    System.out.println("search_databox status: " + dbStatus.value.getDbStatusMessage());
    if (dbStatus.value.getDbStatusCode().compareTo("0000") == 0) {
      Iterator<TDbOwnerInfo> it = dbResults.value.getDbOwnerInfo().iterator();
      while (it.hasNext()) {
        TDbOwnerInfo owner = it.next();
        System.out.println("firmname: " + owner.getFirmName() + ", dbid: " + owner.getDbID());
      }
    }
  }

  /**
   * Overi zpravu.
   * @param port port webove sluzby.
   * @param message_id id zpravy.
   * @throws java.lang.Exception
   */
  private static void verify_message(DmInfoPortType port, String message_id) throws Exception {
    Holder<THash> dmHash = new Holder<THash>();
    Holder<TStatus> dmStatus = new Holder<TStatus>();


    port.verifyMessage(message_id, dmHash, dmStatus);
    String h = (dmHash.value != null ? " (hash:  " + dmHash.value.getValue() + ") " : "");
    System.out.println(">>> Status of " + message_id +
            h +
            dmStatus.value.getDmStatusMessage());

  }

  /**
   * Načte obsah souboru z disku.
   * @param path cesta.
   * @return obsah souboru.
   * @throws java.io.FileNotFoundException
   * @throws java.io.IOException
   */
  private static byte[] readWholeFile(String path) throws FileNotFoundException, IOException {
    File f = new File(path);
    FileInputStream fis = new FileInputStream(f);
    long filelen = f.length();
    byte[] buf = new byte[(int) filelen];
    fis.read(buf);
    fis.close();

    return buf;
  }

  /**
   * Vypise seznam zmen stavu zprav za poslednich 7 dnu.
   * @param port DmInfoPort
   * @throws DatatypeConfigurationException
   */
  private static void getMessagesStateChanges(DmInfoPortType port) throws DatatypeConfigurationException {

    DatatypeFactory dataTypeFactory = DatatypeFactory.newInstance();
    Holder<TStatus> status = new Holder<TStatus>();
    Holder<TStateChangesArray> changesArray = new Holder<TStateChangesArray>();

    //zajima nas obdobi od -7dni do soucasnosti
    GregorianCalendar gcTo = new GregorianCalendar();
    gcTo.setTimeInMillis(System.currentTimeMillis()); //konec intervalu je soucasny okamzik
    XMLGregorianCalendar xmlToTime = dataTypeFactory.newXMLGregorianCalendar(gcTo);

    GregorianCalendar gcFrom = new GregorianCalendar();
    gcFrom.setTimeInMillis(gcTo.getTimeInMillis());
    gcFrom.add(Calendar.DATE, -7); //zacatek intervalu pred 7 dny od soucasnosti
    XMLGregorianCalendar xmlFromTime = dataTypeFactory.newXMLGregorianCalendar(gcFrom);

    port.getMessageStateChanges(xmlFromTime, xmlToTime, changesArray, status);

    if (status.value.getDmStatusCode().equals("0000")) {

      System.out.println("Zmeny stavu zprav za poslednich 7 dnu:");
      //vypis vsech zmen
      for (TStateChangesRecord record : changesArray.value.getDmRecord()) {
        System.out.println("ID zpravy "+record.getDmID() + "; cas zmeny " + record.getDmEventTime() + "; stav " + record.getDmMessageStatus());
      }
    }

  }

  /**
   * Vytvori zpravu s konstantnimi hodnotami.
   * @param port port webove sluzby.
   * @throws java.lang.Exception
   */
  private static void create_message(DmOperationsPortType port, String ISDSBoxID_tosend_message) throws Exception {
    TMessageEnvelopeSub dmEnvelope = new TMessageEnvelopeSub();
    TFilesArray dmFiles = new TFilesArray();
    Holder<String> dmID = new Holder<String>();
    Holder<TStatus> dmStatus = new Holder<TStatus>();

    dmEnvelope.setDbIDRecipient(ISDSBoxID_tosend_message);
    dmEnvelope.setDmAllowSubstDelivery(false);
    dmEnvelope.setDmAnnotation("Testovací zpráva");
    dmEnvelope.setDmLegalTitleLaw(BigInteger.valueOf(677));
    dmEnvelope.setDmLegalTitlePar("231");
    dmEnvelope.setDmLegalTitlePoint("179");
    dmEnvelope.setDmLegalTitleSect("331");
    dmEnvelope.setDmLegalTitleYear(BigInteger.valueOf(2010));
    dmEnvelope.setDmPersonalDelivery(false);
    dmEnvelope.setDmRecipientIdent("VZ-147");
    dmEnvelope.setDmRecipientOrgUnit("Vaše org. jednotka");
    dmEnvelope.setDmRecipientOrgUnitNum(BigInteger.valueOf(-1));
    dmEnvelope.setDmRecipientRefNumber("včj. 253");
    dmEnvelope.setDmSenderIdent("NZ-557");
    dmEnvelope.setDmSenderOrgUnit("Naše org. jednotka");
    //dmEnvelope.setDmSenderOrgUnitNum()
    dmEnvelope.setDmSenderRefNumber("nčj. 589");
    dmEnvelope.setDmToHands("K rukám p. Nováka");

    //pridej jeden attachment
    TFilesArray.DmFile file = new TFilesArray.DmFile();
    file.setDmFileDescr("test.txt");
    file.setDmFileGuid("");
    file.setDmMimeType("enclosure");
    file.setDmFormat("");
    file.setDmFormat("");
    file.setDmMimeType("text/plain");
    file.setDmFileGuid("");
    file.setDmEncodedContent("Testovací obsah souboru v kódování utf-8.".getBytes("UTF-8"));
    dmFiles.getDmFile().add(file);

    port.createMessage(dmEnvelope, dmFiles, dmID, dmStatus);

    System.out.println("Created message. dmID: " + dmID.value +
            ", dmStatus " + dmStatus.value.getDmStatusCode() +
            ": " + dmStatus.value.getDmStatusMessage());
  }

  private static String caltostr(Calendar calendar) {
    // define output format and print
    SimpleDateFormat sdf = new SimpleDateFormat("d MMM yyyy hh:mm aaa");
    return sdf.format(calendar.getTime());
  }

  private static class DmRecordComparator implements Comparator<TRecord> {

    public int compare(TRecord a, TRecord b) {
      // - je pro sestupne trideni
      return -a.getDmDeliveryTime().compare(b.getDmDeliveryTime());
    }
  }

  /**
   * Vrati prijate zpravy.
   * @param port webove sluzby.
   * @return prijate zpravy.
   * @throws java.lang.Exception
   */
  private static Iterator<TRecord> get_received_messages(DmInfoPortType port) throws Exception {
    DatatypeFactory dataTypeFactory = DatatypeFactory.newInstance();
    Calendar cfrom = Calendar.getInstance();
    cfrom.add(Calendar.DATE, -90); // minus 90 dni
    System.out.print("from: " + caltostr(cfrom));

    //pred tremi mesici
    XMLGregorianCalendar dmFromTime = dataTypeFactory.newXMLGregorianCalendar(cfrom.get(Calendar.YEAR),
            cfrom.get(Calendar.MONTH) + 1,
            cfrom.get(Calendar.DAY_OF_MONTH),
            0, 0, 0, 0,
            cfrom.get(Calendar.ZONE_OFFSET) / 3600000);
    System.out.println(" == " + dmFromTime.toXMLFormat());

    Calendar cto = Calendar.getInstance();
    cto.add(Calendar.DAY_OF_MONTH, 1);

    //dnes
    XMLGregorianCalendar dmToTime = dataTypeFactory.newXMLGregorianCalendar(cto.get(Calendar.YEAR),
            cto.get(Calendar.MONTH) + 1,
            cto.get(Calendar.DAY_OF_MONTH),
            0, 0, 0, 0,
            cto.get(Calendar.ZONE_OFFSET) / 3600000);
    System.out.println("to: " + dmToTime.toXMLFormat());

    BigInteger dmRecipientOrgUnitNum = null;
    String dmStatusFilter = null;
    BigInteger dmOffset = BigInteger.valueOf(1);
    BigInteger dmLimit = BigInteger.valueOf(100000);
    Holder<TRecordsArray> dmRecords = new Holder<TRecordsArray>();
    Holder<TStatus> dmStatus = new Holder<TStatus>();


    port.getListOfReceivedMessages(dmFromTime,
            dmToTime,
            dmRecipientOrgUnitNum,
            dmStatusFilter,
            dmOffset,
            dmLimit,
            dmRecords,
            dmStatus);

    System.out.println("getListOfReceivedMessages() status: " + dmStatus.value.getDmStatusMessage());

    //setrideni podle casu doruceni
    List<TRecord> list = dmRecords.value.getDmRecord();
    DmRecordComparator comp = new DmRecordComparator();
    Collections.sort(list, comp);

    //ziskani iteratoru pres jednotlive polozky
    Iterator<TRecord> it = list.iterator();

    System.out.println("getListOfReceivedMessages() received count: " + dmRecords.value.getDmRecord().size());
    while (it.hasNext()) {
      TRecord rec = it.next();
      System.out.println("id: " + rec.getDmID() + "\tstatus: " + rec.getDmMessageStatus() + "\tto: " + rec.getDmSenderAddress() + "\taccepted: " + rec.getDmAcceptanceTime() + "\tdelivery: " + rec.getDmDeliveryTime());

      //setridit podle delivery time
    }
    it = dmRecords.value.getDmRecord().iterator(); //nastav iterator na zacatek
    return it;
  }

  /**
   * Příkldad pro použití s JAX-WS knihovnou
   * @param cr přihlašovací údaje.
   * @throws Exception
   */
  public static void run_jaxws(Credentials cr, String appUrl) throws Exception {
    //uri sluzeb
    String dm_info_service_uri = appUrl + "/DS/dx";
    String dm_operations_service_uri = appUrl + "/DS/dz";
    String db_search_service_uri = appUrl + "/DS/df";

    // kontext pro volani sluzeb
    ServiceManager smng = ServiceManager.getServiceManager();

    // ziskame remote interface pro dmInfoPortType
    DmInfoWebService dmInfoService = new DmInfoWebService();
    DmInfoPortType dmInfoPort = dmInfoService.getDmInfoPortType();

    // nastavime uri pro pripojeni (null, vezme se default hodnota) a autentizujeme sluzbu
    smng.set_service_uri((BindingProvider) dmInfoPort, dm_info_service_uri);
    smng.authenticate((BindingProvider) dmInfoPort,
            dm_info_service_uri,
            cr.getLoginName1(),
            cr.getPassword1(),
            cr.getCliCertFilePath(),
            cr.getCliCertPassword());

    // ziskame remote interface pro dmOperationsWebService
    DmOperationsWebService dmOperationsService = new DmOperationsWebService();
    DmOperationsPortType dmOperationsPort = dmOperationsService.getDmOperationsPortType();

    // nastavime uri pro pripojeni (null, vezme se default hodnota) a autentizujeme sluzbu
    smng.set_service_uri((BindingProvider) dmOperationsPort, dm_operations_service_uri);
    smng.authenticate((BindingProvider) dmOperationsPort,
            dm_operations_service_uri,
            cr.getLoginName1(),
            cr.getPassword1(),
            cr.getCliCertFilePath(),
            cr.getCliCertPassword());

    //ziskame remote interface pro db_search
    DataBoxSearch dataBoxSearchService = new DataBoxSearch();
    DataBoxSearchPortType dataBoxSearchPort = dataBoxSearchService.getDataBoxSearchPortType();
    //nastavime uri pro pripojeni
    smng.set_service_uri((BindingProvider) dataBoxSearchPort, db_search_service_uri);
    smng.authenticate((BindingProvider) dataBoxSearchPort,
            db_search_service_uri,
            cr.getLoginName1(),
            cr.getPassword1(),
            cr.getCliCertFilePath(),
            cr.getCliCertPassword());

    System.out.println();
    System.out.println(">>> Calling services <<< ");
    System.out.println();

    int MAX_FAILURES = 3;
    //Cyklus se snaží zotavit se z chyb při volání operace. Neumí se zotavit z chyb při re-autentizaci.
    for (int failures = 0; failures < MAX_FAILURES; failures++) {
      //vyhledej schranku
      try {
        search_databox(dataBoxSearchPort);
        break;
      } catch (Exception ex) {
        System.err.println(ex + " - trying again...");

        //pockej 20 vterin
        Thread.sleep(20 * 1000);
        //provedeme nove prihlaseni
        smng.authenticate((BindingProvider) dataBoxSearchPort,
                dm_info_service_uri, cr.getLoginName1(), cr.getPassword1(), cr.getCliCertFilePath(), cr.getCliCertPassword());
      }
    }

    //Další příklady volání jsou pro přehlednost bez cyklu pro zotavení se z chyb.

    //poslání zprávy
    create_message(dmOperationsPort, "doplnte id schranky prijemce");

    //vylistuj dosle zpravy
    Iterator<TRecord> it = get_received_messages(dmInfoPort);
    while (it.hasNext()) {
      TRecord rec = it.next();
      System.out.println("dmId: " + rec.getDmID());
    }

    //stahni prvni zpravu
    if (it != null && it.hasNext()) {
      download_signed_message(dmOperationsPort, it.next().getDmID());
    }

    //stahni a vypis seznam zmen stavu odeslanych zprav
    getMessagesStateChanges(dmInfoPort);
  }

  public static void main(String[] args) throws Exception {
    /* Tip: Pro výpis odesílaných a přijatých SOAP zpráv je možné nastavit
     * -Dcom.sun.xml.ws.transport.http.client.HttpTransportPipe.dump=true
     *
     * POZOR: Priklad odkazuje na wsdl, ktere lezi na testovaci rozhrani
     */

    Credentials cr = new Credentials();
    cr.load_lognamepass();

    run_jaxws(cr, APP_TEST_BASIC);
  }
}
