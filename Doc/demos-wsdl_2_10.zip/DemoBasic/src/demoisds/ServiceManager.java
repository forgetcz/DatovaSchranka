package demoisds;

import com.sun.xml.ws.developer.JAXWSProperties;
import java.io.FileNotFoundException;
import java.net.URISyntaxException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import javax.xml.ws.*;
import java.util.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.security.KeyStore;
import java.security.SecureRandom;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;


/**
 * Kontext pro volani webovych sluzeb.
 * @author Jan Vávra, isds@software602.cz
 */
public class ServiceManager {          
    // ssl factory obsahujici klientsky certifikat - z volani getSocketFactory()
    SSLSocketFactory sslSocketFactory = null;
        
    // debug vystupy
    private Boolean verbose = true;

     /**
     * Factory metoda.
     * @return servicemanager.
     * @throws java.net.URISyntaxException
     */
    public static ServiceManager getServiceManager() {
        return new ServiceManager();
    }

    private ServiceManager () {
     
    }
    
    /**
     * Nastavi debug vystupy.
     * @param val true = zapnuto.
     */
    public void set_verbose(Boolean val)
    {
        this.verbose=val;
    }


    /**
     * Nastavi autentizacni cookie. Pro autentizaci vyuzije jmeno, heslo. Volitelne klientsky certifikat.
     * @param provider proxy webove sluzby.
     * @param service_uri uri webove sluzby
     * @param username basic auth jmeno
     * @param password basic auth heslo
     * @param cliCertFilePath cesta k souboru s certifikatem. Muze byt null
     * @param cliCertPassword heslo klientskeho certifikatu.
     * @throws java.lang.Exception
     */
    public void authenticate(BindingProvider provider, String service_uri,
            String username, String password,
            String cliCertFilePath, String cliCertPassword) throws NoSuchAlgorithmException,
            KeyStoreException, FileNotFoundException, IOException, CertificateException,
            UnrecoverableKeyException, KeyManagementException
    {
        if (cliCertFilePath!=null)
        {
            if (sslSocketFactory==null)
                sslSocketFactory =  getSocketFactory(cliCertFilePath, cliCertPassword);
        
            provider.getRequestContext().put(JAXWSProperties.SSL_SOCKET_FACTORY, sslSocketFactory);
        }

        Map requestContext = provider.getRequestContext();
        requestContext.put(BindingProvider.USERNAME_PROPERTY, username);
        requestContext.put(BindingProvider.PASSWORD_PROPERTY, password);
    }


    /**
     * Nastavi klientovi webove sluzby adresu, kam se ma pripojovat.
     * @param provider proxy webove sluzby.
     * @param uri uri pripojeni.
     * @throws java.net.URISyntaxException
     */
    public void set_service_uri(BindingProvider provider, String uri) throws URISyntaxException {
        println("Setting service uri to: "+uri);
        provider.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, uri);
    }
   

    /**
     * Vytvori socket factory obsahujici vlastni certifikat
     * @param cliCertFilePath jmeno souboru s klientskym certifikatem
     * @param pKeyPassword heslo klientskeho certifikatu
     * @return socket factory
     * @throws java.lang.Exception
     */
    private SSLSocketFactory getSocketFactory(String cliCertFilePath, String pKeyPassword)
            throws NoSuchAlgorithmException, KeyStoreException, FileNotFoundException, IOException, 
            CertificateException, UnrecoverableKeyException, KeyManagementException
    {
        KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance("SunX509");

        File pKeyFile = new File(cliCertFilePath);
        KeyStore keyStore = KeyStore.getInstance("PKCS12");

        InputStream keyInput = new FileInputStream(pKeyFile);
        keyStore.load(keyInput, pKeyPassword.toCharArray());
        keyInput.close();

        keyManagerFactory.init(keyStore, pKeyPassword.toCharArray());

        SSLContext context = SSLContext.getInstance("TLS");
        context.init(keyManagerFactory.getKeyManagers(), null, new SecureRandom());

        return context.getSocketFactory();
    }

    /**
     * Debug vypis, pokud je nastaveno verbose.
     * @param s retezec pro vypis.
     */
    private void println(String s) {
        if (verbose)
            System.out.println(s);
    }


     /**
     * Standardni URI.getPort() vraci -1 pro standardni porty.
     * Tohle vraci 80 nebo 443 pro standardni porty.
     * @param uri uri.
     * @return port v uri.
     */
    private int getPort(URI uri) {
        if (uri.getPort()>=0)
            return uri.getPort();
        if (uri.getScheme().compareToIgnoreCase("https")==0)
            return 443;
        return 80;
    }

    /**
     * Nastaveni proxy - funguje i pro jax ws slubhy. Uzitecne pro sledovani toku pozadavku např. pomocí
     * programu Fiddler http://www.fiddler2.com/fiddler2/.
     * @throws java.net.URISyntaxException
     */
    public void set_global_proxy() throws URISyntaxException{
        URI  proxy_uri = new URI("http://127.0.0.1:8888");

        System.setProperty("proxySet", "true");
        System.setProperty("https.proxyHost", proxy_uri.getHost());
        System.setProperty("https.proxyPort", new Integer(getPort(proxy_uri)).toString());
        System.setProperty("http.proxyHost", proxy_uri.getHost());
        System.setProperty("http.proxyPort", new Integer(getPort(proxy_uri)).toString());
    }
  
}