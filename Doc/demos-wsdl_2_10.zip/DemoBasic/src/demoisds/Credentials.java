package demoisds;

import java.io.Console;

/**
 * Přihlašovací údaje
 * @author Jan Vávra, isds@software602.cz
 */
public class Credentials {
    private String LoginName1 = null;
    public String getLoginName1() {
        return LoginName1;
    }

    private String Password1 = null;
    public String getPassword1() {
        return Password1;
    }

    private String cliCertFilePath = null;
    public String getCliCertFilePath() {
        return cliCertFilePath;
    }

    private String cliCertPassword = null;
    public String getCliCertPassword() {
        return cliCertPassword;
    }

    public void load_lognamepass() {
         System.out.println("Tohle je příklad načtení přihlašovacích údajů. Uložení jména a hesla přímo ve zdrojovém kódu "+
                 "aplikace není bezpečné. Stejně tak uložení privátního klíče na disku není bezpečné. Bezpečné je uložení "+
                 "privátního klíče v úložišti certifikátů nebo v hardwarovém zařízení. \n\n");
                 

         Console console = System.console();
         if (console==null)
             throw new Error("Toto načtení údajů je funkční jen při spuštění programu v příkazovém řádku (cmd.exe, bash).\n");

         LoginName1 = console.readLine("Enter loginname: ");
         Password1 = new String (console.readPassword ("Enter password: "));         
    }

}


