﻿// Soucast ukazkoveho programu demonstrujiciho moznosti prace s datovymi schrankami
//
// (c) 2009 Software602 a.s. 
//
// Pripadne dotazy a pripominky zasilejte na: ISDS@602.cz
//
// Tento soubor obsahuje zapouzdreni proxy trid pro praci s datovymi schrankami

using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.IO;
using System.Threading;
using System.Security.Cryptography.X509Certificates;
using System.Web.Services.Protocols;

namespace ISDS
{
    /// <summary>
    /// Informace o zprave
    /// </summary>
    public struct ISDSDM
    {
        /// <summary>
        /// Nahradni doruceni povoleno/nepovoleno - pouze pro nektere subjekty (napr. soudy)
        /// </summary>
        public bool? AllowSubstDelivery;
        /// <summary>
        /// Textova poznamka (Vec, Predmet, Anotace)
        /// </summary>
        public string Annotation;
        /// <summary>
        /// Identifikace zpravy
        /// </summary>
        public string ID;
        /// <summary>
        /// Identifikace schranky adresata
        /// </summary>
        public string IDRecipient;
        /// <summary>
        /// Identifikace schranky odesilatele
        /// </summary>
        public string IDSender;
        /// <summary>
        /// Zmocneni - cislo zakona
        /// </summary>
        public int LegalTitleLaw;
        /// <summary>
        /// Zmocneni - rok vydani zakona
        /// </summary>
        public int LegalTitleYear;
        /// <summary>
        /// Zmocneni - paragraf v zakone
        /// </summary>
        public string LegalTitleSect;
        /// <summary>
        /// Zmocneni - odstavec v paragrafu
        /// </summary>
        public string LegalTitlePar;
        /// <summary>
        /// Zmocneni - pismeno v odstavci
        /// </summary>
        public string LegalTitlePoint;
        /// <summary>
        /// Priznak "Do vlastních rukou" znacici, ze zpravu muze cist pouze adresat nebo osoba s explicitne danym opravnenim
        /// </summary>
        public bool? PersonalDelivery;
        /// <summary>
        /// Prijemce slovne - doplnuje ISDS
        /// </summary>
        public string Recipient;
        /// <summary>
        /// Postovni adresa prijemce - doplnuje ISDS
        /// </summary>
        public string RecipientAddress;
        /// <summary>
        /// Spisova znacka ze strany prijemce, Nepovinne.
        /// </summary>
        public string RecipientIdent;
        /// <summary>
        /// Organizacni jednotka prijemce slovne, nepovinne, mozne upresneni prijemce pri podani z portalu
        /// </summary>
        public string RecipientOrgUnit;
        /// <summary>
        /// Organizacni jednotka prijemce hodnotou z ciselniku, nepovinne
        /// </summary>
        public int RecipientOrgUnitNum;
        /// <summary>
        /// Cislo jednaci ze strany prijemce, nepovinne
        /// </summary>
        public string RecipientRefNumber;
        /// <summary>
        /// Odesilatel slovne. Doplnuje ISDS
        /// </summary>
        public string Sender;
        /// <summary>
        /// Typ odesilatele
        /// </summary>
        public int SenderType;
        /// <summary>
        /// Postovni adresa odesilatele. Doplnuje ISDS
        /// </summary>
        public string SenderAddress;
        /// <summary>
        /// Spisova znacka ze strany odesilatele
        /// </summary>
        public string SenderIdent;
        /// <summary>
        /// Organizacni jednotka odesilatele slovne. Nepovinne
        /// </summary>
        public string SenderOrgUnit;
        /// <summary>
        /// Organizacni jednotka odesilatele hodnotou z ciselniku. Nepovinne
        /// </summary>
        public int SenderOrgUnitNum;
        /// <summary>
        /// Cislo jednaci ze strany odesilatele. Nepovinne
        /// </summary>
        public string SenderRefNumber;
        /// <summary>
        /// K rukam vlastnika datove schranky - pravo cist ma mensi mnozina opravnenych osob
        /// </summary>
        public string ToHands;
        public bool? AmbiguousRecipient;
    }

    /// <summary>
    /// Informace o obalce zpravy
    /// </summary>
    public struct ISDSMessageEnvelopeInfo
    {
        /// <summary>
        /// Cas doruceni zpravy
        /// </summary>
        public DateTime? AcceptanceTime;
        /// <summary>
        /// Cas dodani zpravy do datove schranky
        /// </summary>
        public DateTime? DeliveryTime;
        /// <summary>
        /// Stav zpravy (dodana, dorucena atd.)
        /// </summary>
        public string MessageStatus;
        /// <summary>
        /// Velikost prilohy v kB
        /// </summary>
        public int AttachmentSize;
    }

    /// <summary>
    /// Kontrolni hash zpravy
    /// </summary>
    public struct ISDSHash
    {
        /// <summary>
        /// Nazev pouziteho algoritmu pro vypocet hashe (napr. SHA-1)
        /// </summary>
        public string Algorithm;
        /// <summary>
        /// Vlastni hash
        /// </summary>
        public byte[] Value;
    }

    /// <summary>
    /// Obalka zpravy
    /// </summary>
    public struct ISDSMessageEnvelope
    {
        /// <summary>
        /// Informace o zprave
        /// </summary>
        public ISDSDM DM;
        /// <summary>
        /// Informace o obalce
        /// </summary>
        public ISDSMessageEnvelopeInfo EnvelopeInfo;
        /// <summary>
        /// Kontrolni hash
        /// </summary>
        public ISDSHash Hash;
        /// <summary>
        /// Kvalifikovane casove razitko
        /// </summary>
        public byte[] QTimestamp;
        /// <summary>
        /// Typ datove zpravy. Pokud obsahuje "K" jde o komercni zpravu
        /// </summary>
        public string Type;
    }

    /// <summary>
    /// Informace o zprave pouzita v seznamech zprav
    /// </summary>
    public struct ISDSMessageInfo
    {
        /// <summary>
        /// Poradove cislo zpravy v seznamu
        /// </summary>
        public int Ordinal;
        /// <summary>
        /// Informace o zprave
        /// </summary>
        public ISDSDM DM;
        /// <summary>
        /// Informace o obalce
        /// </summary>
        public ISDSMessageEnvelopeInfo EnvelopeInfo;
        /// <summary>
        /// Typ datove zpravy. Pokud obsahuje "K" jde o komercni zpravu
        /// </summary>
        public string Type;
    }

    public struct ISDSRecipient
    {
        public string IDRecipient;
        public string RecipientOrgUnit;
        public int RecipientOrgUnitNum;
        public string ToHands;
    }

    public struct ISDSMessageStatus
    {
        public string MessageID;
        public string StatusCode;
        public string StatusMessage;
    }
            
    /// <summary>
    /// Trida pouzita pro pridavani souboru do odesilane zpravy
    /// </summary>
    public class ISDSSendOutFiles
    {        
        private ArrayList FileInfos = null;
        private ArrayList FullFileNames = null;

        /// <summary>
        /// Prida soubor
        /// </summary>
        /// <param name="FullFileName">Uplne jmeno souboru (vcetne cesty)</param>
        /// <param name="MimeType">Typ souboru v MIME zapisu, napr. application/pdf nebo image/tiff</param>
        /// <param name="MetaType">Typ pisemnosti</param>
        /// <param name="Guid">Nepovinny interni identifikator tohoto dokumentu - pro vytvareni stromu zavislosti dokumentu</param>
        /// <param name="UpFileGuid">Nepovinny interni identifikator nadrizeneho dokumentu (napr. pro vztah soubor - podpis aj.)</param>
        /// <param name="FileDescr">Muze obsahovat jmeno souboru, prip. jiny popis. Objevi se v seznamu priloh na portale</param>
        /// <param name="Format">Nepovinny udaj - odkaz na definici formulare</param>
        public void AddFile(
            string FullFileName, 
            string MimeType,
            tFilesArrayDmFileDmFileMetaType MetaType,
            string Guid,
            string UpFileGuid,
            string FileDescr,
            string Format)
        {
            tFilesArrayDmFile FAF = new tFilesArrayDmFile();
            FAF.dmFileDescr = FileDescr;
            FAF.dmFileGuid = Guid;
            FAF.dmFileMetaType = MetaType;
            FAF.dmFormat = Format;
            FAF.dmMimeType = MimeType;
            FAF.dmUpFileGuid = UpFileGuid;
            FAF.Item = File.ReadAllBytes(FullFileName);
            if (FileInfos == null)
            {
                FileInfos = new ArrayList();
                FullFileNames = new ArrayList();
            }
            FileInfos.Add(FAF);
            FullFileNames.Add(FullFileName);
        }

        /// <summary>
        /// Prida soubor
        /// </summary>
        /// <param name="FullFileName">Uplne jmeno souboru (vcetne cesty)</param>
        public void AddFile(string FullFileName)
        {
            tFilesArrayDmFileDmFileMetaType MetaType;
            if (FileInfos == null) 
            {
                // prvni pripojeny soubor musi byt typu main
                MetaType = tFilesArrayDmFileDmFileMetaType.main;
            }
            else
            {
                // druhy a dalsi pripojeny soubor musi byt typu enclosure
                MetaType = tFilesArrayDmFileDmFileMetaType.enclosure;
            }
            AddFile(FullFileName, "",
                MetaType, "", "", Path.GetFileName(FullFileName), "");
        }

        internal tFilesArrayDmFile[] GetFiles()
        {
            return (tFilesArrayDmFile[])(FileInfos.ToArray(typeof(tFilesArrayDmFile)));
        }
    }

    /// <summary>
    /// Trida reprezentujici soubory ve stazene zprave
    /// </summary>
    public class ISDSDeliveredFiles
    {
        internal tFilesArrayDmFile[] Files = null;
        
        /// <summary>
        /// Ulozi vsechny soubory do zadaneho adresare
        /// </summary>
        /// <param name="DirectoryName">Nazev adresare do ktereho maji byt soubory ulozeny</param>
        public void SaveFilesToDirectory(string DirectoryName)
        {
            if (Files != null)
            {
                foreach (tFilesArrayDmFile F in Files)
                {
                    if (F.dmFileDescr == "")
                    {
                        throw new Exception("Ve zprávě není uveden název připojeného souboru");
                    }
                    File.WriteAllBytes(DirectoryName + @"\" + F.dmFileDescr, (byte[])(F.Item));
                }
            }
        }
    }

    /// <summary>
    /// Trida reprezentujici stazenou zasilku
    /// </summary>
    public struct ISDSDeliveredMessage
    {
        /// <summary>
        /// Soubory (prilohy) obsazene ve zprave
        /// </summary>
        public ISDSDeliveredFiles DeliveredFiles;
        /// <summary>
        /// Vlastni zasilka
        /// </summary>
        public ISDSMessageEnvelope MessageEnvelope;
    }

    /// <summary>
    /// Informace o prubehu dorucovani zpravy
    /// </summary>
    public struct ISDSEvent
    {
        /// <summary>
        /// Cas udalosti
        /// </summary>
        public DateTime? Time;
        /// <summary>
        /// Popis udalosti
        /// </summary>
        public string Descr;
    }

    /// <summary>
    /// Informace o dorucence
    /// </summary>
    public struct ISDSDeliveryInfo
    {
        /// <summary>
        /// Obalka dorucenky
        /// </summary>
        public ISDSMessageEnvelope MessageEnvelope;
        /// <summary>
        /// Informace o prubehu dorucovani
        /// </summary>
        public ISDSEvent[] Events;
    }

    /// <summary>
    /// Trida reprezentujici vlastnika schranky
    /// </summary>
    public struct ISDSOwnerInfo
    {
        /// <summary>
        /// adresa - obec
        /// </summary>
        public string adCity;
        /// <summary>
        /// adresa - cislo popisne
        /// </summary>
        public string adNumberInMunicipality;
        /// <summary>
        /// adresa - cislo orientacni
        /// </summary>
        public string adNumberInStreet;
        /// <summary>
        /// adresa - stat
        /// </summary>
        public string adState;
        /// <summary>
        /// adresa - ulice
        /// </summary>
        public string adStreet;
        /// <summary>
        /// adresa - PSC
        /// </summary>
        public string adZipCode;
        /// <summary>
        /// misto narozeni
        /// </summary>
        public string biCity;
        /// <summary>
        /// okres narozeni
        /// </summary>
        public string biCounty;
        /// <summary>
        /// datum narozeni
        /// </summary>
        public DateTime? biDate;
        /// <summary>
        /// stat narozeni (je-li jiny, nez CZ)
        /// </summary>
        public string biState;
        /// <summary>
        /// ID datove schranky
        /// </summary>
        public string dbID;
        /// <summary>
        /// typ datove schranky
        /// </summary>
        public tDbType? dbType;
        /// <summary>
        /// email
        /// </summary>
        public string email;
        /// <summary>
        /// nazev firmy, nebo subjektu
        /// </summary>
        public string firmName;
        /// <summary>
        /// identifikacni cislo, nebo jina evidence
        /// </summary>
        public string ic;
        /// <summary>
        /// statni obcanstvi
        /// </summary>
        public string nationality;
        /// <summary>
        /// jmeno osoby
        /// </summary>
        public string pnFirstName;
        /// <summary>
        /// prijmeni
        /// </summary>
        public string pnLastName;
        /// <summary>
        /// rodne jmeno
        /// </summary>
        public string pnLastNameAtBirth;
        /// <summary>
        /// prostredni jmeno
        /// </summary>
        public string pnMiddleName;
        /// <summary>
        /// telefonni cislo
        /// </summary>
        public string telNumber;
        /// <summary>
        /// identifikator z externi agendy poskytovatele dat
        /// </summary>
        public string Identifier;
        /// <summary>
        /// kod externi agendy PFO
        /// </summary>
        public string RegistryCode;
        /// <summary>
        /// stav DS (0 az 5). Pouze stav 1 dovoluje dorucovani do teto DS
        /// </summary>
        public int dbState;
        /// <summary>
        /// priznak, ze DS vystupuje jako OVM (§5a) 
        /// </summary>
        public bool? dbEffectiveOVM;
        /// <summary>
        /// priznak, ze ne-OVM DS ma aktivovano volne adresovani (§18a)
        /// </summary>
        public bool? dbOpenAddressing;
    }

    /// <summary>
    /// Informace o opravnene osobe
    /// </summary>
    public struct ISDSUserInfo
    {
        /// <summary>
        /// adresa - mesto
        /// </summary>
        public string adCity;
        /// <summary>
        /// adresa - popisne cislo
        /// </summary>
        public string adNumberInMunicipality;
        /// <summary>
        /// adresa - orientacni cislo
        /// </summary>
        public string adNumberInStreet;
        /// <summary>
        /// adresa - stat
        /// </summary>
        public string adState;
        /// <summary>
        /// adresa - ulice
        /// </summary>
        public string adStreet;
        /// <summary>
        /// adresa - PSC
        /// </summary>
        public string adZipCode;
        /// <summary>
        /// datum narozeni
        /// </summary>
        public DateTime? biDate;
        /// <summary>
        /// jmeno osoby
        /// </summary>
        public string pnFirstName;
        /// <summary>
        /// prijmeni osoby
        /// </summary>
        public string pnLastName;
        /// <summary>
        /// rodne jmeno
        /// </summary>
        public string pnLastNameAtBirth;
        /// <summary>
        /// prostredni jmeno
        /// </summary>
        public string pnMiddleName;
        /// <summary>
        /// 
        /// </summary>
        public string userID;
        /// <summary>
        /// 
        /// </summary>
        public long? userPrivils;
        /// <summary>
        /// 
        /// </summary>
        public tUserType? userType;
        /// <summary>
        /// IC firmy (PO), ktery vystupuje v datech z OR jako statutarni zastupce teto PO
        /// </summary>
        public string ic;
        /// <summary>
        /// jmeno firmy (PO), ktery vystupuje v datech z OR jako statutarni zastupce teto PO
        /// </summary>
        public string firmname;
        /// <summary>
        /// ulice a cisla v jednom retezci pro kontaktni adresu v CR
        /// </summary>
        public string caStreet;
        /// <summary>
        /// mesto pro kontaktni adresu v CR
        /// </summary>
        public string caCity;
        /// <summary>
        /// PSC pro pro kontaktni adresu v CR
        /// </summary>
        public string caZipCode;
    }

    public enum PortalType
    {
        CZebox,
        Prod
    }

    public enum LoginType
    {
        Password,
        Cert,
        HostCert,
        UserCert
    }

    public enum ISDSServiceType
    {
        Operation,
        Info,
        Manipulation,
        Access
    }

    /// <summary>
    /// Trida reprezentujici datovou schranku
    /// </summary>
    public class ISDSBox
    {
        private string LoginName = "";
        private string Password = "";
        private string CertFileName = "";
        private X509Certificate Certificate = null;
        
        private bool Connected = false;

        private dmInfoWebService InfoWebService;
        private dmOperationsWebService OperationsWebService;
        private DataBoxManipulation ManipulationWebService;
        private DataBoxAccess AccessWebService;

        private LoginType loginType;
        private PortalType portalType = PortalType.CZebox;

        public static string BaseURI(PortalType PT,LoginType LT)
        {
            switch (PT)
            {
                case PortalType.Prod:
                    if (LT == LoginType.Password)
                    {
                        return "ws1.mojedatovaschranka.cz";
                    }
                    else
                    {
                        return "ws1c.mojedatovaschranka.cz";
                    }
                default:
                    if (LT == LoginType.Password)
                    {
                        return "ws1.czebox.cz";
                    }
                    else
                    {
                        return "ws1c.czebox.cz";
                    }
            }
        }

        private static string LoginSuffix(LoginType LT)
        {
            switch (LT)
            {
                case LoginType.Cert:
                    return "cert";
                case LoginType.HostCert:
                    return "hspis";
                case LoginType.UserCert:
                    return "certds";
                default:
                    return "";
            }
        }

        private static string ServiceSuffix(ISDSServiceType ST)
        {
            switch (ST)
            {
                case ISDSServiceType.Info:
                    return "dx";
                case ISDSServiceType.Operation:
                    return "dz";
                default:
                    return "DsManage";
            }
        }

        public static string GetISDSServiceURL(PortalType PT, LoginType LT, ISDSServiceType ST)
        {
            string S = LoginSuffix(LT);
            if (S == "")
            {
                return "https://" + BaseURI(PT,LT) + "/DS/" + ServiceSuffix(ST);
            }
            else
            {
                return "https://" + BaseURI(PT,LT) + "/" + S + "/DS/" + ServiceSuffix(ST);
            }
        }

        /// <summary>
        /// Adresa proxy serveru pokud se pouziva pro pripojeni (napr. 192.168.14.10)
        /// </summary>
        public string ProxyAddress = "";
        /// <summary>
        /// Pokud proxy server vyzaduje autentizaci, tak musi obsahovat prihlasovaci jmeno
        /// </summary>
        public string ProxyLoginName = "";
        /// <summary>
        /// Pokud proxy server vyzaduje autentizaci, tak musi obsahovat prihlasovaci heslo
        /// </summary>
        public string ProxyPassword = "";

        /// <summary>
        /// Konstruktor pro pripojeni jmenem a heslem
        /// </summary>
        /// <param name="LoginName">Prihlasovaci jmeno</param>
        /// <param name="Password">Heslo</param>
        /// <param name="URL">URL</param>
        public ISDSBox(
            string LoginName,
            string Password)
        {
            loginType = LoginType.Password;
            this.LoginName = LoginName;
            this.Password = Password;
        }

        /// <summary>
        /// Konstruktor pro pripojeni certifikatem ulozenym v souboru
        /// </summary>
        /// <param name="CertFileName">Soubor s certifikatem</param>
        public ISDSBox(string CertFileName)
        {
            loginType = LoginType.Cert;
            this.CertFileName = CertFileName;
        }

        /// <summary>
        /// Konstruktor pro pripojeni certifikatem predavanym jako objekt
        /// </summary>
        /// <param name="Certificate">Certifikat</param>
        public ISDSBox(X509Certificate Certificate)
        {
            loginType = LoginType.Cert;
            this.Certificate = Certificate;
        }

        /// <summary>
        /// Konstruktor pro pripojeni pro hostovane spisovkove sluzby
        /// </summary>
        /// <param name="LoginName">Prihlasovaci jmeno</param>
        /// <param name="Password">Heslo</param>
        /// <param name="CertFileName">Soubor s certifikatem</param>
        public ISDSBox(string LoginName, string Password, string CertFileName)
        {
            loginType = LoginType.HostCert;
            this.LoginName = LoginName;
            this.Password = Password;
            this.CertFileName = CertFileName;
        }

        /// <summary>
        /// Konstruktor pro pripojeni pro hostovane spisovkove sluzby
        /// </summary>
        /// <param name="LoginName">Prihlasovaci jmeno</param>
        /// <param name="Password">Heslo</param>
        /// <param name="Certificate">Certifikat</param>
        public ISDSBox(string LoginName, string Password, X509Certificate Certificate)
        {
            loginType = LoginType.HostCert;
            this.LoginName = LoginName;
            this.Password = Password;
            this.Certificate = Certificate;
        }

        /// <summary>
        /// Univerzalni konstruktor pro testovaci aplikace
        /// </summary>
        /// <param name="LT">Typ pripojeni</param>
        /// <param name="PT">Portal ke kteremu se pripojujeme</param>
        /// <param name="LoginName">Prihlasovaci jmeno</param>
        /// <param name="Password">Heslo</param>
        /// <param name="CertFileName">Soubor s certifikatem</param>
        /// <param name="Certificate">Certifikat</param>
        public ISDSBox(LoginType LT, PortalType PT, string LoginName, string Password, string CertFileName, X509Certificate Certificate)
        {
            loginType = LT;
            portalType = PT;
            this.LoginName = LoginName;
            this.Password = Password;
            this.CertFileName = CertFileName;
            this.Certificate = Certificate;
        }

        /// <summary>
        /// Inicializacni procedura pro jednotlivou sluzbu
        /// </summary>
        /// <param name="WS"></param>
        private void InitializeService(SoapHttpClientProtocol WS, string URL)
        {
            WS.Url = URL;
            // Pri prihlasovani k ISDS dochazi k presmerovavani - to je treba implicitne povolit
            WS.AllowAutoRedirect = true;
            WS.UserAgent = "ISDS Basic NET Sample v15";
            
            // vytvoreni cache pro povereni
            WS.Credentials = new NetworkCredential(LoginName, Password);
            WS.PreAuthenticate = true;
            
            // podpora proxy serveru
            if (ProxyAddress != "")
            {
                WebProxy WP = new WebProxy(ProxyAddress);
                if (ProxyLoginName != "")
                {
                    WP.Credentials = new NetworkCredential(ProxyLoginName, ProxyPassword);
                }
                WS.Proxy = WP;
            }

            if ((loginType == LoginType.Cert) || (loginType == LoginType.HostCert))
            {
                if (Certificate == null)
                {
                    Certificate = X509Certificate.CreateFromCertFile(CertFileName);                    
                }
                WS.ClientCertificates.Add(Certificate);
            }
        }

        /// <summary>
        /// Inicializacni procedura
        /// </summary>
        public void Connect()
        {
            string InfoURL;
            string OperationURL;
            string AccessURL;
            string ManipulationURL;
            Connect(out InfoURL, out OperationURL, out AccessURL, out ManipulationURL);
        }

        public string[] GetServicesURL()
        {
            return new string[] {GetISDSServiceURL(portalType, loginType, ISDSServiceType.Info),
                GetISDSServiceURL(portalType, loginType, ISDSServiceType.Operation),
                GetISDSServiceURL(portalType, loginType, ISDSServiceType.Access),
                GetISDSServiceURL(portalType,loginType,ISDSServiceType.Manipulation)};
        }

        public void Connect(out string InfoURL, out string OperationURL, out string AccessURL, out string ManipulationURL)
        {
            // system pouziva 4 webove sluzby
            InfoWebService = new dmInfoWebService();
            OperationsWebService = new dmOperationsWebService();
            AccessWebService = new DataBoxAccess();
            ManipulationWebService = new DataBoxManipulation();

            InfoURL = GetISDSServiceURL(portalType, loginType, ISDSServiceType.Info);
            OperationURL = GetISDSServiceURL(portalType, loginType, ISDSServiceType.Operation);
            AccessURL = GetISDSServiceURL(portalType, loginType, ISDSServiceType.Access);
            ManipulationURL = GetISDSServiceURL(portalType, loginType, ISDSServiceType.Manipulation);

            // inicializace jednotlivych sluzeb
            InitializeService(InfoWebService, InfoURL);
            InitializeService(OperationsWebService, OperationURL);
            InitializeService(AccessWebService, AccessURL);
            InitializeService(ManipulationWebService, ManipulationURL);

            Connected = true;
        }

        private void VerifyConnect()
        {
            if (!Connected)
            {
                Connect();
            }
        }

        private int StatusCodeToInt(string StatusCode)
        {
            try
            {
                return Convert.ToInt32(StatusCode);
            }
            catch (Exception)
            {
                throw new Exception(string.Format("Vrácený dmStatusCode není v číselném formátu: {0}",StatusCode));
            }
        }

        private static int ConvertInt(string Value)
        {
            int Res = 0;
            try
            {
                Res = Convert.ToInt32(Value);
            }
            catch
            {
            }
            return Res;
        }
        
        private static ISDSMessageInfo PrepareMessageInfo(tRecord Rec, string Type)
        {
            ISDSMessageInfo Res;
            Res.DM = PrepareDM(Rec);
            Res.EnvelopeInfo = PrepareEnvelopeInfo(Rec);
            Res.Ordinal = Rec.dmOrdinal;
            Res.Type = Type;
            return Res;
        }

        private static ISDSDeliveryInfo PrepareDeliveryInfo(tDelivery Delivery)
        {
            ISDSDeliveryInfo Res;
            Res.MessageEnvelope = PrepareMessageEnvelope(Delivery,"");
            int EventsLength = 0;
            if ((Delivery.dmEvents != null) && (Delivery.dmEvents.dmEvent != null))
            {
                EventsLength = Delivery.dmEvents.dmEvent.Length;
            }
            Res.Events = new ISDSEvent[EventsLength];
            for (int i = 0; i < EventsLength; i++)
            {
                Res.Events[i].Descr = Delivery.dmEvents.dmEvent[i].dmEventDescr;
                Res.Events[i].Time = Delivery.dmEvents.dmEvent[i].dmEventTime;
            }
            return Res;
        }

        private static ISDSDM PrepareDM(tReturnedMessageEnvelopeDmDm RME)
        {
            ISDSDM Res;
            Res.AllowSubstDelivery = RME.dmAllowSubstDelivery;
            Res.Annotation = RME.dmAnnotation;
            Res.ID = RME.dmID;
            Res.IDRecipient = RME.dbIDRecipient;
            Res.IDSender = RME.dbIDSender;
            Res.LegalTitleLaw = ConvertInt(RME.dmLegalTitleLaw);
            Res.LegalTitlePar = RME.dmLegalTitlePar;
            Res.LegalTitlePoint = RME.dmLegalTitlePoint;
            Res.LegalTitleSect = RME.dmLegalTitleSect;
            Res.LegalTitleYear = ConvertInt(RME.dmLegalTitleYear);
            Res.PersonalDelivery = RME.dmPersonalDelivery;
            Res.Recipient = RME.dmRecipient;
            Res.RecipientAddress = RME.dmRecipientAddress;
            Res.RecipientIdent = RME.dmRecipientIdent;
            Res.RecipientOrgUnit = RME.dmRecipientOrgUnit;
            Res.RecipientOrgUnitNum = ConvertInt(RME.dmRecipientOrgUnitNum);
            Res.RecipientRefNumber = RME.dmRecipientRefNumber;
            Res.Sender = RME.dmSender;
            Res.SenderAddress = RME.dmSenderAddress;
            Res.SenderIdent = RME.dmSenderIdent;
            Res.SenderOrgUnit = RME.dmSenderOrgUnit;
            Res.SenderOrgUnitNum = ConvertInt(RME.dmSenderOrgUnitNum);
            Res.SenderRefNumber = RME.dmSenderRefNumber;
            Res.ToHands = RME.dmToHands;
            Res.SenderType = RME.dmSenderType;
            Res.AmbiguousRecipient = RME.dmAmbiguousRecipient;
            return Res;
        }

        private static ISDSDM PrepareDM(tRecord RME)
        {
            ISDSDM Res;
            Res.AllowSubstDelivery = RME.dmAllowSubstDelivery;
            Res.Annotation = RME.dmAnnotation;
            Res.ID = RME.dmID;
            Res.IDRecipient = RME.dbIDRecipient;
            Res.IDSender = RME.dbIDSender;
            Res.LegalTitleLaw = ConvertInt(RME.dmLegalTitleLaw);
            Res.LegalTitlePar = RME.dmLegalTitlePar;
            Res.LegalTitlePoint = RME.dmLegalTitlePoint;
            Res.LegalTitleSect = RME.dmLegalTitleSect;
            Res.LegalTitleYear = ConvertInt(RME.dmLegalTitleYear);
            Res.PersonalDelivery = RME.dmPersonalDelivery;
            Res.Recipient = RME.dmRecipient;
            Res.RecipientAddress = RME.dmRecipientAddress;
            Res.RecipientIdent = RME.dmRecipientIdent;
            Res.RecipientOrgUnit = RME.dmRecipientOrgUnit;
            Res.RecipientOrgUnitNum = ConvertInt(RME.dmRecipientOrgUnitNum);
            Res.RecipientRefNumber = RME.dmRecipientRefNumber;
            Res.Sender = RME.dmSender;
            Res.SenderAddress = RME.dmSenderAddress;
            Res.SenderIdent = RME.dmSenderIdent;
            Res.SenderOrgUnit = RME.dmSenderOrgUnit;
            Res.SenderOrgUnitNum = ConvertInt(RME.dmSenderOrgUnitNum);
            Res.SenderRefNumber = RME.dmSenderRefNumber;
            Res.ToHands = RME.dmToHands;
            Res.SenderType = RME.dmSenderType;
            Res.AmbiguousRecipient = RME.dmAmbiguousRecipient;
            return Res;
        }

        private static ISDSDM PrepareDM(tDeliveryDmDm RME)
        {
            ISDSDM Res;
            Res.AllowSubstDelivery = RME.dmAllowSubstDelivery;
            Res.Annotation = RME.dmAnnotation;
            Res.ID = RME.dmID;
            Res.IDRecipient = RME.dbIDRecipient;
            Res.IDSender = RME.dbIDSender;
            Res.LegalTitleLaw = ConvertInt(RME.dmLegalTitleLaw);
            Res.LegalTitlePar = RME.dmLegalTitlePar;
            Res.LegalTitlePoint = RME.dmLegalTitlePoint;
            Res.LegalTitleSect = RME.dmLegalTitleSect;
            Res.LegalTitleYear = ConvertInt(RME.dmLegalTitleYear);
            Res.PersonalDelivery = RME.dmPersonalDelivery;
            Res.Recipient = RME.dmRecipient;
            Res.RecipientAddress = RME.dmRecipientAddress;
            Res.RecipientIdent = RME.dmRecipientIdent;
            Res.RecipientOrgUnit = RME.dmRecipientOrgUnit;
            Res.RecipientOrgUnitNum = ConvertInt(RME.dmRecipientOrgUnitNum);
            Res.RecipientRefNumber = RME.dmRecipientRefNumber;
            Res.Sender = RME.dmSender;
            Res.SenderAddress = RME.dmSenderAddress;
            Res.SenderIdent = RME.dmSenderIdent;
            Res.SenderOrgUnit = RME.dmSenderOrgUnit;
            Res.SenderOrgUnitNum = ConvertInt(RME.dmSenderOrgUnitNum);
            Res.SenderRefNumber = RME.dmSenderRefNumber;
            Res.ToHands = RME.dmToHands;
            Res.SenderType = RME.dmSenderType;
            Res.AmbiguousRecipient = RME.dmAmbiguousRecipient;
            return Res;
        }

        private static ISDSDM PrepareDM(tReturnedMessageDmDm RME)
        {
            ISDSDM Res;
            Res.AllowSubstDelivery = RME.dmAllowSubstDelivery;
            Res.Annotation = RME.dmAnnotation;
            Res.ID = RME.dmID;
            Res.IDRecipient = RME.dbIDRecipient;
            Res.IDSender = RME.dbIDSender;
            Res.LegalTitleLaw = ConvertInt(RME.dmLegalTitleLaw);
            Res.LegalTitlePar = RME.dmLegalTitlePar;
            Res.LegalTitlePoint = RME.dmLegalTitlePoint;
            Res.LegalTitleSect = RME.dmLegalTitleSect;
            Res.LegalTitleYear = ConvertInt(RME.dmLegalTitleYear);
            Res.PersonalDelivery = RME.dmPersonalDelivery;
            Res.Recipient = RME.dmRecipient;
            Res.RecipientAddress = RME.dmRecipientAddress;
            Res.RecipientIdent = RME.dmRecipientIdent;
            Res.RecipientOrgUnit = RME.dmRecipientOrgUnit;
            Res.RecipientOrgUnitNum = ConvertInt(RME.dmRecipientOrgUnitNum);
            Res.RecipientRefNumber = RME.dmRecipientRefNumber;
            Res.Sender = RME.dmSender;
            Res.SenderAddress = RME.dmSenderAddress;
            Res.SenderIdent = RME.dmSenderIdent;
            Res.SenderOrgUnit = RME.dmSenderOrgUnit;
            Res.SenderOrgUnitNum = ConvertInt(RME.dmSenderOrgUnitNum);
            Res.SenderRefNumber = RME.dmSenderRefNumber;
            Res.ToHands = RME.dmToHands;
            Res.SenderType = RME.dmSenderType;
            Res.AmbiguousRecipient = RME.dmAmbiguousRecipient;
            return Res;
        }

        private static ISDSMessageEnvelopeInfo PrepareEnvelopeInfo(tReturnedMessageEnvelope RME)
        {
            ISDSMessageEnvelopeInfo Res;
            Res.AcceptanceTime = RME.dmAcceptanceTime;
            Res.DeliveryTime = RME.dmDeliveryTime;
            Res.MessageStatus = RME.dmMessageStatus;
            Res.AttachmentSize = ConvertInt(RME.dmAttachmentSize);
            return Res;
        }

        private static ISDSMessageEnvelopeInfo PrepareEnvelopeInfo(tDelivery RME)
        {
            ISDSMessageEnvelopeInfo Res;
            Res.AcceptanceTime = RME.dmAcceptanceTime;
            Res.DeliveryTime = RME.dmDeliveryTime;
            Res.MessageStatus = RME.dmMessageStatus;
            Res.AttachmentSize = 0;
            return Res;
        }

        private static ISDSMessageEnvelopeInfo PrepareEnvelopeInfo(tRecord RME)
        {
            ISDSMessageEnvelopeInfo Res;
            Res.AcceptanceTime = RME.dmAcceptanceTime;
            Res.DeliveryTime = RME.dmDeliveryTime;
            Res.MessageStatus = RME.dmMessageStatus;
            Res.AttachmentSize = ConvertInt(RME.dmAttachmentSize);
            return Res;
        }

        private static ISDSMessageEnvelopeInfo PrepareEnvelopeInfo(tReturnedMessage RME)
        {
            ISDSMessageEnvelopeInfo Res;
            Res.AcceptanceTime = RME.dmAcceptanceTime;
            Res.DeliveryTime = RME.dmDeliveryTime;
            Res.MessageStatus = RME.dmMessageStatus;
            Res.AttachmentSize = ConvertInt(RME.dmAttachmentSize);
            return Res;
        }

        private static ISDSHash PrepareHash(tHash Hash)
        {
            ISDSHash Res;
            if (Hash == null)
            {
                Res.Algorithm = "";
                Res.Value = new byte[0];
            }
            else
            {
                Res.Algorithm = Hash.algorithm;
                Res.Value = Hash.Value;
            }
            return Res;
        }

        private static ISDSMessageEnvelope PrepareMessageEnvelope(tReturnedMessageEnvelope RME, string Type)
        {
            ISDSMessageEnvelope Res;
            Res.DM = PrepareDM(RME.dmDm);
            Res.EnvelopeInfo = PrepareEnvelopeInfo(RME);
            Res.Hash = PrepareHash(RME.dmHash);
            Res.QTimestamp = RME.dmQTimestamp;
            Res.Type = Type;
            return Res;
        }

        private static ISDSMessageEnvelope PrepareMessageEnvelope(tReturnedMessage RME, string Type)
        {
            ISDSMessageEnvelope Res;
            Res.DM = PrepareDM(RME.dmDm);
            Res.EnvelopeInfo = PrepareEnvelopeInfo(RME);
            Res.Hash = PrepareHash(RME.dmHash);
            Res.QTimestamp = RME.dmQTimestamp;
            Res.Type = Type;
            return Res;
        }

        private static ISDSMessageEnvelope PrepareMessageEnvelope(tDelivery RME, string Type)
        {
            ISDSMessageEnvelope Res;
            Res.DM = PrepareDM(RME.dmDm);
            Res.EnvelopeInfo = PrepareEnvelopeInfo(RME);
            Res.Hash = PrepareHash(RME.dmHash);
            Res.QTimestamp = RME.dmQTimestamp;
            Res.Type = Type;
            return Res;
        }

        private tDbOwnerInfo PrepareOwnerInfo(ISDSOwnerInfo OwnerInfo)
        {
            tDbOwnerInfo Res = new tDbOwnerInfo();
            Res.adCity = OwnerInfo.adCity;
            Res.adNumberInMunicipality = OwnerInfo.adNumberInMunicipality;
            Res.adNumberInStreet = OwnerInfo.adNumberInStreet;
            Res.adState = OwnerInfo.adState;
            Res.adStreet = OwnerInfo.adStreet;
            Res.adZipCode = OwnerInfo.adZipCode;
            Res.biCity = OwnerInfo.biCity;
            Res.biCounty = OwnerInfo.biCounty;
            Res.biDate = OwnerInfo.biDate;
            Res.biState = OwnerInfo.biState;
            Res.dbID = OwnerInfo.dbID;
            Res.dbType = OwnerInfo.dbType;
            Res.email = OwnerInfo.email;
            Res.firmName = OwnerInfo.firmName;
            Res.ic = OwnerInfo.ic;
            Res.nationality = OwnerInfo.nationality;
            Res.pnFirstName = OwnerInfo.pnFirstName;
            Res.pnLastName = OwnerInfo.pnLastName;
            Res.pnLastNameAtBirth = OwnerInfo.pnLastNameAtBirth;
            Res.pnMiddleName = OwnerInfo.pnMiddleName;
            Res.telNumber = OwnerInfo.telNumber;
            Res.identifier = OwnerInfo.Identifier;
            Res.registryCode = OwnerInfo.RegistryCode;
            Res.dbState = OwnerInfo.dbState.ToString();
            Res.dbEffectiveOVM = OwnerInfo.dbEffectiveOVM;
            Res.dbOpenAddressing = OwnerInfo.dbOpenAddressing;
            return Res;
        }

        private ISDSOwnerInfo PrepareOwnerInfo(tDbOwnerInfo OwnerInfo)
        {
            ISDSOwnerInfo Res;
            Res.adCity = OwnerInfo.adCity;
            Res.adNumberInMunicipality = OwnerInfo.adNumberInMunicipality;
            Res.adNumberInStreet = OwnerInfo.adNumberInStreet;
            Res.adState = OwnerInfo.adState;
            Res.adStreet = OwnerInfo.adStreet;
            Res.adZipCode = OwnerInfo.adZipCode;
            Res.biCity = OwnerInfo.biCity;
            Res.biCounty = OwnerInfo.biCounty;
            Res.biDate = OwnerInfo.biDate;
            Res.biState = OwnerInfo.biState;
            Res.dbID = OwnerInfo.dbID;
            Res.dbType = OwnerInfo.dbType;
            Res.email = OwnerInfo.email;
            Res.firmName = OwnerInfo.firmName;
            Res.ic = OwnerInfo.ic;
            Res.nationality = OwnerInfo.nationality;
            Res.pnFirstName = OwnerInfo.pnFirstName;
            Res.pnLastName = OwnerInfo.pnLastName;
            Res.pnLastNameAtBirth = OwnerInfo.pnLastNameAtBirth;
            Res.pnMiddleName = OwnerInfo.pnMiddleName;
            Res.telNumber = OwnerInfo.telNumber;
            Res.Identifier = OwnerInfo.identifier;
            Res.RegistryCode = OwnerInfo.registryCode;
            Res.dbState = ConvertInt(OwnerInfo.dbState);
            Res.dbEffectiveOVM = OwnerInfo.dbEffectiveOVM;
            Res.dbOpenAddressing = OwnerInfo.dbOpenAddressing;
            return Res;
        }

        private ISDSUserInfo PrepareUserInfo(tDbUserInfo UserInfo)
        {
            ISDSUserInfo Res = new ISDSUserInfo();
            Res.adCity = UserInfo.adCity;
            Res.adNumberInMunicipality = UserInfo.adNumberInMunicipality;
            Res.adNumberInStreet = UserInfo.adNumberInStreet;
            Res.adState = UserInfo.adState;
            Res.adStreet = UserInfo.adStreet;
            Res.adZipCode = UserInfo.adZipCode;
            Res.biDate = UserInfo.biDate;
            Res.pnFirstName = UserInfo.pnFirstName;
            Res.pnLastName = UserInfo.pnLastName;
            Res.pnLastNameAtBirth = UserInfo.pnLastNameAtBirth;
            Res.userID = UserInfo.userID;
            Res.userPrivils = UserInfo.userPrivils;
            Res.userType = UserInfo.userType;            
            Res.ic = UserInfo.ic;
            Res.firmname = UserInfo.firmName;
            Res.caStreet = UserInfo.caStreet;
            Res.caCity = UserInfo.caCity;
            Res.caZipCode = UserInfo.caZipCode;
            return Res;
        }

        /// <summary>
        /// Stazeni seznamu odeslanych zprav urceneho casovym intervalem, organizacni jednotkou odesilatele, 
        /// filtrem na stav zprav a usekem poradovych císel zaznamu
        /// </summary>
        /// <param name="FromTime">Pocatek casoveho intervalu z nehoz maji byt zpravy nacteny</param>
        /// <param name="ToTime">Konec casoveho intervalu z nehoz maji byt zpravy nacteny</param>
        /// <param name="Offset">Cislo prvniho pozadovaneho zaznamu</param>
        /// <param name="Limit">Pocet pozadovanych zaznamu</param>
        /// <param name="StatusFilter">Filtr na stav zpravy. Hodnota -1 vrati vsechny zpravy. Je mozne specifikovat pozadovane 
        /// zpravy kombinaci nasledujicich hodnot (jde o bitove priznaky):
        /// 1 podana
        /// 2 dostala razitko
        /// 3 neprosla antivirem
        /// 4 dodana
        /// 5 dorucena fikci - tzn. uplynutim casu 10 dnu
        /// 6 dorucena prihlasenim
        /// 7 prectena
        /// 8 nedorucitelna (znepristupnena schranka po odeslani)
        /// 9 smazana
        /// </param>
        /// <param name="SenderOrgUnitNum">Organizacni slozka odesilatele (z ciselniku)</param>
        /// <returns>Pole informaci o zpravach</returns>
        public ISDSMessageInfo[] GetListOfSentMessages(
            DateTime? FromTime,
            DateTime? ToTime,
            int Offset,
            int Limit,
            int StatusFilter,
            int SenderOrgUnitNum)
        {
            VerifyConnect();
            tListOfSentInput TIN = new tListOfSentInput();
            TIN.dmFromTime = FromTime;
            TIN.dmToTime = ToTime;
            if (StatusFilter >= 0)
            {
                TIN.dmStatusFilter = StatusFilter.ToString();
            }
            if (Offset >= 0)
            {
                TIN.dmOffset = Offset.ToString();
            }
            if (Limit >= 0)
            {
                TIN.dmLimit = Limit.ToString();
            }
            if (SenderOrgUnitNum >= 0)
            {
                TIN.dmSenderOrgUnitNum = SenderOrgUnitNum.ToString();
            }
            tListOfMessOutput LO = null;
            try
            {
                LO = InfoWebService.GetListOfSentMessages(TIN);
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Při volání metody GetListOfSentMessages webové služby InfoWebService došlo k výjimce: {0}", ex.Message));
            }
            int StatusCode = StatusCodeToInt(LO.dmStatus.dmStatusCode);
            if (StatusCode != 0)
            {
                throw new Exception(LO.dmStatus.dmStatusMessage);
            }
            tRecordsArray RA = LO.dmRecords;
            if (RA.dmRecord == null)
            {
                return new ISDSMessageInfo[0];
            }
            ISDSMessageInfo[] Res = new ISDSMessageInfo[RA.dmRecord.Length];
            for (int i = 0; i < RA.dmRecord.Length; i++)
            {
                Res[i] = PrepareMessageInfo(RA.dmRecord[i],RA.dmRecord[i].dmType);
            }
            return Res;
        }

        /// <summary>
        /// Stazeni seznamu doslych zprav urceneho casovym intervalem, 
        /// zpresnenim organizacni jednotky adresata (pouze ESS), filtrem na stav zprav 
        /// a usekem poradovych císel zaznamu
        /// </summary>
        /// <param name="FromTime">Pocatek casoveho intervalu z nehoz maji byt zpravy nacteny</param>
        /// <param name="ToTime">Konec casoveho intervalu z nehoz maji byt zpravy nacteny</param>
        /// <param name="Offset">Cislo prvniho pozadovaneho zaznamu</param>
        /// <param name="Limit">Pocet pozadovanych zaznamu</param>
        /// <param name="StatusFilter">Filtr na stav zpravy. Hodnota -1 vrati vsechny zpravy. Je mozne specifikovat pozadovane 
        /// zpravy kombinaci nasledujicich hodnot (jde o bitove priznaky):
        /// 1 podana
        /// 2 dostala razitko
        /// 3 neprosla antivirem
        /// 4 dodana
        /// 5 dorucena fikci - tzn. uplynutim casu 10 dnu
        /// 6 dorucena prihlasenim
        /// 7 prectena
        /// 8 nedorucitelna (znepristupnena schranka po odeslani)
        /// 9 smazana</param>
        /// <param name="RecipientOrgUnitNum">Organizacni slozka adresata (z ciselniku)</param>
        /// <returns>Pole informaci o zpravach</returns>
        public ISDSMessageInfo[] GetListOfReceivedMessages(
            DateTime? FromTime,
            DateTime? ToTime,
            int Offset,
            int Limit,
            int StatusFilter,
            int RecipientOrgUnitNum)
        {
            VerifyConnect();
            tListOfFReceivedInput TIN = new tListOfFReceivedInput();
            TIN.dmFromTime = FromTime;
            TIN.dmToTime = ToTime;
            if (StatusFilter >= 0)
            {
                TIN.dmStatusFilter = StatusFilter.ToString();
            }
            if (Offset >= 0)
            {
                TIN.dmOffset = Offset.ToString();
            }
            if (Limit >= 0)
            {
                TIN.dmLimit = Limit.ToString();
            }
            if (RecipientOrgUnitNum >= 0)
            {
                TIN.dmRecipientOrgUnitNum = RecipientOrgUnitNum.ToString();
            }
            tListOfMessOutput LO = null;
            try
            {
                LO = InfoWebService.GetListOfReceivedMessages(TIN);
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Při volání metody GetListOfReceivedMessages webové služby InfoWebService došlo k výjimce: {0}", ex.Message));
            }
            int StatusCode = StatusCodeToInt(LO.dmStatus.dmStatusCode);
            if (StatusCode != 0)
            {
                throw new Exception(LO.dmStatus.dmStatusMessage);
            }
            tRecordsArray RA = LO.dmRecords;
            if (RA.dmRecord == null)
            {
                return new ISDSMessageInfo[0];
            }
            ISDSMessageInfo[] Res = new ISDSMessageInfo[RA.dmRecord.Length];
            for (int i = 0; i < RA.dmRecord.Length; i++)
            {
                Res[i] = PrepareMessageInfo(RA.dmRecord[i],RA.dmRecord[i].dmType);
            }
            return Res;
        }

        /// <summary>
        /// Vytvori datovou zpravu a umisti ji do dane schranky
        /// </summary>
        /// <param name="IDRecipient">Identifikace adresata</param>
        /// <param name="Annotation">Textova poznamka (vec, predmet, anotace)</param>
        /// <param name="AllowSubstDelivery">Nahradni doruceni povoleno/nepovoleno - pouze pro nektere subjekty (napr. soudy)</param>
        /// <param name="LegalTitleLaw">Zmocneni - cislo zakona</param>
        /// <param name="LegalTitlePar">Zmocneni - odstavec v paragrafu</param>
        /// <param name="LegalTitlePoint">Zmocneni - pismeno v odstavci</param>
        /// <param name="LegalTitleSect">Zmocneni - paragraf v zakone</param>
        /// <param name="LegalTitleYear">Zmocneni - rok vydani zakona</param>
        /// <param name="RecipientIdent">Spisova znacka ze strany prijemce, Nepovinne.</param>
        /// <param name="RecipientOrgUnit">Organizacni jednotka prijemce slovne, nepovinne, mozne upresneni prijemce pri podani z portalu</param>
        /// <param name="RecipientOrgUnitNum">Organizacni jednotka prijemce hodnotou z ciselniku, nepovinne, pokud nechcete urcit zadejte -1</param>
        /// <param name="RecipientRefNumber">Cislo jednaci ze strany prijemce, nepovinne</param>
        /// <param name="SenderIdent">Spisova znacka ze strany odesilatele</param>
        /// <param name="SenderOrgUnit">Organizacni jednotka odesilatele slovne. Nepovinne</param>
        /// <param name="SenderOrgUnitNum">Organizacni jednotka odesilatele hodnotou z ciselniku. Nepovinne, pokud nechcete urcit zadejte -1</param>
        /// <param name="SenderRefNumber">Cislo jednaci ze strany odesilatele. Nepovinne</param>
        /// <param name="ToHands">K rukam vlastnika datove schranky - pravo cist ma mensi mnozina opravnenych osob</param>
        /// <param name="PersonalDelivery">Priznak "Do vlastních rukou" znacici, ze zpravu muze cist pouze adresat nebo osoba s explicitne danym opravnenim</param>
        /// <param name="OVM"></param>
        /// <param name="Attachments">Pripojene soubory (pisemnosti)</param>
        /// <returns>Identifikace zpravy</returns>
        public string CreateMessage(
            string IDRecipient,
            string Annotation,
            bool? AllowSubstDelivery,
            int LegalTitleLaw,
            string LegalTitlePar,
            string LegalTitlePoint,
            string LegalTitleSect,
            int LegalTitleYear,
            string RecipientIdent,
            string RecipientOrgUnit,
            int RecipientOrgUnitNum,
            string RecipientRefNumber,
            string SenderIdent,
            string SenderOrgUnit,
            int SenderOrgUnitNum,
            string SenderRefNumber,
            string ToHands,
            bool? PersonalDelivery,
            bool? OVM,
            ISDSSendOutFiles Attachments
            )
        {
            VerifyConnect();
            tMessageCreateInput TIN = new tMessageCreateInput();
            tMessageEnvelopeSub MES = new tMessageEnvelopeSub();
            MES.dbIDRecipient = IDRecipient;
            MES.dmAllowSubstDelivery = AllowSubstDelivery;
            MES.dmAnnotation = Annotation;
            if (LegalTitleLaw >= 0)
            {
                MES.dmLegalTitleLaw = LegalTitleLaw.ToString();
            }            
            MES.dmLegalTitlePar = LegalTitlePar;
            MES.dmLegalTitlePoint = LegalTitlePoint;
            MES.dmLegalTitleSect = LegalTitleSect;
            if (LegalTitleYear >= 0)
            {
                MES.dmLegalTitleYear = LegalTitleYear.ToString();
            }
            MES.dmPersonalDelivery = PersonalDelivery;
            MES.dmRecipientIdent = RecipientIdent;
            MES.dmRecipientOrgUnit = RecipientOrgUnit;
            if (RecipientOrgUnitNum >= 0)
            {
                MES.dmRecipientOrgUnitNum = RecipientOrgUnitNum.ToString();
            }
            MES.dmRecipientRefNumber = RecipientRefNumber;
            MES.dmSenderIdent = SenderIdent;
            MES.dmSenderOrgUnit = SenderOrgUnit;
            if (SenderOrgUnitNum >= 0)
            {
                MES.dmSenderOrgUnitNum = SenderOrgUnitNum.ToString();
            }
            MES.dmSenderRefNumber = SenderRefNumber;
            MES.dmToHands = ToHands;
            MES.dmOVM = OVM;
            MES.dmOVMSpecified = OVM.HasValue;
            if (Attachments == null)
            {
                TIN.dmFiles = new tFilesArrayDmFile[0];
            }
            else
            {
                TIN.dmFiles = Attachments.GetFiles();
            }
            TIN.dmEnvelope = MES;
            tMessageCreateOutput TOU = new tMessageCreateOutput();
            try
            {
                TOU = OperationsWebService.CreateMessage(TIN);                
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Při volání metody CreateMessage webové služby OperationsWebService došlo k výjimce: {0}", ex.Message));
            }
            int StatusCode = StatusCodeToInt(TOU.dmStatus.dmStatusCode);
            if (StatusCode != 0)
            {
                throw new Exception(string.Format("CreateMessage: {0} StatusCode: {1}", TOU.dmStatus.dmStatusMessage, StatusCode));
            }
            return TOU.dmID;
        }

        public ISDSMessageStatus[] CreateMultipleMessage(
            ISDSRecipient[] Recipients,
            string Annotation,
            bool? AllowSubstDelivery,
            int LegalTitleLaw,
            string LegalTitlePar,
            string LegalTitlePoint,
            string LegalTitleSect,
            int LegalTitleYear,
            string RecipientIdent,
            string RecipientOrgUnit,
            int RecipientOrgUnitNum,
            string RecipientRefNumber,
            string SenderIdent,
            string SenderOrgUnit,
            int SenderOrgUnitNum,
            string SenderRefNumber,
            string ToHands,
            bool? PersonalDelivery,
            bool? OVM,
            ISDSSendOutFiles Attachments)
        {
            tRecipients[] Recs = new tRecipients[Recipients.Length];
            for (int i = 0; i < Recipients.Length; i++)
            {
                Recs[i] = new tRecipients();
                Recs[i].dbIDRecipient = Recipients[i].IDRecipient;
                Recs[i].dmRecipientOrgUnit = Recipients[i].RecipientOrgUnit;
                if (Recipients[i].RecipientOrgUnitNum >= 0)
                {
                    Recs[i].dmRecipientOrgUnitNum = Recipients[i].RecipientOrgUnitNum.ToString();
                }
                Recs[i].dmToHands = Recipients[i].ToHands;
            }
            tMultipleMessageCreateInput MMCI = new tMultipleMessageCreateInput();
            MMCI.dmRecipients = Recs;
            tMultipleMessageEnvelopeSub MMES = new tMultipleMessageEnvelopeSub();
            MMES.dmAllowSubstDelivery = AllowSubstDelivery;
            MMES.dmAnnotation = Annotation;
            if (LegalTitleLaw >= 0)
            {
                MMES.dmLegalTitleLaw = LegalTitleLaw.ToString();
            }            
            MMES.dmLegalTitlePar = LegalTitlePar;
            MMES.dmLegalTitlePoint = LegalTitlePoint;
            MMES.dmLegalTitleSect = LegalTitleSect;
            if (LegalTitleYear >= 0)
            {
                MMES.dmLegalTitleYear = LegalTitleYear.ToString();
            }
            MMES.dmOVM = OVM;
            MMES.dmOVMSpecified = OVM.HasValue;
            MMES.dmPersonalDelivery = PersonalDelivery;
            MMES.dmRecipientIdent = RecipientIdent;
            MMES.dmRecipientRefNumber = RecipientRefNumber;
            MMES.dmSenderIdent = SenderIdent;
            MMES.dmSenderOrgUnit = SenderOrgUnit;
            if (SenderOrgUnitNum >= 0)
            {
                MMES.dmSenderOrgUnitNum = SenderOrgUnitNum.ToString();
            }
            MMES.dmSenderRefNumber = SenderRefNumber;           
            MMCI.dmEnvelope = MMES;
            if (Attachments == null)
            {
                MMCI.dmFiles = new tFilesArrayDmFile[0];
            }
            else
            {
                MMCI.dmFiles = Attachments.GetFiles();
            }            
            tMultipleMessageCreateOutput MMCO = new tMultipleMessageCreateOutput();
            try
            {
                MMCO = OperationsWebService.CreateMultipleMessage(MMCI);
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Při volání metody CreateMultipleMessage webové služby OperationsWebService došlo k výjimce: {0}", ex.Message));
            }
            int StatusCode = StatusCodeToInt(MMCO.dmStatus.dmStatusCode);
            if (StatusCode != 0)
            {
                throw new Exception(string.Format("CreateMultipleMessage: {0} StatusCode: {1}", MMCO.dmStatus.dmStatusMessage, StatusCode));
            }
            ISDSMessageStatus[] MStatus = new ISDSMessageStatus[MMCO.dmMultipleStatus.Length];
            for (int i = 0; i < MStatus.Length; i++)
            {
                MStatus[i].MessageID = MMCO.dmMultipleStatus[i].dmID;
                MStatus[i].StatusCode = MMCO.dmMultipleStatus[i].dmStatus.dmStatusCode;
                MStatus[i].StatusMessage = MMCO.dmMultipleStatus[i].dmStatus.dmStatusMessage;
            }
            return MStatus;
        }
        
        private static ISDSDeliveredMessage PrepareDeliveredMessage(tReturnedMessage RM, string Type)
        {
            ISDSDeliveredMessage Res;
            Res.MessageEnvelope = PrepareMessageEnvelope(RM, Type);
            Res.DeliveredFiles = new ISDSDeliveredFiles();
            Res.DeliveredFiles.Files = RM.dmDm.dmFiles;
            return Res;
        }

        /// <summary>
        /// Stazeni prijate zpravy z ISDS bez elektronickeho podpisu
        /// </summary>
        /// <param name="MessageID">Identifikace zpravy</param>
        /// <returns>Stazena zprava</returns>
        public ISDSDeliveredMessage MessageDownload(string MessageID)
        {
            VerifyConnect();
            tIDMessInput MI = new tIDMessInput();
            MI.dmID = MessageID;
            tMessDownOutput MDO = new tMessDownOutput();
            try
            {
                MDO = OperationsWebService.MessageDownload(MI);
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Při volání metody MessageDownload webové služby OperationsWebService došlo k výjimce: {0}", ex.Message));
            }
            int StatusCode = StatusCodeToInt(MDO.dmStatus.dmStatusCode);
            if (StatusCode != 0)
            {
                throw new Exception(string.Format("MessageDownload: {0} StatusCode: {1}", MDO.dmStatus.dmStatusMessage, StatusCode));
            }
            return PrepareDeliveredMessage(MDO.dmReturnedMessage,MDO.dmReturnedMessage.dmType);
        }

        /// <summary>
        /// Stazeni podepsane prijate zpravy
        /// </summary>
        /// <param name="MessageID">Identifikace zpravy</param>
        /// <returns>Podepsana zprava v binarnim formatu</returns>
        public byte[] SignedMessageDownload(string MessageID)
        {
            VerifyConnect();
            tIDMessInput MI = new tIDMessInput();
            MI.dmID = MessageID;
            tSignedMessDownOutput SMDO = new tSignedMessDownOutput();
            try
            {
                SMDO = OperationsWebService.SignedMessageDownload(MI);
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Při volání metody SignedMessageDownload webové služby OperationsWebService došlo k výjimce: {0}", ex.Message));
            }
            int StatusCode = StatusCodeToInt(SMDO.dmStatus.dmStatusCode);
            if (StatusCode != 0)
            {
                throw new Exception(string.Format("SignedMessageDownload: {0} StatusCode: {1}", SMDO.dmStatus.dmStatusMessage, StatusCode));
            }            
            return SMDO.dmSignature;
        }

        /// <summary>
        /// Stazeni podepsane prijate zpravy do souboru
        /// </summary>
        /// <param name="MessageID">Identifikace zpravy</param>
        /// <param name="FileName">Nazev souboru, do ktereho ma byt zprava ulozena</param>
        public void SignedMessageDownloadToFile(string MessageID, string FileName)
        {
            File.WriteAllBytes(FileName, SignedMessageDownload(MessageID));
        }

        /// <summary>
        /// Stazeni informace o dodani, doruceni nebo nedoruceni zpravy
        /// </summary>
        /// <param name="MessageID">Identifikace zpravy</param>
        /// <returns>Dorucenka</returns>
        public ISDSDeliveryInfo GetDeliveryInfo(string MessageID)
        {
            VerifyConnect();
            tIDMessInput MI = new tIDMessInput();
            MI.dmID = MessageID;
            tDeliveryMessageOutput DMO = new tDeliveryMessageOutput();
            try
            {
                DMO = InfoWebService.GetDeliveryInfo(MI);
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Při volání metody GetDeliveryInfo webové služby InfoWebService došlo k výjimce: {0}", ex.Message));
            }
            int StatusCode = StatusCodeToInt(DMO.dmStatus.dmStatusCode);
            if (StatusCode != 0)
            {
                throw new Exception(string.Format("GetDeliveryInfo: {0} StatusCode: {1}", DMO.dmStatus.dmStatusMessage, StatusCode));
            }
            return PrepareDeliveryInfo(DMO.dmDelivery);
        }

        /// <summary>
        /// Stazeni podepsane informace o dodani, doruceni nebo nedoruceni zpravy
        /// </summary>
        /// <param name="MessageID">Identifikace zpravy</param>
        /// <returns>Podepsana dorucenka v binarni podobe</returns>
        public byte[] GetSignedDeliveryInfo(string MessageID)
        {
            VerifyConnect();
            tIDMessInput MI = new tIDMessInput();
            MI.dmID = MessageID;
            tSignDelivMessOutput DMO = new tSignDelivMessOutput();
            try
            {
                DMO = InfoWebService.GetSignedDeliveryInfo(MI);
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Při volání metody GetSignedDeliveryInfo webové služby InfoWebService došlo k výjimce: {0}", ex.Message));
            }
            int StatusCode = StatusCodeToInt(DMO.dmStatus.dmStatusCode);
            if (StatusCode != 0)
            {
                throw new Exception(string.Format("GetSignedDeliveryInfo: {0} StatusCode: {1}", DMO.dmStatus.dmStatusMessage, StatusCode));
            }
            return DMO.dmSignature;
        }

        /// <summary>
        /// Stazeni podepsane informace o dodani, doruceni nebo nedoruceni zpravy do souboru
        /// </summary>
        /// <param name="MessageID">Identifikace zpravy</param>
        /// <param name="FileName">Nazev souboru, do ktereho bude dorucenka ulozena</param>
        public void GetSignedDeliveryInfoToFile(string MessageID, string FileName)
        {
            File.WriteAllBytes(FileName, GetSignedDeliveryInfo(MessageID));
        }

        /// <summary>
        /// Slouzi k porovnani hashe datove zpravy ulozene mimo ISDS s originalem
        /// </summary>
        /// <param name="MessageID">Identifikace zpravy</param>
        /// <returns>Hash zpravy</returns>
        public ISDSHash VerifyMessage(string MessageID)
        {
            VerifyConnect();
            tIDMessInput MI = new tIDMessInput();
            MI.dmID = MessageID;
            tMessageVerifyOutput MVO = new tMessageVerifyOutput();
            try
            {
                MVO = InfoWebService.VerifyMessage(MI);
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Při volání metody VerifyMessage webové služby InfoWebService došlo k výjimce: {0}", ex.Message));
            }
            int StatusCode = StatusCodeToInt(MVO.dmStatus.dmStatusCode);
            if (StatusCode != 0)
            {
                throw new Exception(string.Format("VerifyMessage: {0} StatusCode: {1}", MVO.dmStatus.dmStatusMessage, StatusCode));
            }
            ISDSHash Res = new ISDSHash();
            Res.Algorithm = MVO.dmHash.algorithm;
            Res.Value = MVO.dmHash.Value;
            return Res;
        }

        /// <summary>
        /// Stazeni pouhe obalky prijate zpravy (bez pisemnosti)
        /// </summary>
        /// <param name="MessageID">Identifikace zpravy</param>
        /// <returns>Obalka zpravy</returns>
        public ISDSMessageEnvelope MessageEnvelopeDownload(string MessageID)
        {
            VerifyConnect();
            tIDMessInput MI = new tIDMessInput();
            MI.dmID = MessageID;
            tMessEnvelDownOutput MEDO = new tMessEnvelDownOutput();
            try
            {
                MEDO = InfoWebService.MessageEnvelopeDownload(MI);
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Při volání metody MessageDownloadWebService webové služby InfoWebService došlo k výjimce: {0}", ex.Message));
            }
            int StatusCode = StatusCodeToInt(MEDO.dmStatus.dmStatusCode);
            if (StatusCode != 0)
            {
                throw new Exception(string.Format("MessageEnvelopeDownload: {0} StatusCode: {1}", MEDO.dmStatus.dmStatusMessage, StatusCode));
            }
            return PrepareMessageEnvelope(MEDO.dmReturnedMessageEnvelope,MEDO.dmReturnedMessageEnvelope.dmType);
        }

        /// <summary>
        /// Vybrana dorucena zprava bude oznacena jako „Prectena“. 
        /// </summary>
        /// <param name="MessageID">Identifikace zpravy</param>
        public void MarkMessageAsDownloaded(string MessageID)
        {
            VerifyConnect();
            tIDMessInput MI = new tIDMessInput();
            MI.dmID = MessageID;
            tMarkMessOutput TMO = new tMarkMessOutput();
            try
            {
                TMO = InfoWebService.MarkMessageAsDownloaded(MI);
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Při volání metody MarkMessageAsDownloaded webové služby InfoWebService došlo k výjimce: {0}", ex.Message));
            }
            int StatusCode = StatusCodeToInt(TMO.dmStatus.dmStatusCode);
            if (StatusCode != 0)
            {
                throw new Exception(string.Format("MarkMessageAsDownloaded: {0} StatusCode: {1}", TMO.dmStatus.dmStatusMessage, StatusCode));
            }
        }

        /// <summary>
        /// Stazeni podepsane odeslane zpravy
        /// </summary>
        /// <param name="MessageID">Identifikace zpravy</param>
        /// <returns>Podepsana zprava v binarni podobe</returns>
        public byte[] SignedSentMessageDownload(string MessageID)
        {
            VerifyConnect();
            tIDMessInput MI = new tIDMessInput();
            MI.dmID = MessageID;
            tSignedMessDownOutput SMDO = new tSignedMessDownOutput();
            try
            {
                SMDO = OperationsWebService.SignedSentMessageDownload(MI);
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Při volání metody SignedSentMessageDownload webové služby OperationsWebService došlo k výjimce: {0}", ex.Message));
            }
            int StatusCode = StatusCodeToInt(SMDO.dmStatus.dmStatusCode);
            if (StatusCode != 0)
            {
                throw new Exception(string.Format("SignedSentMessageDownload: {0} StatusCode: {1}", SMDO.dmStatus.dmStatusMessage, StatusCode));
            }
            return SMDO.dmSignature;
        }

        /// <summary>
        /// Stazeni podepsane odeslane zpravy do souboru
        /// </summary>
        /// <param name="MessageID">Identifikace zpravy</param>
        /// <param name="FileName">Nazev souboru, do ktereho bude zprava ulozena</param>
        public void SignedSentMessageDownloadToFile(string MessageID, string FileName)
        {
            File.WriteAllBytes(FileName, SignedSentMessageDownload(MessageID));
        }

        private const int AsyncStatusCode = 1;

        /// <summary>
        /// Vyhledani schranky
        /// </summary>
        /// <param name="OwnerInfo"></param>
        /// <param name="StatusCode"></param>
        /// <param name="StatusMessage"></param>
        /// <param name="RefNumber"></param>
        /// <returns></returns>
        public ISDSOwnerInfo[] FindDataBox(ISDSOwnerInfo OwnerInfo, out int StatusCode, out string StatusMessage, out string RefNumber)
        {
            VerifyConnect();
            RefNumber = "";
            StatusCode = 0;
            StatusMessage = "";
            tFindDBInput FDBI = new tFindDBInput();
            FDBI.dbOwnerInfo = PrepareOwnerInfo(OwnerInfo);
            tFindDBOuput FDBO = new tFindDBOuput();
            try
            {
                FDBO = ManipulationWebService.FindDataBox(FDBI);
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Při volání metody FindDataBox webové služby ManipulationWebService došlo k výjimce: {0}", ex.Message));
            }
            StatusCode = StatusCodeToInt(FDBO.dbStatus.dbStatusCode);
            StatusMessage = FDBO.dbStatus.dbStatusMessage;
            if (StatusCode == AsyncStatusCode)
            {
                RefNumber = FDBO.dbStatus.dbStatusRefNumber;
                return null;
            }
            if ((FDBO.dbResults == null) || (FDBO.dbResults.dbOwnerInfo == null))
            {
                return new ISDSOwnerInfo[0];
            }
            ISDSOwnerInfo[] Res = new ISDSOwnerInfo[FDBO.dbResults.dbOwnerInfo.Length];
            for (int i = 0; i < FDBO.dbResults.dbOwnerInfo.Length; i++)
            {
                Res[i] = PrepareOwnerInfo(FDBO.dbResults.dbOwnerInfo[i]);
            }
            return Res;
        }

        /// <summary>
        /// Kontrola pristupnosti schranky
        /// </summary>
        /// <param name="DataBoxID"></param>
        /// <param name="RefNumber"></param>
        /// <returns></returns>
        public int CheckDataBox(string DataBoxID, out string RefNumber)
        {
            VerifyConnect();
            RefNumber = "";
            tIdDbInput IDI = new tIdDbInput();
            IDI.dbID = DataBoxID;
            tCheckDBOutput CDBO = new tCheckDBOutput();
            try
            {
                CDBO = ManipulationWebService.CheckDataBox(IDI);
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Při volání metody CheckDataBox webové služby ManipulationWebService došlo k výjimce: {0}", ex.Message));
            }
            int StatusCode = StatusCodeToInt(CDBO.dbStatus.dbStatusCode);
            if (StatusCode != 0)
            {
                if (StatusCode == AsyncStatusCode)
                {
                    RefNumber = CDBO.dbStatus.dbStatusRefNumber;
                    return 0;
                }
                throw new Exception(CDBO.dbStatus.dbStatusMessage);
            }
            return CDBO.dbState;
        }

        /// <summary>
        /// Ziskani udaju o opravnenych osobach k dane schrance
        /// </summary>
        /// <param name="DataBoxID"></param>
        /// <param name="RefNumber"></param>
        /// <returns></returns>
        public ISDSUserInfo[] GetDataBoxUsers(string DataBoxID, out string RefNumber)
        {
            VerifyConnect();
            RefNumber = "";
            tIdDbInput IDI = new tIdDbInput();
            IDI.dbID = DataBoxID;
            tGetDBUsersOutput GDBU = new tGetDBUsersOutput();
            try
            {
                GDBU = ManipulationWebService.GetDataBoxUsers(IDI);
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Při volání metody GetDataBoxUsers webové služby ManipulationWebService došlo k výjimce: {0}", ex.Message));
            }
            int StatusCode = StatusCodeToInt(GDBU.dbStatus.dbStatusCode);
            if (StatusCode != 0)
            {
                if (StatusCode == AsyncStatusCode)
                {
                    RefNumber = GDBU.dbStatus.dbStatusRefNumber;
                    return new ISDSUserInfo[0];
                }
                throw new Exception(GDBU.dbStatus.dbStatusMessage);
            }
            ISDSUserInfo[] Res = new ISDSUserInfo[GDBU.dbUsers.dbUserInfo.Length];
            for (int i = 0; i < GDBU.dbUsers.dbUserInfo.Length; i++)
            {
                Res[i] = PrepareUserInfo(GDBU.dbUsers.dbUserInfo[i]);
            }
            return Res;
        }
        
        /// <summary>
        /// Ziskani informaci o datove schrance ke ktere jsme pripojeni
        /// </summary>
        /// <param name="RefNumber"></param>
        /// <returns></returns>
        public ISDSOwnerInfo GetOwnerInfoFromLogin(out string RefNumber)
        {
            VerifyConnect();
            RefNumber = "";
            tDummyInput GOFL = new tDummyInput();
            GOFL.dbDummy = "";
            tGetOwnInfoOutput GOIO = new tGetOwnInfoOutput();
            try
            {
                GOIO = AccessWebService.GetOwnerInfoFromLogin(GOFL);
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Při volání metody GetOwnerInfoFromLogin webové služby AccessWebService došlo k výjimce: {0}", ex.Message));
            }
            int StatusCode = StatusCodeToInt(GOIO.dbStatus.dbStatusCode);
            if (StatusCode != 0)
            {
                if (StatusCode == AsyncStatusCode)
                {
                    RefNumber = GOIO.dbStatus.dbStatusRefNumber;
                    return new ISDSOwnerInfo();
                }
                throw new Exception(GOIO.dbStatus.dbStatusMessage);
            }
            return PrepareOwnerInfo(GOIO.dbOwnerInfo);
        }        

        /// <summary>
        /// Nastaveni datove schranky do rezimu otevreneho adresovani (§18a odst.1)
        /// </summary>
        /// <param name="ID">ID datove schranky</param>
        /// <param name="Approved"></param>
        /// <param name="ExternRefNumber"></param>
        /// <param name="RefNumber"></param>
        /// <returns></returns>
        public int SetOpenAddressing(
            string ID,
            bool? Approved,
            string ExternRefNumber,
            out string RefNumber)
        {
            VerifyConnect();
            RefNumber = "";
            tReqStatusOutput RSO = new tReqStatusOutput();
            tIdDbInput IDI = new tIdDbInput();
            IDI.dbID = ID;
            IDI.dbApproved = Approved;
            IDI.dbExternRefNumber = ExternRefNumber;
            try
            {
                RSO = ManipulationWebService.SetOpenAddressing(IDI);
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Při volání metody SetOpenAddressing webové služby ManipulationWebService došlo k výjimce: {0}", ex.Message));
            }
            int StatusCode = StatusCodeToInt(RSO.dbStatus.dbStatusCode);
            if (StatusCode != 0)
            {
                if (StatusCode == AsyncStatusCode)
                {
                    RefNumber = RSO.dbStatus.dbStatusRefNumber;
                    return StatusCode;
                }
                throw new Exception(RSO.dbStatus.dbStatusMessage);
            }
            return 0;
        }

        /// <summary>
        /// Zruseni nastaveni datove schranky do rezimu otevreneho adresovani (§18a odst.1)
        /// </summary>
        /// <param name="ID">ID schranky</param>
        /// <param name="Approved"></param>
        /// <param name="ExternRefNumber"></param>
        /// <param name="RefNumber"></param>
        /// <returns></returns>
        public int ClearOpenAddressing(
            string ID,
            bool? Approved,
            string ExternRefNumber,
            out string RefNumber)
        {
            VerifyConnect();
            RefNumber = "";
            tReqStatusOutput RSO = new tReqStatusOutput();
            tIdDbInput IDI = new tIdDbInput();
            IDI.dbID = ID;
            IDI.dbApproved = Approved;
            IDI.dbExternRefNumber = ExternRefNumber;
            try
            {
                RSO = ManipulationWebService.ClearOpenAddressing(IDI);
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Při volání metody ClearOpenAddressing webové služby ManipulationWebService došlo k výjimce: {0}", ex.Message));
            }
            int StatusCode = StatusCodeToInt(RSO.dbStatus.dbStatusCode);
            if (StatusCode != 0)
            {
                if (StatusCode == AsyncStatusCode)
                {
                    RefNumber = RSO.dbStatus.dbStatusRefNumber;
                    return StatusCode;
                }
                throw new Exception(RSO.dbStatus.dbStatusMessage);
            }
            return 0;
        }

        /// <summary>
        /// Potvrzeni doruceni komercni zpravy (§18a odst.2)
        /// </summary>
        /// <param name="MessageID"></param>
        public void ConfirmDelivery(string MessageID)
        {
            VerifyConnect();
            tIDMessInput MI = new tIDMessInput();
            MI.dmID = MessageID;
            tConfirmDeliveryOutput CDO = new tConfirmDeliveryOutput();
            try
            {
                CDO = InfoWebService.ConfirmDelivery(MI);
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Při volání metody ConfirmDelivery webové služby InfoWebService došlo k výjimce: {0}", ex.Message));
            }
            int StatusCode = StatusCodeToInt(CDO.dmStatus.dmStatusCode);
            if (StatusCode != 0)
            {
                throw new Exception(CDO.dmStatus.dmStatusMessage);
            }
        }

        /// <summary>
        /// Vraceni informaci o prihlasenem uzivateli
        /// </summary>
        /// <returns></returns>
        public ISDSUserInfo GetUserInfoFromLogin()
        {
            VerifyConnect();
            tDummyInput DI = new tDummyInput();
            DI.dbDummy = "";
            tGetUserInfoOutput GUIO = new tGetUserInfoOutput();
            try
            {
                GUIO = AccessWebService.GetUserInfoFromLogin(DI);
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Při volání metody GetUserInfoFromLogin webové služby AccessWebService došlo k výjimce: {0}", ex.Message));
            }

            int StatusCode = StatusCodeToInt(GUIO.dbStatus.dbStatusCode);
            if (StatusCode != 0)
            {
                throw new Exception(GUIO.dbStatus.dbStatusMessage);
            }
            return PrepareUserInfo(GUIO.dbUserInfo);
        }

        /// <summary>
        /// Informace o expiraci hesla
        /// </summary>
        /// <returns></returns>
        public DateTime? GetPasswordInfo()
        {
            VerifyConnect();
            tDummyInput DI = new tDummyInput();
            DI.dbDummy = "";
            tGetPasswInfoOutput GPIO = new tGetPasswInfoOutput();
            try
            {
                GPIO = AccessWebService.GetPasswordInfo(DI);
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Při volání metody GetPasswordInfo webové služby AccessWebService došlo k výjimce: {0}", ex.Message));
            }
            int StatusCode = StatusCodeToInt(GPIO.dbStatus.dbStatusCode);
            if (StatusCode != 0)
            {
                throw new Exception(GPIO.dbStatus.dbStatusMessage);
            }
            if (GPIO.pswExpDateSpecified)
            {
                return GPIO.pswExpDate;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// Zmena pristupoveho hesla k datove schrance
        /// </summary>
        /// <param name="OldPassword"></param>
        /// <param name="NewPassword"></param>
        public void ChangeISDSPassword(string OldPassword, string NewPassword)
        {
            VerifyConnect();
            tChngPasswInput CPI = new tChngPasswInput();
            CPI.dbOldPassword = OldPassword;
            CPI.dbNewPassword = NewPassword;
            tReqStatusOutput RSO = new tReqStatusOutput();
            try
            {
                RSO = AccessWebService.ChangeISDSPassword(CPI);
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Při volání metody ChangeISDSPassword webové služby AccessWebService došlo k výjimce: {0}", ex.Message));
            }
            int StatusCode = StatusCodeToInt(RSO.dbStatus.dbStatusCode);
            if (StatusCode != 0)
            {
                throw new Exception(RSO.dbStatus.dbStatusMessage);
            }
        }

        /// <summary>
        /// Overeni pravosti zpravy
        /// </summary>
        /// <param name="FilePath"></param>
        public bool AuthenticateMessage(String FilePath)
        {

            VerifyConnect();
            FileStream FStream = File.OpenRead(FilePath);
            byte[] FBytes = new byte[FStream.Length];
            FStream.Read(FBytes, 0, (int)FStream.Length);
            FStream.Close();



            tAuthenticateMessageInput input = new tAuthenticateMessageInput();
            input.dmMessage = FBytes;

            tAuthenticateMessageOutput AMO = new tAuthenticateMessageOutput();

            try
            {
                AMO = OperationsWebService.AuthenticateMessage(input);
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Při volání metody AuthenticateMessage webové služby OperationWebService došlo k výjimce: {0}", ex.Message));
            }
            int StatusCode = StatusCodeToInt(AMO.dmStatus.dmStatusCode);
            if (StatusCode != 0)
            {
                throw new Exception(AMO.dmStatus.dmStatusMessage);
            }

            return AMO.dmAuthResult.Value;

        }

        public tStateChangesRecord[] GetMessagesChanges() {
            VerifyConnect();

            tGetStateChangesInput input = new tGetStateChangesInput();
            input.dmToTime = DateTime.Now;
            input.dmFromTime = DateTime.Now.AddDays(-7);

            tGetStateChangesOutput GSCO = new tGetStateChangesOutput();

            try
            {
                GSCO = InfoWebService.GetMessageStateChanges(input);
            }
            catch (Exception ex) 
            {
                throw new Exception(string.Format("Při volání metody GetMessageStateChanges webové služby OperationWebService došlo k výjimce: {0}", ex.Message));
            }
            int StatusCode = StatusCodeToInt(GSCO.dmStatus.dmStatusCode);
            if (StatusCode != 0)
            {
                throw new Exception(GSCO.dmStatus.dmStatusMessage);
            }

            return GSCO.dmRecords.dmRecord;

            
        }

    }
}
