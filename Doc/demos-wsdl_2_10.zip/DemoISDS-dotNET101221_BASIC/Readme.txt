----------------------------------------------------
TATO VERZE JE URČENA PRO ALTERNATIVNÍ PŘÍSTUP K ISDS
----------------------------------------------------

Součásti projektu
-----------------

ISDSBox.cs - zapouzdření proxy tříd pro práci s datovými schránkami
Program.cs - testovací konzolová aplikace
app.Config, AssemblyInfo.cs, DemoISDS.csproj - standardní součásti C# projektu
DataBoxManipulation.cs, DataBoxAccess.cs, dmInfoWebService.cs, dmOperationsWebService.cs - vygenerované proxy třídy 
pro jednotlivé služby
Readme.txt - tento soubor

Instalace
---------

- vytvořte adresář
- nakopírujte do něho součásti projektu
- ve Visual studiu 2008 otevřete DemoISDS.csproj

Překlad a spuštění
------------------

Pro spuštění demonstračního programu budete potřebovat přihlašovací údaje ke dvěma schránkám. 

Dotazy a připomínky k projektu můžete zasílat emailem na adresu isds@602.cz

Novinky ve verzi z 18.8.2010
----------------------------

- byla přidána metoda pro ověření pravosti zprávy AuthenticateMessage

Novinky ve verzi z 14.1.2010
----------------------------

- byla přidána funkce pro zjištění informací o přihlášeném uživateli GetUserInfoFromLogin
- byla přidána funkce pro zjištění informace o expiraci hesla GetPasswordInfo
- byla přidána funkce pro změnu hesla ChangeISDSPassword

Novinky ve verzi z 19.11.2009
-----------------------------

- byla přidána podpora pro přístup k ISDS přes proxy server
- byla přidána funkce pro hromadné rozesílání zásilek CreateMultipleMessage
- byly přidány funkce pro podporu posílání komerčních zpráv (Set/ClearOpenAddressing a ConfirmDelivery)