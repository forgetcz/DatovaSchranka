﻿// Ukazkovy program (konzolova aplikace) demonstrujici moznosti prace s datovymi schrankami
//
// (c) 2009 Software602 a.s. 
//
// Pripadne dotazy a pripominky zasilejte na: ISDS@602.cz

using System;
using System.Text;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using ISDS;

namespace DemoISDS
{
    class Program
    {
        /// <summary>
        /// Objekt reprezentujici pripojeni k prvni datove schrance
        /// </summary>
        static ISDSBox IB1 = null;
        /// <summary>
        /// Objekt reprezentujici pripojeni k druhe datove schrance
        /// </summary>
        static ISDSBox IB2 = null;

        static string LoginName1 = "";
        static string Password1 = "";
        static X509Certificate Certificate1 = null;
        static string ISDSBoxID1 = "";

        static string LoginName2 = "";
        static string Password2 = "";
        static X509Certificate Certificate2 = null;
        static string ISDSBoxID2 = "";

        /// <summary>
        /// Pomocna metoda
        /// </summary>
        static void Exit()
        {
            Console.WriteLine("Pro ukončení programu stiskněte <ENTER>");
            Console.ReadLine();
        }

        /// <summary>
        /// Pomocna metoda
        /// </summary>
        /// <param name="DM"></param>
        static void WriteISDSDM(ISDSDM DM)
        {
            Console.WriteLine("AllowSubstDelivery: " + DM.AllowSubstDelivery);
            Console.WriteLine("AmbiguousRecipient: " + DM.AmbiguousRecipient);
            Console.WriteLine("Annotation: " + DM.Annotation);
            Console.WriteLine("ID: " + DM.ID);
            Console.WriteLine("IDRecipient: " + DM.IDRecipient);
            Console.WriteLine("IDSender: " + DM.IDSender);
            Console.WriteLine("LegalTitleLaw: " + DM.LegalTitleLaw);
            Console.WriteLine("LegalTitlePar: " + DM.LegalTitlePar);
            Console.WriteLine("LegalTitlePoint: " + DM.LegalTitlePoint);
            Console.WriteLine("LegalTitleSect: " + DM.LegalTitleSect);
            Console.WriteLine("LegalTitleYear: " + DM.LegalTitleYear);
            Console.WriteLine("PersonalDelivery: " + DM.PersonalDelivery);
            Console.WriteLine("Recipient: " + DM.Recipient);
            Console.WriteLine("RecipientAddress: " + DM.RecipientAddress);
            Console.WriteLine("RecipientIdent: " + DM.RecipientIdent);
            Console.WriteLine("RecipientOrgUnit: " + DM.RecipientOrgUnit);
            Console.WriteLine("RecipientOrgUnitNum: " + DM.RecipientOrgUnitNum);
            Console.WriteLine("RecipientRefNumber: " + DM.RecipientRefNumber);
            Console.WriteLine("Sender: " + DM.Sender);
            Console.WriteLine("SenderAddress: " + DM.SenderAddress);
            Console.WriteLine("SenderIdent: " + DM.SenderIdent);
            Console.WriteLine("SenderOrgUnit: " + DM.SenderOrgUnit);
            Console.WriteLine("SenderOrgUnitNum: " + DM.SenderOrgUnitNum);
            Console.WriteLine("SenderRefNumber: " + DM.SenderRefNumber);
            Console.WriteLine("SenderType: " + DM.SenderType.ToString());
            Console.WriteLine("ToHands: " + DM.ToHands);
        }

        /// <summary>
        /// Pomocna metoda
        /// </summary>
        /// <param name="Hash"></param>
        static void WriteISDSHash(ISDSHash Hash)
        {
            Console.WriteLine("Hash.Algorithm: " + Hash.Algorithm);
        }

        /// <summary>
        /// Pomocna metoda
        /// </summary>
        /// <param name="MEI"></param>
        static void WriteISDSMessageEnvelopeInfo(ISDSMessageEnvelopeInfo MEI)
        {
            Console.WriteLine("AcceptanceTime: " + MEI.AcceptanceTime);
            Console.WriteLine("DeliveryTime: " + MEI.DeliveryTime);
            Console.WriteLine("MessageStatus: " + MEI.MessageStatus);
            Console.WriteLine(string.Format("AttachmentSize: {0} kB", MEI.AttachmentSize.ToString()));
        }

        /// <summary>
        /// Pomocna metoda
        /// </summary>
        /// <param name="ME"></param>
        static void WriteISDSMessageEnvelope(ISDSMessageEnvelope ME)
        {
            WriteISDSDM(ME.DM);
            WriteISDSMessageEnvelopeInfo(ME.EnvelopeInfo);
            WriteISDSHash(ME.Hash);
            Console.WriteLine("Type: " + ME.Type);
        }

        /// <summary>
        /// Pomocna metoda
        /// </summary>
        /// <param name="MI"></param>
        static void WriteISDSMessageInfo(ISDSMessageInfo MI)
        {
            Console.WriteLine("Ordinal: " + MI.Ordinal);
            WriteISDSDM(MI.DM);
            WriteISDSMessageEnvelopeInfo(MI.EnvelopeInfo);
            Console.WriteLine("Type: " + MI.Type);
        }

        /// <summary>
        /// Pomocna metoda
        /// </summary>
        /// <param name="DM"></param>
        static void WriteISDSDeliveredMessage(ISDSDeliveredMessage DM)
        {
            WriteISDSMessageEnvelope(DM.MessageEnvelope);
        }

        /// <summary>
        /// Pomocna metoda
        /// </summary>
        /// <param name="DI"></param>
        static void WriteISDSDeliveryInfo(ISDSDeliveryInfo DI)
        {
            WriteISDSMessageEnvelope(DI.MessageEnvelope);
            Console.WriteLine("Events: " + DI.Events.Length.ToString());
            for (int i = 0; i < DI.Events.Length; i++)
            {
                Console.WriteLine(DI.Events[i].Time + " " + DI.Events[i].Descr);
            }
        }

        /// <summary>
        /// Pomocna metoda
        /// </summary>
        /// <param name="DI"></param>
        static void WriteISDSOwnerInfo(ISDSOwnerInfo OwnerInfo)
        {
            Console.WriteLine("adCity: " + OwnerInfo.adCity);
            Console.WriteLine("adNumberInMunicipality: " + OwnerInfo.adNumberInMunicipality);
            Console.WriteLine("adNumberInStreet: " + OwnerInfo.adNumberInStreet);
            Console.WriteLine("adState: " + OwnerInfo.adState);
            Console.WriteLine("adStreet: " + OwnerInfo.adStreet);
            Console.WriteLine("adZipCode: " + OwnerInfo.adZipCode);
            Console.WriteLine("biCity: " + OwnerInfo.biCity);
            Console.WriteLine("biCounty: " + OwnerInfo.biCounty);
            Console.WriteLine("biDate: " + OwnerInfo.biDate);
            Console.WriteLine("biState: " + OwnerInfo.biState);
            Console.WriteLine("dbID: " + OwnerInfo.dbID);
            Console.WriteLine("dbType: " + OwnerInfo.dbType);
            Console.WriteLine("email: " + OwnerInfo.email);
            Console.WriteLine("firmName: " + OwnerInfo.firmName);
            Console.WriteLine("ic: " + OwnerInfo.ic);
            Console.WriteLine("nationality: " + OwnerInfo.nationality);
            Console.WriteLine("pnFirstName: " + OwnerInfo.pnFirstName);
            Console.WriteLine("pnLastName: " + OwnerInfo.pnLastName);
            Console.WriteLine("pnLastNameAtBirth: " + OwnerInfo.pnLastNameAtBirth);
            Console.WriteLine("pnMiddleName: " + OwnerInfo.pnMiddleName);
            Console.WriteLine("telNumber: " + OwnerInfo.telNumber);
            Console.WriteLine("Identifier: "+OwnerInfo.Identifier);
            Console.WriteLine("RegistryCode: "+OwnerInfo.RegistryCode);
            Console.WriteLine("dbState: "+OwnerInfo.dbState);
            Console.WriteLine("dbEffectiveOVM: "+OwnerInfo.dbEffectiveOVM);
            Console.WriteLine("dbOpenAddressing: "+OwnerInfo.dbOpenAddressing);
        }

        /// <summary>
        /// Pomocna metoda
        /// </summary>
        /// <param name="UserInfo"></param>
        static void WriteISDSUserInfo(ISDSUserInfo UserInfo)
        {
            Console.WriteLine("adCity: "+UserInfo.adCity);
            Console.WriteLine("adNumberInMunicipality: "+UserInfo.adNumberInMunicipality);
            Console.WriteLine("adNumberInStreet: "+UserInfo.adNumberInStreet);
            Console.WriteLine("adState: "+UserInfo.adState);
            Console.WriteLine("adStreet: "+UserInfo.adStreet);
            Console.WriteLine("adZipCode: "+UserInfo.adZipCode);
            Console.WriteLine("biDate: "+UserInfo.biDate.ToString());
            Console.WriteLine("pnFirstName: "+UserInfo.pnFirstName);
            Console.WriteLine("pnLastName: "+UserInfo.pnLastName);
            Console.WriteLine("pnLastNameAtBirth: "+UserInfo.pnLastNameAtBirth);
            Console.WriteLine("pnMiddleName: "+UserInfo.pnMiddleName);
            Console.WriteLine("userID: "+UserInfo.userID);
            Console.WriteLine("userPrivils: "+UserInfo.userPrivils);
            Console.WriteLine("userType: "+UserInfo.userType.ToString());
        }

        /// <summary>
        /// Pomocna metoda
        /// </summary>
        static void Separator()
        {
            Console.WriteLine("####################################################################");
        }

        /// <summary>
        /// Vyber certifikatu z uloziste
        /// </summary>
        /// <returns></returns>
        static X509Certificate SelectX509Certificate()
        {
            X509Store Store = new X509Store();
            Store.Open(OpenFlags.ReadOnly);
            X509CertificateCollection StoreCollection = (X509CertificateCollection)Store.Certificates;
            int NumOf = StoreCollection.Count;
            Console.WriteLine("Ve Vašem úložišti se nacházejí tyto certifikáty:");
            for (int i = 0; i < NumOf; i++)
            {
                ConsoleColor CC = Console.ForegroundColor;
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("{0} ",i);
                Console.ForegroundColor = CC;
                Console.WriteLine("{0}",StoreCollection[i].Subject);
            }
            Console.WriteLine();
            int CertNum = -1;
            do
            {
                Console.WriteLine("Zadejte číslo certifikátu se kterým se chcete připojit a stiskněte <Enter>");
                try
                {
                    CertNum = Convert.ToInt32(Console.ReadLine());
                }
                catch
                {
                }
            } while ((CertNum < 0) || (CertNum >= NumOf));
            return StoreCollection[CertNum];
        }

        /// <summary>
        /// Hlavni procedura programu
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            Console.WriteLine("Ukázkový program demonstrující možnosti práce s datovými schránkami");
            Console.WriteLine("(c) 2009 Software602 a.s.");
            Console.WriteLine();
            Console.WriteLine("Budete vyzváni k zadání přihlašovacích údajů ke dvěma schránkám. "+
                "Ke každé z těchto schránek se můžete připojit buď jménem a heslem, "+
                "nebo klientským certifikátem vybraným z úložiště certifikátů.");
            Console.WriteLine();
            Console.Write("Chcete se k první datové schránce připojit certifikátem ? (A/N)");
            LoginType LT = LoginType.Cert;
            if (Console.ReadKey().Key == ConsoleKey.A)
            {
                Console.WriteLine();
                Certificate1 = SelectX509Certificate();
            }
            else
            {
                LT = LoginType.Password;
                Console.WriteLine();
                Console.Write("Zadejte přihlašovací jméno k první datové schránce a stiskněte <Enter>: ");
                LoginName1 = Console.ReadLine();
                Console.Write("Zadejte heslo k první datové schránce a stiskněte <Enter>: ");
                ConsoleColor CC = Console.ForegroundColor;
                Console.ForegroundColor = ConsoleColor.Black;
                Console.CursorVisible = false;
                Password1 = Console.ReadLine();
                Console.ForegroundColor = CC;
                Console.CursorVisible = true;
            }
            try
            {
                Console.WriteLine("Probíhá připojování k první datové schránce...");
                IB1 = new ISDSBox(LT, PortalType.CZebox, LoginName1, Password1, "", Certificate1);
                IB1.Connect();
                Console.WriteLine("Připojování proběhlo v pořádku");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Během připojování došlo k výjimce: " + ex.Message);
                Exit();
                return;
            }

            Console.WriteLine();
            Console.Write("Chcete se k druhé datové schránce připojit certifikátem ? (A/N)");
            if (Console.ReadKey().Key == ConsoleKey.A)
            {
                LT = LoginType.Cert;
                Console.WriteLine();
                Certificate2 = SelectX509Certificate();
            }
            else
            {
                LT = LoginType.Password;
                Console.WriteLine();
                Console.Write("Zadejte přihlašovací jméno k druhé datové schránce a stiskněte <Enter>: ");
                LoginName2 = Console.ReadLine();
                Console.Write("Zadejte heslo k druhé datové schránce a stiskněte <Enter>: ");
                ConsoleColor CC = Console.ForegroundColor;
                Console.ForegroundColor = ConsoleColor.Black;
                Console.CursorVisible = false;
                Password2 = Console.ReadLine();
                Console.ForegroundColor = CC;
                Console.CursorVisible = true;
            }
            try
            {
                Console.WriteLine("Probíhá připojování k druhé datové schránce...");
                IB2 = new ISDSBox(LT, PortalType.CZebox, LoginName2, Password2, "", Certificate2);
                IB2.Connect();
                Console.WriteLine("Připojování proběhlo v pořádku");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Během připojování došlo k výjimce: " + ex.Message);
                Exit();
                return;
            }

            Separator();

            Console.WriteLine("Probíhá test získání informací o vlastníkovi první schránky ke které jsme připojeni");

            bool IB1OVM = true;
            try
            {
                string RefNumber;
                ISDSOwnerInfo OwnerInfo = IB1.GetOwnerInfoFromLogin(out RefNumber);
                Console.WriteLine("Informace o vlastníkovi první schránky:");
                ISDSBoxID1 = OwnerInfo.dbID;
                IB1OVM = ((OwnerInfo.dbType == tDbType.OVM)||(OwnerInfo.dbType == tDbType.OVM_EXEKUT)||
                    (OwnerInfo.dbType == tDbType.OVM_NOTAR)||(OwnerInfo.dbType == tDbType.OVM_REQ));
                WriteISDSOwnerInfo(OwnerInfo);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Exit();
                return;
            }

            Separator();

            Console.WriteLine("Probíhá test získání informací o vlastníkovi druhé schránky ke které jsme připojeni");

            bool IB2OVM = true;
            try
            {
                string RefNumber;
                ISDSOwnerInfo OwnerInfo = IB2.GetOwnerInfoFromLogin(out RefNumber);
                Console.WriteLine("Informace o vlastníkovi druhé schránky:");
                ISDSBoxID2 = OwnerInfo.dbID;
                IB2OVM = ((OwnerInfo.dbType == tDbType.OVM)||(OwnerInfo.dbType == tDbType.OVM_EXEKUT)||
                    (OwnerInfo.dbType == tDbType.OVM_NOTAR)||(OwnerInfo.dbType == tDbType.OVM_REQ));
                WriteISDSOwnerInfo(OwnerInfo);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Exit();
                return;
            }

            Separator();

            // zaslani testovaci zasilky
            // k zasilce bude pripojen vytvoreny testovaci soubor

            string TestFileName1 = @"C:\TESTISDS_1.TXT";
            string TestFileData1 = "Prvni testovaci datovy soubor";
            string TestFileName2 = @"C:\TESTISDS_2.TXT";
            string TestFileData2 = "Druhy testovaci datovy soubor";
            Console.WriteLine("Probíhá vytvoření testovacích souborů...");
            try
            {
                File.WriteAllText(TestFileName1, TestFileData1);
                File.WriteAllText(TestFileName2, TestFileData2);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Testovací soubor se nepodařilo vytvořit: " + ex.Message);
                Exit();
                return;
            }
            Console.WriteLine("Vytvořeny testovací soubory: " + TestFileName1 + " "+TestFileName2);

            Console.WriteLine("Probíhá zaslání testovací zprávy z první do druhé schránky...");
            string TestMessageID = "";
            try
            {
                ISDSSendOutFiles SOF = new ISDSSendOutFiles();
                SOF.AddFile(TestFileName1);
                SOF.AddFile(TestFileName2);
                TestMessageID = IB1.CreateMessage(ISDSBoxID2, "Testovací zpráva 1->2",
                    false,
                    677,
                    "231", "179", "331", 2010,
                    "VZ-147", "Vaše org jednotka", -1, "včj. 253",
                    "NZ-557", "Naše org jednotka", -1, "nčj. 589",
                    "K rukám p.Nováka", false,null, SOF);
                Console.WriteLine("Zaslání testovací zprávy proběhlo v pořádku");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Exit();
                return;
            }

            Console.WriteLine("Pro pokračování stiskněte <ENTER>");
            Console.ReadLine();
                
            Separator();
            
            // test nacteni seznamu odeslanych zprav
            
            DateTime Today = DateTime.Now;
            DateTime Tomorrow = Today.AddDays(1);
            ISDSMessageInfo[] MessagesList;
            
            Console.WriteLine("Probíhá načítání seznamu dnes odeslaných zpráv...");
            try
            {
                MessagesList = IB1.GetListOfSentMessages(
                    new DateTime(Today.Year, Today.Month, Today.Day),
                    new DateTime(Tomorrow.Year, Tomorrow.Month, Tomorrow.Day),
                    0, -1, -1, -1);
                Console.WriteLine("Celkem nalezeno " + MessagesList.Length.ToString() + " dnes odeslaných zpráv");
                Console.WriteLine("Pro vypsání seznamu zpráv stiskněte <ENTER>");
                Console.ReadLine();
                foreach (ISDSMessageInfo MI in MessagesList)
                {
                    WriteISDSMessageInfo(MI);
                    Console.WriteLine("--------------------------------------------------------------------");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Exit();
                return;
            }

            Separator();

            // vytvoreni testovaciho adresare
            string TestISDSDir = @"C:\TESTISDS";
            Console.WriteLine("Bude vytvořen adresář {0} pro vracená data", TestISDSDir);
            try
            {
                if (!Directory.Exists(TestISDSDir))
                {
                    Directory.CreateDirectory(TestISDSDir);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Testovací adresář se nepodařilo vytvořit: " + ex.Message);
                Exit();
                return;
            }

            // test stazeni odeslane podepsane zpravy
            if (TestMessageID != "")
            {
                Separator();
                Console.WriteLine("Probíhá stažení odeslané zprávy v podepsaném tvaru");
                try
                {
                    string FileName = TestISDSDir + @"\ODESLANA.ZFO";
                    IB1.SignedSentMessageDownloadToFile(TestMessageID, FileName);
                    Console.WriteLine("Odeslaná zpráva byla v podepsaném tvaru uložena do souboru " + FileName);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    Exit();
                    return;
                }
            }
            
            Separator();

            Console.WriteLine("Probíhá zaslání testovací zprávy z druhé do první schránky...");
            try
            {
                ISDSSendOutFiles SOF = new ISDSSendOutFiles();
                SOF.AddFile(TestFileName1);
                SOF.AddFile(TestFileName2);
                TestMessageID = IB2.CreateMessage(ISDSBoxID1, "Testovací zpráva 2->1",
                    false,
                    677,
                    "231", "179", "331", 2010,
                    "VZ-147", "Vaše org jednotka", -1, "včj. 253",
                    "NZ-557", "Naše org jednotka", -1, "nčj. 589",
                    "K rukám p.Nováka", false, false,SOF);
                Console.WriteLine("Zaslání testovací zprávy proběhlo v pořádku");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Exit();
                return;
            }

            Separator();

            // test nacteni seznamu doslych zprav
            
            Console.WriteLine("Probíhá načítání seznamu dnes došlých zpráv...");
            string ReceivedMessageID = "";
            try
            {
                MessagesList = IB1.GetListOfReceivedMessages(
                    new DateTime(Today.Year, Today.Month, Today.Day),
                    new DateTime(Tomorrow.Year, Tomorrow.Month, Tomorrow.Day),
                    0, -1, -1, -1);
                Console.WriteLine("Celkem nalezeno " + MessagesList.Length.ToString() + " došlých zpráv");
                Console.WriteLine("Pro vypsání seznamu zpráv stiskněte <ENTER>");
                Console.ReadLine();
                foreach (ISDSMessageInfo MI in MessagesList)
                {
                    WriteISDSMessageInfo(MI);
                    Console.WriteLine("--------------------------------------------------------------------");
                    if (ReceivedMessageID == "")
                    {
                        ReceivedMessageID = MI.DM.ID;
                    }
                }
                if (ReceivedMessageID == "")
                {
                    ReceivedMessageID = TestMessageID;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Exit();
                return;
            }

            Separator();

            // test stazeni dorucenky

            ReceivedMessageID = TestMessageID;

            Console.WriteLine("Probíhá test stažení doručenky");
            try
            {
                ISDSDeliveryInfo MI = IB1.GetDeliveryInfo(ReceivedMessageID);
                Console.WriteLine("Doručenka:");
                WriteISDSDeliveryInfo(MI);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Exit();
                return;
            }

            if (ReceivedMessageID != "")
            {
                Separator();

                Console.WriteLine("Probíhá stažení testovací zprávy...");
                try
                {
                    ISDSDeliveredMessage DM = IB1.MessageDownload(ReceivedMessageID);
                    DM.DeliveredFiles.SaveFilesToDirectory(TestISDSDir);
                    Console.WriteLine("Testovací zpráva byla stažena");
                    WriteISDSDeliveredMessage(DM);
                    Console.WriteLine("Soubory obsažené ve zprávě byly uloženy do adresáře " + TestISDSDir);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    Exit();
                    return;
                }
            }

            if (ReceivedMessageID != "")
            {
                // test oznaceni testovaci zpravy jako dorucena
                Separator();

                Console.WriteLine("Probíhá označení zprávy jako doručené...");
                try
                {
                    IB1.MarkMessageAsDownloaded(ReceivedMessageID);
                    Console.WriteLine("Odeslaná testovací zpráva byla označena jako doručená");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    Exit();
                    return;
                }
            }

            if (ReceivedMessageID != "")
            {
                Separator();

                // test stazeni obalky odeslane testovaci zpravy

                Console.WriteLine("Probíhá stažení obálky testovací zprávy...");
                try
                {
                    ISDSMessageEnvelope ME = IB1.MessageEnvelopeDownload(ReceivedMessageID);
                    Console.WriteLine("Obálka testovací zprávy:");
                    WriteISDSMessageEnvelope(ME);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    Exit();
                    return;
                }
            }

            // test overeni zpravy

            if (ReceivedMessageID != "")
            {
                Separator();

                Console.WriteLine("Probíhá verifikace zprávy...");
                try
                {
                    ISDSHash Hash = IB1.VerifyMessage(ReceivedMessageID);
                    string HashFileName = TestISDSDir + @"\HASH.BIN";
                    File.WriteAllBytes(HashFileName, Hash.Value);
                    Console.WriteLine("Hash testovací zprávy byl uložen do souboru " + HashFileName);
                    Console.WriteLine("Použitý hashovací algoritmus: " + Hash.Algorithm);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    Exit();
                    return;
                }
            }

            if (ReceivedMessageID != "")
            {
                Separator();

                // test stazeni dorucene zpravy v podepsanem tvaru
                Console.WriteLine("Probíhá stažení zprávy v podepsaném tvaru");
                try
                {
                    string FileName = TestISDSDir + @"\TESTOVACI.ZFO";
                    IB1.SignedMessageDownloadToFile(ReceivedMessageID, FileName);
                    Console.WriteLine("Testovací zpráva byla v podepsaném tvaru uložena do souboru " + FileName);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    Exit();
                    return;
                }
            }

            if (ReceivedMessageID != "")
            {
                Separator();
                // test stazeni podepsane dorucenky
                Console.WriteLine("Probíhá stažení doručenky v podepsaném tvaru");
                try
                {
                    string FileName = TestISDSDir + @"\DORUCENKA.ZFO";
                    IB1.GetSignedDeliveryInfoToFile(ReceivedMessageID, FileName);
                    Console.WriteLine("Doručenka byla v podepsaném tvaru uložena do souboru " + FileName);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    Exit();
                    return;
                }
            }

            Separator();

            Console.WriteLine("Probíhá test vyhledávání schránky");

            try
            {
                ISDSOwnerInfo OwnerInfo;
                OwnerInfo.adCity = "";
                OwnerInfo.adNumberInMunicipality = "";
                OwnerInfo.adNumberInStreet = "";
                OwnerInfo.adState = "";
                OwnerInfo.adStreet = "";
                OwnerInfo.adZipCode = "";
                OwnerInfo.biCity = "";
                OwnerInfo.biCounty = "";
                OwnerInfo.biDate = null;
                OwnerInfo.biState = "";
                OwnerInfo.dbID = "";
                OwnerInfo.dbType = tDbType.OVM;
                OwnerInfo.email = "";
                OwnerInfo.firmName = "OVM";
                OwnerInfo.ic = "";
                OwnerInfo.nationality = "";
                OwnerInfo.pnFirstName = "";
                OwnerInfo.pnLastName = "";
                OwnerInfo.pnLastNameAtBirth = "";
                OwnerInfo.pnMiddleName = "";
                OwnerInfo.telNumber = "";
                OwnerInfo.dbEffectiveOVM = false;
                OwnerInfo.Identifier = "";
                OwnerInfo.RegistryCode = "";
                OwnerInfo.dbState = 1;
                OwnerInfo.dbOpenAddressing = false;
                int StatusCode;
                string RefNumber;
                string StatusMessage;
                ISDSOwnerInfo[] Results = IB1.FindDataBox(OwnerInfo, out StatusCode, out StatusMessage, out RefNumber);
                Console.WriteLine("Vyhledání schránky skončilo s výsledkem: ");
                Console.WriteLine("StatusCode: " + StatusCode.ToString());
                Console.WriteLine("StatusMessage: " + StatusMessage);
                Console.WriteLine("RefNumber: " + RefNumber);
                if (Results != null)
                {
                    Console.WriteLine("Nalezeno {0} výsledků.", Results.Length);
                }
                Console.WriteLine("Pro vypsání vrácených schránek stiskněte <ENTER>");
                Console.ReadLine();
                foreach (ISDSOwnerInfo OI in Results)
                {
                    WriteISDSOwnerInfo(OI);
                    Console.WriteLine("--------------------------------------------------------------------");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Exit();
                return;
            }

            Separator();

            Console.WriteLine("Probíhá test kontroly přístupnosti schránky");

            try
            {
                string RefNumber;
                int State = IB1.CheckDataBox(ISDSBoxID1, out RefNumber);
                Console.WriteLine("Schránka {0} stav {1}", ISDSBoxID1, State);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Exit();
                return;
            }

            Separator();
                        
            Console.WriteLine("Probíhá test získání informací o přihlášeném uživateli");

            try
            {
                ISDSUserInfo UI = IB1.GetUserInfoFromLogin();
                Console.WriteLine("Přihlášený uživatel:");
                WriteISDSUserInfo(UI);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Exit();
                return;
            }

            Separator();

            Console.WriteLine("Probíhá test získání informace o expiraci hesla");

            try
            {
                DateTime? DT = IB1.GetPasswordInfo();
                if (DT == null)
                {
                    Console.WriteLine("Heslo nikdy nevyexpiruje");
                }
                else
                {
                    Console.WriteLine("Heslo vyexpiruje: " + DT.ToString());
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Exit();
                return;
            }

            Separator();

            Console.WriteLine("Probíhá test ověření pravosti zprávy uložené v " + TestISDSDir + @"\TESTOVACI.ZFO");

            try
            {
                bool auth = IB1.AuthenticateMessage(TestISDSDir + @"\TESTOVACI.ZFO");
                if (auth)
                {
                    Console.WriteLine("Zpráva je pravá.");
                }
                else
                {
                    Console.WriteLine("Zpráva není pravá");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Exit();
                return;
            }

            Separator();

            Console.WriteLine("Probíhá test stažení změn stavu odeslaných zpráv za poslední týden");

            try
            {
                tStateChangesRecord[] Changes = IB1.GetMessagesChanges();
                Console.WriteLine("Došlo k následujícím změnám stavů zpráv:");
                foreach(tStateChangesRecord change in Changes){
                    Console.WriteLine("ID zprávy "+ change.dmID +"; čas změny stavu "+change.dmEventTime+"; stav zprávy "+change.dmMessageStatus);
                }
            }
            catch (Exception ex) {
                Console.WriteLine(ex.Message);
                Exit();
                return;
            }

            Exit();            
        }
    }
}
