<?
//-----------------------------------------------------
// Konfiguracni soubor pro komunikaci s ISDS
//-----------------------------------------------------

//-----------------------------------------------------
// typ portalu
// 0 = czebox (zkusebni prostredi)
// 1 = mojedatovaschranka (ostre prostredi)

$portaltype=0;

//-----------------------------------------------------
// debugovaci vypis
// 0 = ne
// 1 = ano

$debug=0;    

//-----------------------------------------------------
// proxy adresa ve tvaru xxx.xxx.xxx.xxx
//

//$proxyaddress='192.168.1.33';

//-----------------------------------------------------
// proxy port
//

//$proxyport=80;

//-----------------------------------------------------
// proxy login name
//

//$proxylogin='supervisor';

//-----------------------------------------------------
// proxy heslo
//

//$proxypwd='';


?>