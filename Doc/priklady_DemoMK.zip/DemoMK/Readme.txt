-------------------------------------------------------------------------
UKAZKOVY PRIKLAD PRO ALTERNATIVNI PRISTUP K ISDS - POMOCI MOBILNIHO KLICE (MK)
Verze: 1.3
Datum: 8.8.2019 
-------------------------------------------------------------------------

----------------------------------------------------------------------------------------------
Soucasti projektu
----------------------------------------------------------------------------------------------
                                           
[src] - adresar se zdrojovymi kody prikladu
Readme.txt - tento soubor

----------------------------------------------------------------------------------------------
Instalace
----------------------------------------------------------------------------------------------

- vytvorte projekt ze zdroju v [src]

----------------------------------------------------------------------------------------------
Preklad a spusteni
----------------------------------------------------------------------------------------------

Pro spusteni demonstracniho programu budete potrebovat v danem prostredi ISDS prihlasovaci udaje k datove schrance.
Ve schrance povolenou prihlasovaci metodu pomoci Mobilniho klice a vygenerovany komunikacni kod.

Komunikacni kod - lze nalezt/vygenerovat na portale na strance Nastaveni > 
Moznosti prihlasovani > Prihlaseni mobilnim klicem, sekce Prihlasovani ostatnich aplikaci (uplne dole) 

Dotazy a pripominky k projektu muzete zadavat do vyvojarske diskuze na htts://team.smartadministration.cz

Souvisejici dokumentace:
MobilniKlic_autentizace.pdf (soucast Provozniho radu ISDS)

