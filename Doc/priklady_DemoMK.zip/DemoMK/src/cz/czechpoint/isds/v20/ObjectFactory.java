
package cz.czechpoint.isds.v20;

import java.math.BigInteger;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the cz.czechpoint.isds.v20 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _CheckDataBoxResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "CheckDataBoxResponse");
    private final static QName _PDZInfo_QNAME = new QName("http://isds.czechpoint.cz/v20", "PDZInfo");
    private final static QName _ChangeBoxesType_QNAME = new QName("http://isds.czechpoint.cz/v20", "ChangeBoxesType");
    private final static QName _DisableOwnDataBox2_QNAME = new QName("http://isds.czechpoint.cz/v20", "DisableOwnDataBox2");
    private final static QName _GetUserInfoFromLogin2Response_QNAME = new QName("http://isds.czechpoint.cz/v20", "GetUserInfoFromLogin2Response");
    private final static QName _EnableOwnDataBoxResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "EnableOwnDataBoxResponse");
    private final static QName _SetOpenAddressingResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "SetOpenAddressingResponse");
    private final static QName _GetUserInfoFromLogin2_QNAME = new QName("http://isds.czechpoint.cz/v20", "GetUserInfoFromLogin2");
    private final static QName _GetOwnerInfoFromLogin2Response_QNAME = new QName("http://isds.czechpoint.cz/v20", "GetOwnerInfoFromLogin2Response");
    private final static QName _UpdateDataBoxUser2_QNAME = new QName("http://isds.czechpoint.cz/v20", "UpdateDataBoxUser2");
    private final static QName _GetDataBoxActivityStatusResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "GetDataBoxActivityStatusResponse");
    private final static QName _FindPersonalDataBox_QNAME = new QName("http://isds.czechpoint.cz/v20", "FindPersonalDataBox");
    private final static QName _DeleteDataBoxResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "DeleteDataBoxResponse");
    private final static QName _DeleteDataBoxUserResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "DeleteDataBoxUserResponse");
    private final static QName _EnableOwnDataBox_QNAME = new QName("http://isds.czechpoint.cz/v20", "EnableOwnDataBox");
    private final static QName _DisableOwnDataBoxResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "DisableOwnDataBoxResponse");
    private final static QName _EnableOwnDataBox2Response_QNAME = new QName("http://isds.czechpoint.cz/v20", "EnableOwnDataBox2Response");
    private final static QName _GetPasswordInfoResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "GetPasswordInfoResponse");
    private final static QName _ChangeBoxesTypeResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "ChangeBoxesTypeResponse");
    private final static QName _AddDataBoxUser2_QNAME = new QName("http://isds.czechpoint.cz/v20", "AddDataBoxUser2");
    private final static QName _AddDataBoxUser_QNAME = new QName("http://isds.czechpoint.cz/v20", "AddDataBoxUser");
    private final static QName _GetDataBoxListResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "GetDataBoxListResponse");
    private final static QName _DeleteDataBoxPromptlyResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "DeleteDataBoxPromptlyResponse");
    private final static QName _CreateDataBox_QNAME = new QName("http://isds.czechpoint.cz/v20", "CreateDataBox");
    private final static QName _FindPersonalDataBoxResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "FindPersonalDataBoxResponse");
    private final static QName _UpdateDataBoxDescr2_QNAME = new QName("http://isds.czechpoint.cz/v20", "UpdateDataBoxDescr2");
    private final static QName _CheckDataBox_QNAME = new QName("http://isds.czechpoint.cz/v20", "CheckDataBox");
    private final static QName _DeleteDataBoxUser2Response_QNAME = new QName("http://isds.czechpoint.cz/v20", "DeleteDataBoxUser2Response");
    private final static QName _GetUserInfoFromLoginResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "GetUserInfoFromLoginResponse");
    private final static QName _DeleteDataBox2Response_QNAME = new QName("http://isds.czechpoint.cz/v20", "DeleteDataBox2Response");
    private final static QName _FindDataBox2_QNAME = new QName("http://isds.czechpoint.cz/v20", "FindDataBox2");
    private final static QName _UpdateDataBoxDescr2Response_QNAME = new QName("http://isds.czechpoint.cz/v20", "UpdateDataBoxDescr2Response");
    private final static QName _ISDSSearch2Response_QNAME = new QName("http://isds.czechpoint.cz/v20", "ISDSSearch2Response");
    private final static QName _CreateDataBox2_QNAME = new QName("http://isds.czechpoint.cz/v20", "CreateDataBox2");
    private final static QName _DTInfo_QNAME = new QName("http://isds.czechpoint.cz/v20", "DTInfo");
    private final static QName _NewAccessData2_QNAME = new QName("http://isds.czechpoint.cz/v20", "NewAccessData2");
    private final static QName _ChangeISDSPasswordResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "ChangeISDSPasswordResponse");
    private final static QName _DeleteDataBox_QNAME = new QName("http://isds.czechpoint.cz/v20", "DeleteDataBox");
    private final static QName _DisableOwnDataBox_QNAME = new QName("http://isds.czechpoint.cz/v20", "DisableOwnDataBox");
    private final static QName _GetOwnerInfoFromLogin2_QNAME = new QName("http://isds.czechpoint.cz/v20", "GetOwnerInfoFromLogin2");
    private final static QName _GetOwnerInfoFromLogin_QNAME = new QName("http://isds.czechpoint.cz/v20", "GetOwnerInfoFromLogin");
    private final static QName _DisableOwnDataBox2Response_QNAME = new QName("http://isds.czechpoint.cz/v20", "DisableOwnDataBox2Response");
    private final static QName _EnableOwnDataBox2_QNAME = new QName("http://isds.czechpoint.cz/v20", "EnableOwnDataBox2");
    private final static QName _ClearOpenAddressing_QNAME = new QName("http://isds.czechpoint.cz/v20", "ClearOpenAddressing");
    private final static QName _GetUserInfoFromLogin_QNAME = new QName("http://isds.czechpoint.cz/v20", "GetUserInfoFromLogin");
    private final static QName _PDZSendInfo_QNAME = new QName("http://isds.czechpoint.cz/v20", "PDZSendInfo");
    private final static QName _GetDataBoxUsers2_QNAME = new QName("http://isds.czechpoint.cz/v20", "GetDataBoxUsers2");
    private final static QName _FindDataBox2Response_QNAME = new QName("http://isds.czechpoint.cz/v20", "FindDataBox2Response");
    private final static QName _GetOwnerInfoFromLoginResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "GetOwnerInfoFromLoginResponse");
    private final static QName _PDZInfoResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "PDZInfoResponse");
    private final static QName _FindDataBox_QNAME = new QName("http://isds.czechpoint.cz/v20", "FindDataBox");
    private final static QName _DTInfoResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "DTInfoResponse");
    private final static QName _CreateDataBoxResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "CreateDataBoxResponse");
    private final static QName _UpdateDataBoxUser2Response_QNAME = new QName("http://isds.czechpoint.cz/v20", "UpdateDataBoxUser2Response");
    private final static QName _DisableDataBoxExternally2Response_QNAME = new QName("http://isds.czechpoint.cz/v20", "DisableDataBoxExternally2Response");
    private final static QName _GetDataBoxList_QNAME = new QName("http://isds.czechpoint.cz/v20", "GetDataBoxList");
    private final static QName _NewAccessData2Response_QNAME = new QName("http://isds.czechpoint.cz/v20", "NewAccessData2Response");
    private final static QName _UpdateDataBoxUserResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "UpdateDataBoxUserResponse");
    private final static QName _GetPasswordInfo_QNAME = new QName("http://isds.czechpoint.cz/v20", "GetPasswordInfo");
    private final static QName _AddDataBoxUser2Response_QNAME = new QName("http://isds.czechpoint.cz/v20", "AddDataBoxUser2Response");
    private final static QName _DeleteDataBox2_QNAME = new QName("http://isds.czechpoint.cz/v20", "DeleteDataBox2");
    private final static QName _UpdateDataBoxDescr_QNAME = new QName("http://isds.czechpoint.cz/v20", "UpdateDataBoxDescr");
    private final static QName _NewAccessData_QNAME = new QName("http://isds.czechpoint.cz/v20", "NewAccessData");
    private final static QName _UpdateDataBoxDescrResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "UpdateDataBoxDescrResponse");
    private final static QName _PDZSendInfoResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "PDZSendInfoResponse");
    private final static QName _DisableDataBoxExternally2_QNAME = new QName("http://isds.czechpoint.cz/v20", "DisableDataBoxExternally2");
    private final static QName _DeleteDataBoxUser_QNAME = new QName("http://isds.czechpoint.cz/v20", "DeleteDataBoxUser");
    private final static QName _GetDataBoxActivityStatus_QNAME = new QName("http://isds.czechpoint.cz/v20", "GetDataBoxActivityStatus");
    private final static QName _DataBoxCreditInfo_QNAME = new QName("http://isds.czechpoint.cz/v20", "DataBoxCreditInfo");
    private final static QName _DisableDataBoxExternallyResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "DisableDataBoxExternallyResponse");
    private final static QName _ChangeISDSPassword_QNAME = new QName("http://isds.czechpoint.cz/v20", "ChangeISDSPassword");
    private final static QName _DataBoxCreditInfoResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "DataBoxCreditInfoResponse");
    private final static QName _NewAccessDataResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "NewAccessDataResponse");
    private final static QName _DeleteDataBoxUser2_QNAME = new QName("http://isds.czechpoint.cz/v20", "DeleteDataBoxUser2");
    private final static QName _GetDataBoxUsers2Response_QNAME = new QName("http://isds.czechpoint.cz/v20", "GetDataBoxUsers2Response");
    private final static QName _DeleteDataBoxPromptly_QNAME = new QName("http://isds.czechpoint.cz/v20", "DeleteDataBoxPromptly");
    private final static QName _ISDSSearch3_QNAME = new QName("http://isds.czechpoint.cz/v20", "ISDSSearch3");
    private final static QName _FindDataBoxResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "FindDataBoxResponse");
    private final static QName _SetOpenAddressing_QNAME = new QName("http://isds.czechpoint.cz/v20", "SetOpenAddressing");
    private final static QName _ISDSSearch2_QNAME = new QName("http://isds.czechpoint.cz/v20", "ISDSSearch2");
    private final static QName _CreateDataBox2Response_QNAME = new QName("http://isds.czechpoint.cz/v20", "CreateDataBox2Response");
    private final static QName _ClearOpenAddressingResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "ClearOpenAddressingResponse");
    private final static QName _UpdateDataBoxUser_QNAME = new QName("http://isds.czechpoint.cz/v20", "UpdateDataBoxUser");
    private final static QName _DisableDataBoxExternally_QNAME = new QName("http://isds.czechpoint.cz/v20", "DisableDataBoxExternally");
    private final static QName _DbStatus_QNAME = new QName("http://isds.czechpoint.cz/v20", "dbStatus");
    private final static QName _AddDataBoxUserResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "AddDataBoxUserResponse");
    private final static QName _ISDSSearch3Response_QNAME = new QName("http://isds.czechpoint.cz/v20", "ISDSSearch3Response");
    private final static QName _TPDZSendOutputPDZsiResult_QNAME = new QName("http://isds.czechpoint.cz/v20", "PDZsiResult");
    private final static QName _TIdDBDUInputAttrs2DbApproved_QNAME = new QName("http://isds.czechpoint.cz/v20", "dbApproved");
    private final static QName _TIdDBDUInputAttrs2DbExternRefNumber_QNAME = new QName("http://isds.czechpoint.cz/v20", "dbExternRefNumber");
    private final static QName _TNewAccDataOutputDbAccessDataId_QNAME = new QName("http://isds.czechpoint.cz/v20", "dbAccessDataId");
    private final static QName _TAddDBUserOutput2DbID_QNAME = new QName("http://isds.czechpoint.cz/v20", "dbID");
    private final static QName _TGetDBListOutputDblData_QNAME = new QName("http://isds.czechpoint.cz/v20", "dblData");
    private final static QName _TCiRecordCiOldFrom_QNAME = new QName("http://isds.czechpoint.cz/v20", "ciOldFrom");
    private final static QName _TCiRecordCiDoneBy_QNAME = new QName("http://isds.czechpoint.cz/v20", "ciDoneBy");
    private final static QName _TCiRecordCiOldTo_QNAME = new QName("http://isds.czechpoint.cz/v20", "ciOldTo");
    private final static QName _TCiRecordCiOldCapacity_QNAME = new QName("http://isds.czechpoint.cz/v20", "ciOldCapacity");
    private final static QName _TDbUserInfoCaState_QNAME = new QName("http://isds.czechpoint.cz/v20", "caState");
    private final static QName _TDbOwnerInfoExtAdAMCode_QNAME = new QName("http://isds.czechpoint.cz/v20", "adAMCode");
    private final static QName _TDbOwnerInfoExtAdDistrict_QNAME = new QName("http://isds.czechpoint.cz/v20", "adDistrict");
    private final static QName _TDbOwnerInfoExtTelNumber_QNAME = new QName("http://isds.czechpoint.cz/v20", "telNumber");
    private final static QName _TDbOwnerInfoExtEmail_QNAME = new QName("http://isds.czechpoint.cz/v20", "email");
    private final static QName _TCreateDBOutputDbUserID_QNAME = new QName("http://isds.czechpoint.cz/v20", "dbUserID");
    private final static QName _TISDSSearchInputHighlighting_QNAME = new QName("http://isds.czechpoint.cz/v20", "highlighting");
    private final static QName _TCreateDBInput2NotifEmail_QNAME = new QName("http://isds.czechpoint.cz/v20", "notifEmail");
    private final static QName _TCreateDBInput2PnLastNameAtBirth_QNAME = new QName("http://isds.czechpoint.cz/v20", "pnLastNameAtBirth");
    private final static QName _TCreateDBInput2DbVirtual_QNAME = new QName("http://isds.czechpoint.cz/v20", "dbVirtual");
    private final static QName _TFindDBOuput2DbResults_QNAME = new QName("http://isds.czechpoint.cz/v20", "dbResults");
    private final static QName _TDbReqStatusDbStatusRefNumber_QNAME = new QName("http://isds.czechpoint.cz/v20", "dbStatusRefNumber");
    private final static QName _TDTInfoOutputFutDTCapacity_QNAME = new QName("http://isds.czechpoint.cz/v20", "FutDTCapacity");
    private final static QName _TDTInfoOutputActDTCapacity_QNAME = new QName("http://isds.czechpoint.cz/v20", "ActDTCapacity");
    private final static QName _TDTInfoOutputFutDTFrom_QNAME = new QName("http://isds.czechpoint.cz/v20", "FutDTFrom");
    private final static QName _TDTInfoOutputActDTCapUsed_QNAME = new QName("http://isds.czechpoint.cz/v20", "ActDTCapUsed");
    private final static QName _TDTInfoOutputFutDTPaid_QNAME = new QName("http://isds.czechpoint.cz/v20", "FutDTPaid");
    private final static QName _TDTInfoOutputActDTFrom_QNAME = new QName("http://isds.czechpoint.cz/v20", "ActDTFrom");
    private final static QName _TDTInfoOutputFutDTTo_QNAME = new QName("http://isds.czechpoint.cz/v20", "FutDTTo");
    private final static QName _TDTInfoOutputActDTTo_QNAME = new QName("http://isds.czechpoint.cz/v20", "ActDTTo");
    private final static QName _TDbOwnerInfoExt2AifoIsds_QNAME = new QName("http://isds.czechpoint.cz/v20", "aifoIsds");
    private final static QName _TCreateDBInputDbUpperDBId_QNAME = new QName("http://isds.czechpoint.cz/v20", "dbUpperDBId");
    private final static QName _TCreateDBInputDbCEOLabel_QNAME = new QName("http://isds.czechpoint.cz/v20", "dbCEOLabel");
    private final static QName _TCreateDBInputDbFormerNames_QNAME = new QName("http://isds.czechpoint.cz/v20", "dbFormerNames");
    private final static QName _TGetPasswInfoOutputPswExpDate_QNAME = new QName("http://isds.czechpoint.cz/v20", "pswExpDate");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: cz.czechpoint.isds.v20
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link TDbUsersArray }
     * 
     */
    public TDbUsersArray createTDbUsersArray() {
        return new TDbUsersArray();
    }

    /**
     * Create an instance of {@link TDbUsersArray2 }
     * 
     */
    public TDbUsersArray2 createTDbUsersArray2() {
        return new TDbUsersArray2();
    }

    /**
     * Create an instance of {@link TIdDBDUInputAttrs2 }
     * 
     */
    public TIdDBDUInputAttrs2 createTIdDBDUInputAttrs2() {
        return new TIdDBDUInputAttrs2();
    }

    /**
     * Create an instance of {@link TDelDBUserInput2 }
     * 
     */
    public TDelDBUserInput2 createTDelDBUserInput2() {
        return new TDelDBUserInput2();
    }

    /**
     * Create an instance of {@link TDBCreditInfoOutput }
     * 
     */
    public TDBCreditInfoOutput createTDBCreditInfoOutput() {
        return new TDBCreditInfoOutput();
    }

    /**
     * Create an instance of {@link TDisableExternallyInput2 }
     * 
     */
    public TDisableExternallyInput2 createTDisableExternallyInput2() {
        return new TDisableExternallyInput2();
    }

    /**
     * Create an instance of {@link TAddDBUserInput2 }
     * 
     */
    public TAddDBUserInput2 createTAddDBUserInput2() {
        return new TAddDBUserInput2();
    }

    /**
     * Create an instance of {@link TAddDBUserInput }
     * 
     */
    public TAddDBUserInput createTAddDBUserInput() {
        return new TAddDBUserInput();
    }

    /**
     * Create an instance of {@link TIdDBInputAttrs }
     * 
     */
    public TIdDBInputAttrs createTIdDBInputAttrs() {
        return new TIdDBInputAttrs();
    }

    /**
     * Create an instance of {@link TCreateDBInput2 }
     * 
     */
    public TCreateDBInput2 createTCreateDBInput2() {
        return new TCreateDBInput2();
    }

    /**
     * Create an instance of {@link TCreateDBInput }
     * 
     */
    public TCreateDBInput createTCreateDBInput() {
        return new TCreateDBInput();
    }

    /**
     * Create an instance of {@link TGetDBListOutput }
     * 
     */
    public TGetDBListOutput createTGetDBListOutput() {
        return new TGetDBListOutput();
    }

    /**
     * Create an instance of {@link TReqStatusOutput }
     * 
     */
    public TReqStatusOutput createTReqStatusOutput() {
        return new TReqStatusOutput();
    }

    /**
     * Create an instance of {@link TGetUserInfoOutput }
     * 
     */
    public TGetUserInfoOutput createTGetUserInfoOutput() {
        return new TGetUserInfoOutput();
    }

    /**
     * Create an instance of {@link TIdDBInput }
     * 
     */
    public TIdDBInput createTIdDBInput() {
        return new TIdDBInput();
    }

    /**
     * Create an instance of {@link TUpdateDBInput2 }
     * 
     */
    public TUpdateDBInput2 createTUpdateDBInput2() {
        return new TUpdateDBInput2();
    }

    /**
     * Create an instance of {@link TFindPersonalDBOutput }
     * 
     */
    public TFindPersonalDBOutput createTFindPersonalDBOutput() {
        return new TFindPersonalDBOutput();
    }

    /**
     * Create an instance of {@link TNewAccDataInput2 }
     * 
     */
    public TNewAccDataInput2 createTNewAccDataInput2() {
        return new TNewAccDataInput2();
    }

    /**
     * Create an instance of {@link TDTInfoInput }
     * 
     */
    public TDTInfoInput createTDTInfoInput() {
        return new TDTInfoInput();
    }

    /**
     * Create an instance of {@link TFindDBInput2 }
     * 
     */
    public TFindDBInput2 createTFindDBInput2() {
        return new TFindDBInput2();
    }

    /**
     * Create an instance of {@link TISDSSearchOutput }
     * 
     */
    public TISDSSearchOutput createTISDSSearchOutput() {
        return new TISDSSearchOutput();
    }

    /**
     * Create an instance of {@link TDeleteDBInput }
     * 
     */
    public TDeleteDBInput createTDeleteDBInput() {
        return new TDeleteDBInput();
    }

    /**
     * Create an instance of {@link TOwnerInfoInput }
     * 
     */
    public TOwnerInfoInput createTOwnerInfoInput() {
        return new TOwnerInfoInput();
    }

    /**
     * Create an instance of {@link TGetUserInfoOutput2 }
     * 
     */
    public TGetUserInfoOutput2 createTGetUserInfoOutput2() {
        return new TGetUserInfoOutput2();
    }

    /**
     * Create an instance of {@link TChangeDBsTypeInput }
     * 
     */
    public TChangeDBsTypeInput createTChangeDBsTypeInput() {
        return new TChangeDBsTypeInput();
    }

    /**
     * Create an instance of {@link TCheckDBOutput }
     * 
     */
    public TCheckDBOutput createTCheckDBOutput() {
        return new TCheckDBOutput();
    }

    /**
     * Create an instance of {@link TPDZInfoInput }
     * 
     */
    public TPDZInfoInput createTPDZInfoInput() {
        return new TPDZInfoInput();
    }

    /**
     * Create an instance of {@link TUpdDBUserInput2 }
     * 
     */
    public TUpdDBUserInput2 createTUpdDBUserInput2() {
        return new TUpdDBUserInput2();
    }

    /**
     * Create an instance of {@link TGetOwnInfoOutput2 }
     * 
     */
    public TGetOwnInfoOutput2 createTGetOwnInfoOutput2() {
        return new TGetOwnInfoOutput2();
    }

    /**
     * Create an instance of {@link TDummyInput }
     * 
     */
    public TDummyInput createTDummyInput() {
        return new TDummyInput();
    }

    /**
     * Create an instance of {@link TGetDBStatusOutput }
     * 
     */
    public TGetDBStatusOutput createTGetDBStatusOutput() {
        return new TGetDBStatusOutput();
    }

    /**
     * Create an instance of {@link TFindPersonalDBInput }
     * 
     */
    public TFindPersonalDBInput createTFindPersonalDBInput() {
        return new TFindPersonalDBInput();
    }

    /**
     * Create an instance of {@link TChangeDBsTypeOutput }
     * 
     */
    public TChangeDBsTypeOutput createTChangeDBsTypeOutput() {
        return new TChangeDBsTypeOutput();
    }

    /**
     * Create an instance of {@link TGetPasswInfoOutput }
     * 
     */
    public TGetPasswInfoOutput createTGetPasswInfoOutput() {
        return new TGetPasswInfoOutput();
    }

    /**
     * Create an instance of {@link TGetDBStatusInput }
     * 
     */
    public TGetDBStatusInput createTGetDBStatusInput() {
        return new TGetDBStatusInput();
    }

    /**
     * Create an instance of {@link TDelDBUserInput }
     * 
     */
    public TDelDBUserInput createTDelDBUserInput() {
        return new TDelDBUserInput();
    }

    /**
     * Create an instance of {@link TPDZSendOutput }
     * 
     */
    public TPDZSendOutput createTPDZSendOutput() {
        return new TPDZSendOutput();
    }

    /**
     * Create an instance of {@link TNewAccDataInput }
     * 
     */
    public TNewAccDataInput createTNewAccDataInput() {
        return new TNewAccDataInput();
    }

    /**
     * Create an instance of {@link TChngPasswInput }
     * 
     */
    public TChngPasswInput createTChngPasswInput() {
        return new TChngPasswInput();
    }

    /**
     * Create an instance of {@link TDBCreditInfoInput }
     * 
     */
    public TDBCreditInfoInput createTDBCreditInfoInput() {
        return new TDBCreditInfoInput();
    }

    /**
     * Create an instance of {@link TCreateDBOutput2 }
     * 
     */
    public TCreateDBOutput2 createTCreateDBOutput2() {
        return new TCreateDBOutput2();
    }

    /**
     * Create an instance of {@link TFindDBOuput }
     * 
     */
    public TFindDBOuput createTFindDBOuput() {
        return new TFindDBOuput();
    }

    /**
     * Create an instance of {@link TISDSSearchInput }
     * 
     */
    public TISDSSearchInput createTISDSSearchInput() {
        return new TISDSSearchInput();
    }

    /**
     * Create an instance of {@link TISDSSearchInput3 }
     * 
     */
    public TISDSSearchInput3 createTISDSSearchInput3() {
        return new TISDSSearchInput3();
    }

    /**
     * Create an instance of {@link TGetDBUsers2Output }
     * 
     */
    public TGetDBUsers2Output createTGetDBUsers2Output() {
        return new TGetDBUsers2Output();
    }

    /**
     * Create an instance of {@link TDeleteDBPromptlyInput }
     * 
     */
    public TDeleteDBPromptlyInput createTDeleteDBPromptlyInput() {
        return new TDeleteDBPromptlyInput();
    }

    /**
     * Create an instance of {@link TNewAccDataOutput }
     * 
     */
    public TNewAccDataOutput createTNewAccDataOutput() {
        return new TNewAccDataOutput();
    }

    /**
     * Create an instance of {@link TISDSSearchOutput2 }
     * 
     */
    public TISDSSearchOutput2 createTISDSSearchOutput2() {
        return new TISDSSearchOutput2();
    }

    /**
     * Create an instance of {@link TAddDBUserOutput }
     * 
     */
    public TAddDBUserOutput createTAddDBUserOutput() {
        return new TAddDBUserOutput();
    }

    /**
     * Create an instance of {@link TDbReqStatus }
     * 
     */
    public TDbReqStatus createTDbReqStatus() {
        return new TDbReqStatus();
    }

    /**
     * Create an instance of {@link TDisableExternallyInput }
     * 
     */
    public TDisableExternallyInput createTDisableExternallyInput() {
        return new TDisableExternallyInput();
    }

    /**
     * Create an instance of {@link TUpdDBUserInput }
     * 
     */
    public TUpdDBUserInput createTUpdDBUserInput() {
        return new TUpdDBUserInput();
    }

    /**
     * Create an instance of {@link TPDZSendInput }
     * 
     */
    public TPDZSendInput createTPDZSendInput() {
        return new TPDZSendInput();
    }

    /**
     * Create an instance of {@link TDTInfoOutput }
     * 
     */
    public TDTInfoOutput createTDTInfoOutput() {
        return new TDTInfoOutput();
    }

    /**
     * Create an instance of {@link TFindDBInput }
     * 
     */
    public TFindDBInput createTFindDBInput() {
        return new TFindDBInput();
    }

    /**
     * Create an instance of {@link TGetOwnInfoOutput }
     * 
     */
    public TGetOwnInfoOutput createTGetOwnInfoOutput() {
        return new TGetOwnInfoOutput();
    }

    /**
     * Create an instance of {@link TPDZInfoOutput }
     * 
     */
    public TPDZInfoOutput createTPDZInfoOutput() {
        return new TPDZInfoOutput();
    }

    /**
     * Create an instance of {@link TFindDBOuput2 }
     * 
     */
    public TFindDBOuput2 createTFindDBOuput2() {
        return new TFindDBOuput2();
    }

    /**
     * Create an instance of {@link TAddDBUserOutput2 }
     * 
     */
    public TAddDBUserOutput2 createTAddDBUserOutput2() {
        return new TAddDBUserOutput2();
    }

    /**
     * Create an instance of {@link TNewAccDataOutput2 }
     * 
     */
    public TNewAccDataOutput2 createTNewAccDataOutput2() {
        return new TNewAccDataOutput2();
    }

    /**
     * Create an instance of {@link TGetDBListInput }
     * 
     */
    public TGetDBListInput createTGetDBListInput() {
        return new TGetDBListInput();
    }

    /**
     * Create an instance of {@link TCreateDBOutput }
     * 
     */
    public TCreateDBOutput createTCreateDBOutput() {
        return new TCreateDBOutput();
    }

    /**
     * Create an instance of {@link TUpdateDBInput }
     * 
     */
    public TUpdateDBInput createTUpdateDBInput() {
        return new TUpdateDBInput();
    }

    /**
     * Create an instance of {@link TDeleteDBInput2 }
     * 
     */
    public TDeleteDBInput2 createTDeleteDBInput2() {
        return new TDeleteDBInput2();
    }

    /**
     * Create an instance of {@link TPDZRec }
     * 
     */
    public TPDZRec createTPDZRec() {
        return new TPDZRec();
    }

    /**
     * Create an instance of {@link TDbUserInfo }
     * 
     */
    public TDbUserInfo createTDbUserInfo() {
        return new TDbUserInfo();
    }

    /**
     * Create an instance of {@link TDbUserInfoExt2 }
     * 
     */
    public TDbUserInfoExt2 createTDbUserInfoExt2() {
        return new TDbUserInfoExt2();
    }

    /**
     * Create an instance of {@link TPDZRecArray }
     * 
     */
    public TPDZRecArray createTPDZRecArray() {
        return new TPDZRecArray();
    }

    /**
     * Create an instance of {@link TDbOwnerInfoExt2 }
     * 
     */
    public TDbOwnerInfoExt2 createTDbOwnerInfoExt2() {
        return new TDbOwnerInfoExt2();
    }

    /**
     * Create an instance of {@link TIdDBDUInput }
     * 
     */
    public TIdDBDUInput createTIdDBDUInput() {
        return new TIdDBDUInput();
    }

    /**
     * Create an instance of {@link TDbOwnersArray2 }
     * 
     */
    public TDbOwnersArray2 createTDbOwnersArray2() {
        return new TDbOwnersArray2();
    }

    /**
     * Create an instance of {@link TdbPeriod }
     * 
     */
    public TdbPeriod createTdbPeriod() {
        return new TdbPeriod();
    }

    /**
     * Create an instance of {@link TDbOwnerInfoExt }
     * 
     */
    public TDbOwnerInfoExt createTDbOwnerInfoExt() {
        return new TDbOwnerInfoExt();
    }

    /**
     * Create an instance of {@link TChangeLogRow }
     * 
     */
    public TChangeLogRow createTChangeLogRow() {
        return new TChangeLogRow();
    }

    /**
     * Create an instance of {@link TdbPersonalOwnerInfo }
     * 
     */
    public TdbPersonalOwnerInfo createTdbPersonalOwnerInfo() {
        return new TdbPersonalOwnerInfo();
    }

    /**
     * Create an instance of {@link TdbResult2 }
     * 
     */
    public TdbResult2 createTdbResult2() {
        return new TdbResult2();
    }

    /**
     * Create an instance of {@link TDbOwnerInfo }
     * 
     */
    public TDbOwnerInfo createTDbOwnerInfo() {
        return new TDbOwnerInfo();
    }

    /**
     * Create an instance of {@link TCiRecord }
     * 
     */
    public TCiRecord createTCiRecord() {
        return new TCiRecord();
    }

    /**
     * Create an instance of {@link TdbResult }
     * 
     */
    public TdbResult createTdbResult() {
        return new TdbResult();
    }

    /**
     * Create an instance of {@link TdbResultsArray }
     * 
     */
    public TdbResultsArray createTdbResultsArray() {
        return new TdbResultsArray();
    }

    /**
     * Create an instance of {@link TdbPeriodsArray }
     * 
     */
    public TdbPeriodsArray createTdbPeriodsArray() {
        return new TdbPeriodsArray();
    }

    /**
     * Create an instance of {@link TdbResultsArray2 }
     * 
     */
    public TdbResultsArray2 createTdbResultsArray2() {
        return new TdbResultsArray2();
    }

    /**
     * Create an instance of {@link TDbOwnersArray }
     * 
     */
    public TDbOwnersArray createTDbOwnersArray() {
        return new TDbOwnersArray();
    }

    /**
     * Create an instance of {@link TdbPersOwnersArray }
     * 
     */
    public TdbPersOwnersArray createTdbPersOwnersArray() {
        return new TdbPersOwnersArray();
    }

    /**
     * Create an instance of {@link TDbUserInfoExt }
     * 
     */
    public TDbUserInfoExt createTDbUserInfoExt() {
        return new TDbUserInfoExt();
    }

    /**
     * Create an instance of {@link TDbUsersArray.DbUserInfo }
     * 
     */
    public TDbUsersArray.DbUserInfo createTDbUsersArrayDbUserInfo() {
        return new TDbUsersArray.DbUserInfo();
    }

    /**
     * Create an instance of {@link TDbUsersArray2 .DbUserInfo }
     * 
     */
    public TDbUsersArray2 .DbUserInfo createTDbUsersArray2DbUserInfo() {
        return new TDbUsersArray2 .DbUserInfo();
    }

    /**
     * Create an instance of {@link TIdDBDUInputAttrs2 .DbID }
     * 
     */
    public TIdDBDUInputAttrs2 .DbID createTIdDBDUInputAttrs2DbID() {
        return new TIdDBDUInputAttrs2 .DbID();
    }

    /**
     * Create an instance of {@link TDelDBUserInput2 .DbID }
     * 
     */
    public TDelDBUserInput2 .DbID createTDelDBUserInput2DbID() {
        return new TDelDBUserInput2 .DbID();
    }

    /**
     * Create an instance of {@link TDBCreditInfoOutput.CiRecords }
     * 
     */
    public TDBCreditInfoOutput.CiRecords createTDBCreditInfoOutputCiRecords() {
        return new TDBCreditInfoOutput.CiRecords();
    }

    /**
     * Create an instance of {@link TDisableExternallyInput2 .DbID }
     * 
     */
    public TDisableExternallyInput2 .DbID createTDisableExternallyInput2DbID() {
        return new TDisableExternallyInput2 .DbID();
    }

    /**
     * Create an instance of {@link TAddDBUserInput2 .DbUserInfo }
     * 
     */
    public TAddDBUserInput2 .DbUserInfo createTAddDBUserInput2DbUserInfo() {
        return new TAddDBUserInput2 .DbUserInfo();
    }

    /**
     * Create an instance of {@link TAddDBUserInput.DbUserInfo }
     * 
     */
    public TAddDBUserInput.DbUserInfo createTAddDBUserInputDbUserInfo() {
        return new TAddDBUserInput.DbUserInfo();
    }

    /**
     * Create an instance of {@link TIdDBInputAttrs.DbID }
     * 
     */
    public TIdDBInputAttrs.DbID createTIdDBInputAttrsDbID() {
        return new TIdDBInputAttrs.DbID();
    }

    /**
     * Create an instance of {@link TCreateDBInput2 .DbOwnerInfo }
     * 
     */
    public TCreateDBInput2 .DbOwnerInfo createTCreateDBInput2DbOwnerInfo() {
        return new TCreateDBInput2 .DbOwnerInfo();
    }

    /**
     * Create an instance of {@link TCreateDBInput.DbOwnerInfo }
     * 
     */
    public TCreateDBInput.DbOwnerInfo createTCreateDBInputDbOwnerInfo() {
        return new TCreateDBInput.DbOwnerInfo();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TCheckDBOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "CheckDataBoxResponse")
    public JAXBElement<TCheckDBOutput> createCheckDataBoxResponse(TCheckDBOutput value) {
        return new JAXBElement<TCheckDBOutput>(_CheckDataBoxResponse_QNAME, TCheckDBOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TPDZInfoInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "PDZInfo")
    public JAXBElement<TPDZInfoInput> createPDZInfo(TPDZInfoInput value) {
        return new JAXBElement<TPDZInfoInput>(_PDZInfo_QNAME, TPDZInfoInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TChangeDBsTypeInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "ChangeBoxesType")
    public JAXBElement<TChangeDBsTypeInput> createChangeBoxesType(TChangeDBsTypeInput value) {
        return new JAXBElement<TChangeDBsTypeInput>(_ChangeBoxesType_QNAME, TChangeDBsTypeInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TIdDBInputAttrs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "DisableOwnDataBox2")
    public JAXBElement<TIdDBInputAttrs> createDisableOwnDataBox2(TIdDBInputAttrs value) {
        return new JAXBElement<TIdDBInputAttrs>(_DisableOwnDataBox2_QNAME, TIdDBInputAttrs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TGetUserInfoOutput2 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "GetUserInfoFromLogin2Response")
    public JAXBElement<TGetUserInfoOutput2> createGetUserInfoFromLogin2Response(TGetUserInfoOutput2 value) {
        return new JAXBElement<TGetUserInfoOutput2>(_GetUserInfoFromLogin2Response_QNAME, TGetUserInfoOutput2 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TReqStatusOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "EnableOwnDataBoxResponse")
    public JAXBElement<TReqStatusOutput> createEnableOwnDataBoxResponse(TReqStatusOutput value) {
        return new JAXBElement<TReqStatusOutput>(_EnableOwnDataBoxResponse_QNAME, TReqStatusOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TReqStatusOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "SetOpenAddressingResponse")
    public JAXBElement<TReqStatusOutput> createSetOpenAddressingResponse(TReqStatusOutput value) {
        return new JAXBElement<TReqStatusOutput>(_SetOpenAddressingResponse_QNAME, TReqStatusOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TDummyInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "GetUserInfoFromLogin2")
    public JAXBElement<TDummyInput> createGetUserInfoFromLogin2(TDummyInput value) {
        return new JAXBElement<TDummyInput>(_GetUserInfoFromLogin2_QNAME, TDummyInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TGetOwnInfoOutput2 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "GetOwnerInfoFromLogin2Response")
    public JAXBElement<TGetOwnInfoOutput2> createGetOwnerInfoFromLogin2Response(TGetOwnInfoOutput2 value) {
        return new JAXBElement<TGetOwnInfoOutput2>(_GetOwnerInfoFromLogin2Response_QNAME, TGetOwnInfoOutput2 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TUpdDBUserInput2 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "UpdateDataBoxUser2")
    public JAXBElement<TUpdDBUserInput2> createUpdateDataBoxUser2(TUpdDBUserInput2 value) {
        return new JAXBElement<TUpdDBUserInput2>(_UpdateDataBoxUser2_QNAME, TUpdDBUserInput2 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TGetDBStatusOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "GetDataBoxActivityStatusResponse")
    public JAXBElement<TGetDBStatusOutput> createGetDataBoxActivityStatusResponse(TGetDBStatusOutput value) {
        return new JAXBElement<TGetDBStatusOutput>(_GetDataBoxActivityStatusResponse_QNAME, TGetDBStatusOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TFindPersonalDBInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "FindPersonalDataBox")
    public JAXBElement<TFindPersonalDBInput> createFindPersonalDataBox(TFindPersonalDBInput value) {
        return new JAXBElement<TFindPersonalDBInput>(_FindPersonalDataBox_QNAME, TFindPersonalDBInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TReqStatusOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "DeleteDataBoxResponse")
    public JAXBElement<TReqStatusOutput> createDeleteDataBoxResponse(TReqStatusOutput value) {
        return new JAXBElement<TReqStatusOutput>(_DeleteDataBoxResponse_QNAME, TReqStatusOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TReqStatusOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "DeleteDataBoxUserResponse")
    public JAXBElement<TReqStatusOutput> createDeleteDataBoxUserResponse(TReqStatusOutput value) {
        return new JAXBElement<TReqStatusOutput>(_DeleteDataBoxUserResponse_QNAME, TReqStatusOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TOwnerInfoInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "EnableOwnDataBox")
    public JAXBElement<TOwnerInfoInput> createEnableOwnDataBox(TOwnerInfoInput value) {
        return new JAXBElement<TOwnerInfoInput>(_EnableOwnDataBox_QNAME, TOwnerInfoInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TReqStatusOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "DisableOwnDataBoxResponse")
    public JAXBElement<TReqStatusOutput> createDisableOwnDataBoxResponse(TReqStatusOutput value) {
        return new JAXBElement<TReqStatusOutput>(_DisableOwnDataBoxResponse_QNAME, TReqStatusOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TReqStatusOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "EnableOwnDataBox2Response")
    public JAXBElement<TReqStatusOutput> createEnableOwnDataBox2Response(TReqStatusOutput value) {
        return new JAXBElement<TReqStatusOutput>(_EnableOwnDataBox2Response_QNAME, TReqStatusOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TGetPasswInfoOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "GetPasswordInfoResponse")
    public JAXBElement<TGetPasswInfoOutput> createGetPasswordInfoResponse(TGetPasswInfoOutput value) {
        return new JAXBElement<TGetPasswInfoOutput>(_GetPasswordInfoResponse_QNAME, TGetPasswInfoOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TChangeDBsTypeOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "ChangeBoxesTypeResponse")
    public JAXBElement<TChangeDBsTypeOutput> createChangeBoxesTypeResponse(TChangeDBsTypeOutput value) {
        return new JAXBElement<TChangeDBsTypeOutput>(_ChangeBoxesTypeResponse_QNAME, TChangeDBsTypeOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TAddDBUserInput2 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "AddDataBoxUser2")
    public JAXBElement<TAddDBUserInput2> createAddDataBoxUser2(TAddDBUserInput2 value) {
        return new JAXBElement<TAddDBUserInput2>(_AddDataBoxUser2_QNAME, TAddDBUserInput2 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TAddDBUserInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "AddDataBoxUser")
    public JAXBElement<TAddDBUserInput> createAddDataBoxUser(TAddDBUserInput value) {
        return new JAXBElement<TAddDBUserInput>(_AddDataBoxUser_QNAME, TAddDBUserInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TGetDBListOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "GetDataBoxListResponse")
    public JAXBElement<TGetDBListOutput> createGetDataBoxListResponse(TGetDBListOutput value) {
        return new JAXBElement<TGetDBListOutput>(_GetDataBoxListResponse_QNAME, TGetDBListOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TReqStatusOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "DeleteDataBoxPromptlyResponse")
    public JAXBElement<TReqStatusOutput> createDeleteDataBoxPromptlyResponse(TReqStatusOutput value) {
        return new JAXBElement<TReqStatusOutput>(_DeleteDataBoxPromptlyResponse_QNAME, TReqStatusOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TCreateDBInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "CreateDataBox")
    public JAXBElement<TCreateDBInput> createCreateDataBox(TCreateDBInput value) {
        return new JAXBElement<TCreateDBInput>(_CreateDataBox_QNAME, TCreateDBInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TFindPersonalDBOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "FindPersonalDataBoxResponse")
    public JAXBElement<TFindPersonalDBOutput> createFindPersonalDataBoxResponse(TFindPersonalDBOutput value) {
        return new JAXBElement<TFindPersonalDBOutput>(_FindPersonalDataBoxResponse_QNAME, TFindPersonalDBOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TUpdateDBInput2 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "UpdateDataBoxDescr2")
    public JAXBElement<TUpdateDBInput2> createUpdateDataBoxDescr2(TUpdateDBInput2 value) {
        return new JAXBElement<TUpdateDBInput2>(_UpdateDataBoxDescr2_QNAME, TUpdateDBInput2 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TIdDBInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "CheckDataBox")
    public JAXBElement<TIdDBInput> createCheckDataBox(TIdDBInput value) {
        return new JAXBElement<TIdDBInput>(_CheckDataBox_QNAME, TIdDBInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TReqStatusOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "DeleteDataBoxUser2Response")
    public JAXBElement<TReqStatusOutput> createDeleteDataBoxUser2Response(TReqStatusOutput value) {
        return new JAXBElement<TReqStatusOutput>(_DeleteDataBoxUser2Response_QNAME, TReqStatusOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TGetUserInfoOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "GetUserInfoFromLoginResponse")
    public JAXBElement<TGetUserInfoOutput> createGetUserInfoFromLoginResponse(TGetUserInfoOutput value) {
        return new JAXBElement<TGetUserInfoOutput>(_GetUserInfoFromLoginResponse_QNAME, TGetUserInfoOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TReqStatusOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "DeleteDataBox2Response")
    public JAXBElement<TReqStatusOutput> createDeleteDataBox2Response(TReqStatusOutput value) {
        return new JAXBElement<TReqStatusOutput>(_DeleteDataBox2Response_QNAME, TReqStatusOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TFindDBInput2 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "FindDataBox2")
    public JAXBElement<TFindDBInput2> createFindDataBox2(TFindDBInput2 value) {
        return new JAXBElement<TFindDBInput2>(_FindDataBox2_QNAME, TFindDBInput2 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TReqStatusOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "UpdateDataBoxDescr2Response")
    public JAXBElement<TReqStatusOutput> createUpdateDataBoxDescr2Response(TReqStatusOutput value) {
        return new JAXBElement<TReqStatusOutput>(_UpdateDataBoxDescr2Response_QNAME, TReqStatusOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TISDSSearchOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "ISDSSearch2Response")
    public JAXBElement<TISDSSearchOutput> createISDSSearch2Response(TISDSSearchOutput value) {
        return new JAXBElement<TISDSSearchOutput>(_ISDSSearch2Response_QNAME, TISDSSearchOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TCreateDBInput2 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "CreateDataBox2")
    public JAXBElement<TCreateDBInput2> createCreateDataBox2(TCreateDBInput2 value) {
        return new JAXBElement<TCreateDBInput2>(_CreateDataBox2_QNAME, TCreateDBInput2 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TDTInfoInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "DTInfo")
    public JAXBElement<TDTInfoInput> createDTInfo(TDTInfoInput value) {
        return new JAXBElement<TDTInfoInput>(_DTInfo_QNAME, TDTInfoInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TNewAccDataInput2 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "NewAccessData2")
    public JAXBElement<TNewAccDataInput2> createNewAccessData2(TNewAccDataInput2 value) {
        return new JAXBElement<TNewAccDataInput2>(_NewAccessData2_QNAME, TNewAccDataInput2 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TReqStatusOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "ChangeISDSPasswordResponse")
    public JAXBElement<TReqStatusOutput> createChangeISDSPasswordResponse(TReqStatusOutput value) {
        return new JAXBElement<TReqStatusOutput>(_ChangeISDSPasswordResponse_QNAME, TReqStatusOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TDeleteDBInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "DeleteDataBox")
    public JAXBElement<TDeleteDBInput> createDeleteDataBox(TDeleteDBInput value) {
        return new JAXBElement<TDeleteDBInput>(_DeleteDataBox_QNAME, TDeleteDBInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TOwnerInfoInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "DisableOwnDataBox")
    public JAXBElement<TOwnerInfoInput> createDisableOwnDataBox(TOwnerInfoInput value) {
        return new JAXBElement<TOwnerInfoInput>(_DisableOwnDataBox_QNAME, TOwnerInfoInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TDummyInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "GetOwnerInfoFromLogin2")
    public JAXBElement<TDummyInput> createGetOwnerInfoFromLogin2(TDummyInput value) {
        return new JAXBElement<TDummyInput>(_GetOwnerInfoFromLogin2_QNAME, TDummyInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TDummyInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "GetOwnerInfoFromLogin")
    public JAXBElement<TDummyInput> createGetOwnerInfoFromLogin(TDummyInput value) {
        return new JAXBElement<TDummyInput>(_GetOwnerInfoFromLogin_QNAME, TDummyInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TReqStatusOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "DisableOwnDataBox2Response")
    public JAXBElement<TReqStatusOutput> createDisableOwnDataBox2Response(TReqStatusOutput value) {
        return new JAXBElement<TReqStatusOutput>(_DisableOwnDataBox2Response_QNAME, TReqStatusOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TIdDBInputAttrs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "EnableOwnDataBox2")
    public JAXBElement<TIdDBInputAttrs> createEnableOwnDataBox2(TIdDBInputAttrs value) {
        return new JAXBElement<TIdDBInputAttrs>(_EnableOwnDataBox2_QNAME, TIdDBInputAttrs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TIdDBInputAttrs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "ClearOpenAddressing")
    public JAXBElement<TIdDBInputAttrs> createClearOpenAddressing(TIdDBInputAttrs value) {
        return new JAXBElement<TIdDBInputAttrs>(_ClearOpenAddressing_QNAME, TIdDBInputAttrs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TDummyInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "GetUserInfoFromLogin")
    public JAXBElement<TDummyInput> createGetUserInfoFromLogin(TDummyInput value) {
        return new JAXBElement<TDummyInput>(_GetUserInfoFromLogin_QNAME, TDummyInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TPDZSendInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "PDZSendInfo")
    public JAXBElement<TPDZSendInput> createPDZSendInfo(TPDZSendInput value) {
        return new JAXBElement<TPDZSendInput>(_PDZSendInfo_QNAME, TPDZSendInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TIdDBInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "GetDataBoxUsers2")
    public JAXBElement<TIdDBInput> createGetDataBoxUsers2(TIdDBInput value) {
        return new JAXBElement<TIdDBInput>(_GetDataBoxUsers2_QNAME, TIdDBInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TFindDBOuput2 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "FindDataBox2Response")
    public JAXBElement<TFindDBOuput2> createFindDataBox2Response(TFindDBOuput2 value) {
        return new JAXBElement<TFindDBOuput2>(_FindDataBox2Response_QNAME, TFindDBOuput2 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TGetOwnInfoOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "GetOwnerInfoFromLoginResponse")
    public JAXBElement<TGetOwnInfoOutput> createGetOwnerInfoFromLoginResponse(TGetOwnInfoOutput value) {
        return new JAXBElement<TGetOwnInfoOutput>(_GetOwnerInfoFromLoginResponse_QNAME, TGetOwnInfoOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TPDZInfoOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "PDZInfoResponse")
    public JAXBElement<TPDZInfoOutput> createPDZInfoResponse(TPDZInfoOutput value) {
        return new JAXBElement<TPDZInfoOutput>(_PDZInfoResponse_QNAME, TPDZInfoOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TFindDBInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "FindDataBox")
    public JAXBElement<TFindDBInput> createFindDataBox(TFindDBInput value) {
        return new JAXBElement<TFindDBInput>(_FindDataBox_QNAME, TFindDBInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TDTInfoOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "DTInfoResponse")
    public JAXBElement<TDTInfoOutput> createDTInfoResponse(TDTInfoOutput value) {
        return new JAXBElement<TDTInfoOutput>(_DTInfoResponse_QNAME, TDTInfoOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TCreateDBOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "CreateDataBoxResponse")
    public JAXBElement<TCreateDBOutput> createCreateDataBoxResponse(TCreateDBOutput value) {
        return new JAXBElement<TCreateDBOutput>(_CreateDataBoxResponse_QNAME, TCreateDBOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TReqStatusOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "UpdateDataBoxUser2Response")
    public JAXBElement<TReqStatusOutput> createUpdateDataBoxUser2Response(TReqStatusOutput value) {
        return new JAXBElement<TReqStatusOutput>(_UpdateDataBoxUser2Response_QNAME, TReqStatusOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TReqStatusOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "DisableDataBoxExternally2Response")
    public JAXBElement<TReqStatusOutput> createDisableDataBoxExternally2Response(TReqStatusOutput value) {
        return new JAXBElement<TReqStatusOutput>(_DisableDataBoxExternally2Response_QNAME, TReqStatusOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TGetDBListInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "GetDataBoxList")
    public JAXBElement<TGetDBListInput> createGetDataBoxList(TGetDBListInput value) {
        return new JAXBElement<TGetDBListInput>(_GetDataBoxList_QNAME, TGetDBListInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TNewAccDataOutput2 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "NewAccessData2Response")
    public JAXBElement<TNewAccDataOutput2> createNewAccessData2Response(TNewAccDataOutput2 value) {
        return new JAXBElement<TNewAccDataOutput2>(_NewAccessData2Response_QNAME, TNewAccDataOutput2 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TReqStatusOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "UpdateDataBoxUserResponse")
    public JAXBElement<TReqStatusOutput> createUpdateDataBoxUserResponse(TReqStatusOutput value) {
        return new JAXBElement<TReqStatusOutput>(_UpdateDataBoxUserResponse_QNAME, TReqStatusOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TDummyInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "GetPasswordInfo")
    public JAXBElement<TDummyInput> createGetPasswordInfo(TDummyInput value) {
        return new JAXBElement<TDummyInput>(_GetPasswordInfo_QNAME, TDummyInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TAddDBUserOutput2 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "AddDataBoxUser2Response")
    public JAXBElement<TAddDBUserOutput2> createAddDataBoxUser2Response(TAddDBUserOutput2 value) {
        return new JAXBElement<TAddDBUserOutput2>(_AddDataBoxUser2Response_QNAME, TAddDBUserOutput2 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TDeleteDBInput2 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "DeleteDataBox2")
    public JAXBElement<TDeleteDBInput2> createDeleteDataBox2(TDeleteDBInput2 value) {
        return new JAXBElement<TDeleteDBInput2>(_DeleteDataBox2_QNAME, TDeleteDBInput2 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TUpdateDBInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "UpdateDataBoxDescr")
    public JAXBElement<TUpdateDBInput> createUpdateDataBoxDescr(TUpdateDBInput value) {
        return new JAXBElement<TUpdateDBInput>(_UpdateDataBoxDescr_QNAME, TUpdateDBInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TNewAccDataInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "NewAccessData")
    public JAXBElement<TNewAccDataInput> createNewAccessData(TNewAccDataInput value) {
        return new JAXBElement<TNewAccDataInput>(_NewAccessData_QNAME, TNewAccDataInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TReqStatusOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "UpdateDataBoxDescrResponse")
    public JAXBElement<TReqStatusOutput> createUpdateDataBoxDescrResponse(TReqStatusOutput value) {
        return new JAXBElement<TReqStatusOutput>(_UpdateDataBoxDescrResponse_QNAME, TReqStatusOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TPDZSendOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "PDZSendInfoResponse")
    public JAXBElement<TPDZSendOutput> createPDZSendInfoResponse(TPDZSendOutput value) {
        return new JAXBElement<TPDZSendOutput>(_PDZSendInfoResponse_QNAME, TPDZSendOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TDisableExternallyInput2 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "DisableDataBoxExternally2")
    public JAXBElement<TDisableExternallyInput2> createDisableDataBoxExternally2(TDisableExternallyInput2 value) {
        return new JAXBElement<TDisableExternallyInput2>(_DisableDataBoxExternally2_QNAME, TDisableExternallyInput2 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TDelDBUserInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "DeleteDataBoxUser")
    public JAXBElement<TDelDBUserInput> createDeleteDataBoxUser(TDelDBUserInput value) {
        return new JAXBElement<TDelDBUserInput>(_DeleteDataBoxUser_QNAME, TDelDBUserInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TGetDBStatusInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "GetDataBoxActivityStatus")
    public JAXBElement<TGetDBStatusInput> createGetDataBoxActivityStatus(TGetDBStatusInput value) {
        return new JAXBElement<TGetDBStatusInput>(_GetDataBoxActivityStatus_QNAME, TGetDBStatusInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TDBCreditInfoInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "DataBoxCreditInfo")
    public JAXBElement<TDBCreditInfoInput> createDataBoxCreditInfo(TDBCreditInfoInput value) {
        return new JAXBElement<TDBCreditInfoInput>(_DataBoxCreditInfo_QNAME, TDBCreditInfoInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TReqStatusOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "DisableDataBoxExternallyResponse")
    public JAXBElement<TReqStatusOutput> createDisableDataBoxExternallyResponse(TReqStatusOutput value) {
        return new JAXBElement<TReqStatusOutput>(_DisableDataBoxExternallyResponse_QNAME, TReqStatusOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TChngPasswInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "ChangeISDSPassword")
    public JAXBElement<TChngPasswInput> createChangeISDSPassword(TChngPasswInput value) {
        return new JAXBElement<TChngPasswInput>(_ChangeISDSPassword_QNAME, TChngPasswInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TDBCreditInfoOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "DataBoxCreditInfoResponse")
    public JAXBElement<TDBCreditInfoOutput> createDataBoxCreditInfoResponse(TDBCreditInfoOutput value) {
        return new JAXBElement<TDBCreditInfoOutput>(_DataBoxCreditInfoResponse_QNAME, TDBCreditInfoOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TNewAccDataOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "NewAccessDataResponse")
    public JAXBElement<TNewAccDataOutput> createNewAccessDataResponse(TNewAccDataOutput value) {
        return new JAXBElement<TNewAccDataOutput>(_NewAccessDataResponse_QNAME, TNewAccDataOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TDelDBUserInput2 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "DeleteDataBoxUser2")
    public JAXBElement<TDelDBUserInput2> createDeleteDataBoxUser2(TDelDBUserInput2 value) {
        return new JAXBElement<TDelDBUserInput2>(_DeleteDataBoxUser2_QNAME, TDelDBUserInput2 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TGetDBUsers2Output }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "GetDataBoxUsers2Response")
    public JAXBElement<TGetDBUsers2Output> createGetDataBoxUsers2Response(TGetDBUsers2Output value) {
        return new JAXBElement<TGetDBUsers2Output>(_GetDataBoxUsers2Response_QNAME, TGetDBUsers2Output.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TDeleteDBPromptlyInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "DeleteDataBoxPromptly")
    public JAXBElement<TDeleteDBPromptlyInput> createDeleteDataBoxPromptly(TDeleteDBPromptlyInput value) {
        return new JAXBElement<TDeleteDBPromptlyInput>(_DeleteDataBoxPromptly_QNAME, TDeleteDBPromptlyInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TISDSSearchInput3 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "ISDSSearch3")
    public JAXBElement<TISDSSearchInput3> createISDSSearch3(TISDSSearchInput3 value) {
        return new JAXBElement<TISDSSearchInput3>(_ISDSSearch3_QNAME, TISDSSearchInput3 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TFindDBOuput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "FindDataBoxResponse")
    public JAXBElement<TFindDBOuput> createFindDataBoxResponse(TFindDBOuput value) {
        return new JAXBElement<TFindDBOuput>(_FindDataBoxResponse_QNAME, TFindDBOuput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TIdDBInputAttrs }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "SetOpenAddressing")
    public JAXBElement<TIdDBInputAttrs> createSetOpenAddressing(TIdDBInputAttrs value) {
        return new JAXBElement<TIdDBInputAttrs>(_SetOpenAddressing_QNAME, TIdDBInputAttrs.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TISDSSearchInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "ISDSSearch2")
    public JAXBElement<TISDSSearchInput> createISDSSearch2(TISDSSearchInput value) {
        return new JAXBElement<TISDSSearchInput>(_ISDSSearch2_QNAME, TISDSSearchInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TCreateDBOutput2 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "CreateDataBox2Response")
    public JAXBElement<TCreateDBOutput2> createCreateDataBox2Response(TCreateDBOutput2 value) {
        return new JAXBElement<TCreateDBOutput2>(_CreateDataBox2Response_QNAME, TCreateDBOutput2 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TReqStatusOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "ClearOpenAddressingResponse")
    public JAXBElement<TReqStatusOutput> createClearOpenAddressingResponse(TReqStatusOutput value) {
        return new JAXBElement<TReqStatusOutput>(_ClearOpenAddressingResponse_QNAME, TReqStatusOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TUpdDBUserInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "UpdateDataBoxUser")
    public JAXBElement<TUpdDBUserInput> createUpdateDataBoxUser(TUpdDBUserInput value) {
        return new JAXBElement<TUpdDBUserInput>(_UpdateDataBoxUser_QNAME, TUpdDBUserInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TDisableExternallyInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "DisableDataBoxExternally")
    public JAXBElement<TDisableExternallyInput> createDisableDataBoxExternally(TDisableExternallyInput value) {
        return new JAXBElement<TDisableExternallyInput>(_DisableDataBoxExternally_QNAME, TDisableExternallyInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TDbReqStatus }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbStatus")
    public JAXBElement<TDbReqStatus> createDbStatus(TDbReqStatus value) {
        return new JAXBElement<TDbReqStatus>(_DbStatus_QNAME, TDbReqStatus.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TAddDBUserOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "AddDataBoxUserResponse")
    public JAXBElement<TAddDBUserOutput> createAddDataBoxUserResponse(TAddDBUserOutput value) {
        return new JAXBElement<TAddDBUserOutput>(_AddDataBoxUserResponse_QNAME, TAddDBUserOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TISDSSearchOutput2 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "ISDSSearch3Response")
    public JAXBElement<TISDSSearchOutput2> createISDSSearch3Response(TISDSSearchOutput2 value) {
        return new JAXBElement<TISDSSearchOutput2>(_ISDSSearch3Response_QNAME, TISDSSearchOutput2 .class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "PDZsiResult", scope = TPDZSendOutput.class)
    public JAXBElement<Boolean> createTPDZSendOutputPDZsiResult(Boolean value) {
        return new JAXBElement<Boolean>(_TPDZSendOutputPDZsiResult_QNAME, Boolean.class, TPDZSendOutput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbApproved", scope = TIdDBDUInputAttrs2 .class)
    public JAXBElement<Boolean> createTIdDBDUInputAttrs2DbApproved(Boolean value) {
        return new JAXBElement<Boolean>(_TIdDBDUInputAttrs2DbApproved_QNAME, Boolean.class, TIdDBDUInputAttrs2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbExternRefNumber", scope = TIdDBDUInputAttrs2 .class)
    public JAXBElement<String> createTIdDBDUInputAttrs2DbExternRefNumber(String value) {
        return new JAXBElement<String>(_TIdDBDUInputAttrs2DbExternRefNumber_QNAME, String.class, TIdDBDUInputAttrs2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbAccessDataId", scope = TNewAccDataOutput.class)
    public JAXBElement<String> createTNewAccDataOutputDbAccessDataId(String value) {
        return new JAXBElement<String>(_TNewAccDataOutputDbAccessDataId_QNAME, String.class, TNewAccDataOutput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbApproved", scope = TDeleteDBInput2 .class)
    public JAXBElement<Boolean> createTDeleteDBInput2DbApproved(Boolean value) {
        return new JAXBElement<Boolean>(_TIdDBDUInputAttrs2DbApproved_QNAME, Boolean.class, TDeleteDBInput2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbExternRefNumber", scope = TDeleteDBInput2 .class)
    public JAXBElement<String> createTDeleteDBInput2DbExternRefNumber(String value) {
        return new JAXBElement<String>(_TIdDBDUInputAttrs2DbExternRefNumber_QNAME, String.class, TDeleteDBInput2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbID", scope = TAddDBUserOutput2 .class)
    public JAXBElement<String> createTAddDBUserOutput2DbID(String value) {
        return new JAXBElement<String>(_TAddDBUserOutput2DbID_QNAME, String.class, TAddDBUserOutput2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbAccessDataId", scope = TAddDBUserOutput2 .class)
    public JAXBElement<String> createTAddDBUserOutput2DbAccessDataId(String value) {
        return new JAXBElement<String>(_TNewAccDataOutputDbAccessDataId_QNAME, String.class, TAddDBUserOutput2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbApproved", scope = TUpdateDBInput2 .class)
    public JAXBElement<Boolean> createTUpdateDBInput2DbApproved(Boolean value) {
        return new JAXBElement<Boolean>(_TIdDBDUInputAttrs2DbApproved_QNAME, Boolean.class, TUpdateDBInput2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbExternRefNumber", scope = TUpdateDBInput2 .class)
    public JAXBElement<String> createTUpdateDBInput2DbExternRefNumber(String value) {
        return new JAXBElement<String>(_TIdDBDUInputAttrs2DbExternRefNumber_QNAME, String.class, TUpdateDBInput2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link byte[]}{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dblData", scope = TGetDBListOutput.class)
    public JAXBElement<byte[]> createTGetDBListOutputDblData(byte[] value) {
        return new JAXBElement<byte[]>(_TGetDBListOutputDblData_QNAME, byte[].class, TGetDBListOutput.class, ((byte[]) value));
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "ciOldFrom", scope = TCiRecord.class)
    public JAXBElement<XMLGregorianCalendar> createTCiRecordCiOldFrom(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_TCiRecordCiOldFrom_QNAME, XMLGregorianCalendar.class, TCiRecord.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "ciDoneBy", scope = TCiRecord.class)
    public JAXBElement<String> createTCiRecordCiDoneBy(String value) {
        return new JAXBElement<String>(_TCiRecordCiDoneBy_QNAME, String.class, TCiRecord.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "ciOldTo", scope = TCiRecord.class)
    public JAXBElement<XMLGregorianCalendar> createTCiRecordCiOldTo(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_TCiRecordCiOldTo_QNAME, XMLGregorianCalendar.class, TCiRecord.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "ciOldCapacity", scope = TCiRecord.class)
    public JAXBElement<BigInteger> createTCiRecordCiOldCapacity(BigInteger value) {
        return new JAXBElement<BigInteger>(_TCiRecordCiOldCapacity_QNAME, BigInteger.class, TCiRecord.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbApproved", scope = TDeleteDBPromptlyInput.class)
    public JAXBElement<Boolean> createTDeleteDBPromptlyInputDbApproved(Boolean value) {
        return new JAXBElement<Boolean>(_TIdDBDUInputAttrs2DbApproved_QNAME, Boolean.class, TDeleteDBPromptlyInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbExternRefNumber", scope = TDeleteDBPromptlyInput.class)
    public JAXBElement<String> createTDeleteDBPromptlyInputDbExternRefNumber(String value) {
        return new JAXBElement<String>(_TIdDBDUInputAttrs2DbExternRefNumber_QNAME, String.class, TDeleteDBPromptlyInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbApproved", scope = TDelDBUserInput.class)
    public JAXBElement<Boolean> createTDelDBUserInputDbApproved(Boolean value) {
        return new JAXBElement<Boolean>(_TIdDBDUInputAttrs2DbApproved_QNAME, Boolean.class, TDelDBUserInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbExternRefNumber", scope = TDelDBUserInput.class)
    public JAXBElement<String> createTDelDBUserInputDbExternRefNumber(String value) {
        return new JAXBElement<String>(_TIdDBDUInputAttrs2DbExternRefNumber_QNAME, String.class, TDelDBUserInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "caState", scope = TDbUserInfo.class)
    public JAXBElement<String> createTDbUserInfoCaState(String value) {
        return new JAXBElement<String>(_TDbUserInfoCaState_QNAME, String.class, TDbUserInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbApproved", scope = TDeleteDBInput.class)
    public JAXBElement<Boolean> createTDeleteDBInputDbApproved(Boolean value) {
        return new JAXBElement<Boolean>(_TIdDBDUInputAttrs2DbApproved_QNAME, Boolean.class, TDeleteDBInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbExternRefNumber", scope = TDeleteDBInput.class)
    public JAXBElement<String> createTDeleteDBInputDbExternRefNumber(String value) {
        return new JAXBElement<String>(_TIdDBDUInputAttrs2DbExternRefNumber_QNAME, String.class, TDeleteDBInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbApproved", scope = TOwnerInfoInput.class)
    public JAXBElement<Boolean> createTOwnerInfoInputDbApproved(Boolean value) {
        return new JAXBElement<Boolean>(_TIdDBDUInputAttrs2DbApproved_QNAME, Boolean.class, TOwnerInfoInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbExternRefNumber", scope = TOwnerInfoInput.class)
    public JAXBElement<String> createTOwnerInfoInputDbExternRefNumber(String value) {
        return new JAXBElement<String>(_TIdDBDUInputAttrs2DbExternRefNumber_QNAME, String.class, TOwnerInfoInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "adAMCode", scope = TDbOwnerInfoExt.class)
    public JAXBElement<String> createTDbOwnerInfoExtAdAMCode(String value) {
        return new JAXBElement<String>(_TDbOwnerInfoExtAdAMCode_QNAME, String.class, TDbOwnerInfoExt.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "adDistrict", scope = TDbOwnerInfoExt.class)
    public JAXBElement<String> createTDbOwnerInfoExtAdDistrict(String value) {
        return new JAXBElement<String>(_TDbOwnerInfoExtAdDistrict_QNAME, String.class, TDbOwnerInfoExt.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "telNumber", scope = TDbOwnerInfoExt.class)
    public JAXBElement<String> createTDbOwnerInfoExtTelNumber(String value) {
        return new JAXBElement<String>(_TDbOwnerInfoExtTelNumber_QNAME, String.class, TDbOwnerInfoExt.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "email", scope = TDbOwnerInfoExt.class)
    public JAXBElement<String> createTDbOwnerInfoExtEmail(String value) {
        return new JAXBElement<String>(_TDbOwnerInfoExtEmail_QNAME, String.class, TDbOwnerInfoExt.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbID", scope = TCreateDBOutput.class)
    public JAXBElement<String> createTCreateDBOutputDbID(String value) {
        return new JAXBElement<String>(_TAddDBUserOutput2DbID_QNAME, String.class, TCreateDBOutput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbAccessDataId", scope = TCreateDBOutput.class)
    public JAXBElement<String> createTCreateDBOutputDbAccessDataId(String value) {
        return new JAXBElement<String>(_TNewAccDataOutputDbAccessDataId_QNAME, String.class, TCreateDBOutput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbUserID", scope = TCreateDBOutput.class)
    public JAXBElement<String> createTCreateDBOutputDbUserID(String value) {
        return new JAXBElement<String>(_TCreateDBOutputDbUserID_QNAME, String.class, TCreateDBOutput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbApproved", scope = TUpdDBUserInput.class)
    public JAXBElement<Boolean> createTUpdDBUserInputDbApproved(Boolean value) {
        return new JAXBElement<Boolean>(_TIdDBDUInputAttrs2DbApproved_QNAME, Boolean.class, TUpdDBUserInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbExternRefNumber", scope = TUpdDBUserInput.class)
    public JAXBElement<String> createTUpdDBUserInputDbExternRefNumber(String value) {
        return new JAXBElement<String>(_TIdDBDUInputAttrs2DbExternRefNumber_QNAME, String.class, TUpdDBUserInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "highlighting", scope = TISDSSearchInput.class)
    public JAXBElement<Boolean> createTISDSSearchInputHighlighting(Boolean value) {
        return new JAXBElement<Boolean>(_TISDSSearchInputHighlighting_QNAME, Boolean.class, TISDSSearchInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbApproved", scope = TCreateDBInput2 .class)
    public JAXBElement<Boolean> createTCreateDBInput2DbApproved(Boolean value) {
        return new JAXBElement<Boolean>(_TIdDBDUInputAttrs2DbApproved_QNAME, Boolean.class, TCreateDBInput2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "notifEmail", scope = TCreateDBInput2 .class)
    public JAXBElement<String> createTCreateDBInput2NotifEmail(String value) {
        return new JAXBElement<String>(_TCreateDBInput2NotifEmail_QNAME, String.class, TCreateDBInput2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "pnLastNameAtBirth", scope = TCreateDBInput2 .class)
    public JAXBElement<String> createTCreateDBInput2PnLastNameAtBirth(String value) {
        return new JAXBElement<String>(_TCreateDBInput2PnLastNameAtBirth_QNAME, String.class, TCreateDBInput2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "email", scope = TCreateDBInput2 .class)
    public JAXBElement<String> createTCreateDBInput2Email(String value) {
        return new JAXBElement<String>(_TDbOwnerInfoExtEmail_QNAME, String.class, TCreateDBInput2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbVirtual", scope = TCreateDBInput2 .class)
    public JAXBElement<Boolean> createTCreateDBInput2DbVirtual(Boolean value) {
        return new JAXBElement<Boolean>(_TCreateDBInput2DbVirtual_QNAME, Boolean.class, TCreateDBInput2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbExternRefNumber", scope = TCreateDBInput2 .class)
    public JAXBElement<String> createTCreateDBInput2DbExternRefNumber(String value) {
        return new JAXBElement<String>(_TIdDBDUInputAttrs2DbExternRefNumber_QNAME, String.class, TCreateDBInput2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbApproved", scope = TNewAccDataInput2 .class)
    public JAXBElement<Boolean> createTNewAccDataInput2DbApproved(Boolean value) {
        return new JAXBElement<Boolean>(_TIdDBDUInputAttrs2DbApproved_QNAME, Boolean.class, TNewAccDataInput2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "email", scope = TNewAccDataInput2 .class)
    public JAXBElement<String> createTNewAccDataInput2Email(String value) {
        return new JAXBElement<String>(_TDbOwnerInfoExtEmail_QNAME, String.class, TNewAccDataInput2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbExternRefNumber", scope = TNewAccDataInput2 .class)
    public JAXBElement<String> createTNewAccDataInput2DbExternRefNumber(String value) {
        return new JAXBElement<String>(_TIdDBDUInputAttrs2DbExternRefNumber_QNAME, String.class, TNewAccDataInput2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbAccessDataId", scope = TNewAccDataOutput2 .class)
    public JAXBElement<String> createTNewAccDataOutput2DbAccessDataId(String value) {
        return new JAXBElement<String>(_TNewAccDataOutputDbAccessDataId_QNAME, String.class, TNewAccDataOutput2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbApproved", scope = TAddDBUserInput.class)
    public JAXBElement<Boolean> createTAddDBUserInputDbApproved(Boolean value) {
        return new JAXBElement<Boolean>(_TIdDBDUInputAttrs2DbApproved_QNAME, Boolean.class, TAddDBUserInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "email", scope = TAddDBUserInput.class)
    public JAXBElement<String> createTAddDBUserInputEmail(String value) {
        return new JAXBElement<String>(_TDbOwnerInfoExtEmail_QNAME, String.class, TAddDBUserInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbExternRefNumber", scope = TAddDBUserInput.class)
    public JAXBElement<String> createTAddDBUserInputDbExternRefNumber(String value) {
        return new JAXBElement<String>(_TIdDBDUInputAttrs2DbExternRefNumber_QNAME, String.class, TAddDBUserInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbApproved", scope = TDisableExternallyInput.class)
    public JAXBElement<Boolean> createTDisableExternallyInputDbApproved(Boolean value) {
        return new JAXBElement<Boolean>(_TIdDBDUInputAttrs2DbApproved_QNAME, Boolean.class, TDisableExternallyInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbExternRefNumber", scope = TDisableExternallyInput.class)
    public JAXBElement<String> createTDisableExternallyInputDbExternRefNumber(String value) {
        return new JAXBElement<String>(_TIdDBDUInputAttrs2DbExternRefNumber_QNAME, String.class, TDisableExternallyInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbID", scope = TCreateDBOutput2 .class)
    public JAXBElement<String> createTCreateDBOutput2DbID(String value) {
        return new JAXBElement<String>(_TAddDBUserOutput2DbID_QNAME, String.class, TCreateDBOutput2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbAccessDataId", scope = TCreateDBOutput2 .class)
    public JAXBElement<String> createTCreateDBOutput2DbAccessDataId(String value) {
        return new JAXBElement<String>(_TNewAccDataOutputDbAccessDataId_QNAME, String.class, TCreateDBOutput2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbUserID", scope = TCreateDBOutput2 .class)
    public JAXBElement<String> createTCreateDBOutput2DbUserID(String value) {
        return new JAXBElement<String>(_TCreateDBOutputDbUserID_QNAME, String.class, TCreateDBOutput2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbApproved", scope = TDelDBUserInput2 .class)
    public JAXBElement<Boolean> createTDelDBUserInput2DbApproved(Boolean value) {
        return new JAXBElement<Boolean>(_TIdDBDUInputAttrs2DbApproved_QNAME, Boolean.class, TDelDBUserInput2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbExternRefNumber", scope = TDelDBUserInput2 .class)
    public JAXBElement<String> createTDelDBUserInput2DbExternRefNumber(String value) {
        return new JAXBElement<String>(_TIdDBDUInputAttrs2DbExternRefNumber_QNAME, String.class, TDelDBUserInput2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbApproved", scope = TAddDBUserInput2 .class)
    public JAXBElement<Boolean> createTAddDBUserInput2DbApproved(Boolean value) {
        return new JAXBElement<Boolean>(_TIdDBDUInputAttrs2DbApproved_QNAME, Boolean.class, TAddDBUserInput2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "email", scope = TAddDBUserInput2 .class)
    public JAXBElement<String> createTAddDBUserInput2Email(String value) {
        return new JAXBElement<String>(_TDbOwnerInfoExtEmail_QNAME, String.class, TAddDBUserInput2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbExternRefNumber", scope = TAddDBUserInput2 .class)
    public JAXBElement<String> createTAddDBUserInput2DbExternRefNumber(String value) {
        return new JAXBElement<String>(_TIdDBDUInputAttrs2DbExternRefNumber_QNAME, String.class, TAddDBUserInput2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbApproved", scope = TUpdDBUserInput2 .class)
    public JAXBElement<Boolean> createTUpdDBUserInput2DbApproved(Boolean value) {
        return new JAXBElement<Boolean>(_TIdDBDUInputAttrs2DbApproved_QNAME, Boolean.class, TUpdDBUserInput2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbExternRefNumber", scope = TUpdDBUserInput2 .class)
    public JAXBElement<String> createTUpdDBUserInput2DbExternRefNumber(String value) {
        return new JAXBElement<String>(_TIdDBDUInputAttrs2DbExternRefNumber_QNAME, String.class, TUpdDBUserInput2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbApproved", scope = TIdDBDUInput.class)
    public JAXBElement<Boolean> createTIdDBDUInputDbApproved(Boolean value) {
        return new JAXBElement<Boolean>(_TIdDBDUInputAttrs2DbApproved_QNAME, Boolean.class, TIdDBDUInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbExternRefNumber", scope = TIdDBDUInput.class)
    public JAXBElement<String> createTIdDBDUInputDbExternRefNumber(String value) {
        return new JAXBElement<String>(_TIdDBDUInputAttrs2DbExternRefNumber_QNAME, String.class, TIdDBDUInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "notifEmail", scope = TDBCreditInfoOutput.class)
    public JAXBElement<String> createTDBCreditInfoOutputNotifEmail(String value) {
        return new JAXBElement<String>(_TCreateDBInput2NotifEmail_QNAME, String.class, TDBCreditInfoOutput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TDbOwnersArray2 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbResults", scope = TFindDBOuput2 .class)
    public JAXBElement<TDbOwnersArray2> createTFindDBOuput2DbResults(TDbOwnersArray2 value) {
        return new JAXBElement<TDbOwnersArray2>(_TFindDBOuput2DbResults_QNAME, TDbOwnersArray2 .class, TFindDBOuput2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbApproved", scope = TUpdateDBInput.class)
    public JAXBElement<Boolean> createTUpdateDBInputDbApproved(Boolean value) {
        return new JAXBElement<Boolean>(_TIdDBDUInputAttrs2DbApproved_QNAME, Boolean.class, TUpdateDBInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbExternRefNumber", scope = TUpdateDBInput.class)
    public JAXBElement<String> createTUpdateDBInputDbExternRefNumber(String value) {
        return new JAXBElement<String>(_TIdDBDUInputAttrs2DbExternRefNumber_QNAME, String.class, TUpdateDBInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbStatusRefNumber", scope = TDbReqStatus.class)
    public JAXBElement<String> createTDbReqStatusDbStatusRefNumber(String value) {
        return new JAXBElement<String>(_TDbReqStatusDbStatusRefNumber_QNAME, String.class, TDbReqStatus.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "highlighting", scope = TISDSSearchInput3 .class)
    public JAXBElement<Boolean> createTISDSSearchInput3Highlighting(Boolean value) {
        return new JAXBElement<Boolean>(_TISDSSearchInputHighlighting_QNAME, Boolean.class, TISDSSearchInput3 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "FutDTCapacity", scope = TDTInfoOutput.class)
    public JAXBElement<BigInteger> createTDTInfoOutputFutDTCapacity(BigInteger value) {
        return new JAXBElement<BigInteger>(_TDTInfoOutputFutDTCapacity_QNAME, BigInteger.class, TDTInfoOutput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "ActDTCapacity", scope = TDTInfoOutput.class)
    public JAXBElement<BigInteger> createTDTInfoOutputActDTCapacity(BigInteger value) {
        return new JAXBElement<BigInteger>(_TDTInfoOutputActDTCapacity_QNAME, BigInteger.class, TDTInfoOutput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "FutDTFrom", scope = TDTInfoOutput.class)
    public JAXBElement<XMLGregorianCalendar> createTDTInfoOutputFutDTFrom(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_TDTInfoOutputFutDTFrom_QNAME, XMLGregorianCalendar.class, TDTInfoOutput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "ActDTCapUsed", scope = TDTInfoOutput.class)
    public JAXBElement<BigInteger> createTDTInfoOutputActDTCapUsed(BigInteger value) {
        return new JAXBElement<BigInteger>(_TDTInfoOutputActDTCapUsed_QNAME, BigInteger.class, TDTInfoOutput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigInteger }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "FutDTPaid", scope = TDTInfoOutput.class)
    public JAXBElement<BigInteger> createTDTInfoOutputFutDTPaid(BigInteger value) {
        return new JAXBElement<BigInteger>(_TDTInfoOutputFutDTPaid_QNAME, BigInteger.class, TDTInfoOutput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "ActDTFrom", scope = TDTInfoOutput.class)
    public JAXBElement<XMLGregorianCalendar> createTDTInfoOutputActDTFrom(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_TDTInfoOutputActDTFrom_QNAME, XMLGregorianCalendar.class, TDTInfoOutput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "FutDTTo", scope = TDTInfoOutput.class)
    public JAXBElement<XMLGregorianCalendar> createTDTInfoOutputFutDTTo(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_TDTInfoOutputFutDTTo_QNAME, XMLGregorianCalendar.class, TDTInfoOutput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "ActDTTo", scope = TDTInfoOutput.class)
    public JAXBElement<XMLGregorianCalendar> createTDTInfoOutputActDTTo(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_TDTInfoOutputActDTTo_QNAME, XMLGregorianCalendar.class, TDTInfoOutput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "caState", scope = TDbUserInfoExt2 .class)
    public JAXBElement<String> createTDbUserInfoExt2CaState(String value) {
        return new JAXBElement<String>(_TDbUserInfoCaState_QNAME, String.class, TDbUserInfoExt2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "telNumber", scope = TDbOwnerInfo.class)
    public JAXBElement<String> createTDbOwnerInfoTelNumber(String value) {
        return new JAXBElement<String>(_TDbOwnerInfoExtTelNumber_QNAME, String.class, TDbOwnerInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "email", scope = TDbOwnerInfo.class)
    public JAXBElement<String> createTDbOwnerInfoEmail(String value) {
        return new JAXBElement<String>(_TDbOwnerInfoExtEmail_QNAME, String.class, TDbOwnerInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TdbPersOwnersArray }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbResults", scope = TFindPersonalDBOutput.class)
    public JAXBElement<TdbPersOwnersArray> createTFindPersonalDBOutputDbResults(TdbPersOwnersArray value) {
        return new JAXBElement<TdbPersOwnersArray>(_TFindDBOuput2DbResults_QNAME, TdbPersOwnersArray.class, TFindPersonalDBOutput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "aifoIsds", scope = TDbOwnerInfoExt2 .class)
    public JAXBElement<Boolean> createTDbOwnerInfoExt2AifoIsds(Boolean value) {
        return new JAXBElement<Boolean>(_TDbOwnerInfoExt2AifoIsds_QNAME, Boolean.class, TDbOwnerInfoExt2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbApproved", scope = TIdDBInput.class)
    public JAXBElement<Boolean> createTIdDBInputDbApproved(Boolean value) {
        return new JAXBElement<Boolean>(_TIdDBDUInputAttrs2DbApproved_QNAME, Boolean.class, TIdDBInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbExternRefNumber", scope = TIdDBInput.class)
    public JAXBElement<String> createTIdDBInputDbExternRefNumber(String value) {
        return new JAXBElement<String>(_TIdDBDUInputAttrs2DbExternRefNumber_QNAME, String.class, TIdDBInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TDbOwnersArray }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbResults", scope = TFindDBOuput.class)
    public JAXBElement<TDbOwnersArray> createTFindDBOuputDbResults(TDbOwnersArray value) {
        return new JAXBElement<TDbOwnersArray>(_TFindDBOuput2DbResults_QNAME, TDbOwnersArray.class, TFindDBOuput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbApproved", scope = TNewAccDataInput.class)
    public JAXBElement<Boolean> createTNewAccDataInputDbApproved(Boolean value) {
        return new JAXBElement<Boolean>(_TIdDBDUInputAttrs2DbApproved_QNAME, Boolean.class, TNewAccDataInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "email", scope = TNewAccDataInput.class)
    public JAXBElement<String> createTNewAccDataInputEmail(String value) {
        return new JAXBElement<String>(_TDbOwnerInfoExtEmail_QNAME, String.class, TNewAccDataInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbExternRefNumber", scope = TNewAccDataInput.class)
    public JAXBElement<String> createTNewAccDataInputDbExternRefNumber(String value) {
        return new JAXBElement<String>(_TIdDBDUInputAttrs2DbExternRefNumber_QNAME, String.class, TNewAccDataInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbApproved", scope = TIdDBInputAttrs.class)
    public JAXBElement<Boolean> createTIdDBInputAttrsDbApproved(Boolean value) {
        return new JAXBElement<Boolean>(_TIdDBDUInputAttrs2DbApproved_QNAME, Boolean.class, TIdDBInputAttrs.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbExternRefNumber", scope = TIdDBInputAttrs.class)
    public JAXBElement<String> createTIdDBInputAttrsDbExternRefNumber(String value) {
        return new JAXBElement<String>(_TIdDBDUInputAttrs2DbExternRefNumber_QNAME, String.class, TIdDBInputAttrs.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbApproved", scope = TCreateDBInput.class)
    public JAXBElement<Boolean> createTCreateDBInputDbApproved(Boolean value) {
        return new JAXBElement<Boolean>(_TIdDBDUInputAttrs2DbApproved_QNAME, Boolean.class, TCreateDBInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbUpperDBId", scope = TCreateDBInput.class)
    public JAXBElement<String> createTCreateDBInputDbUpperDBId(String value) {
        return new JAXBElement<String>(_TCreateDBInputDbUpperDBId_QNAME, String.class, TCreateDBInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbCEOLabel", scope = TCreateDBInput.class)
    public JAXBElement<String> createTCreateDBInputDbCEOLabel(String value) {
        return new JAXBElement<String>(_TCreateDBInputDbCEOLabel_QNAME, String.class, TCreateDBInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "email", scope = TCreateDBInput.class)
    public JAXBElement<String> createTCreateDBInputEmail(String value) {
        return new JAXBElement<String>(_TDbOwnerInfoExtEmail_QNAME, String.class, TCreateDBInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbVirtual", scope = TCreateDBInput.class)
    public JAXBElement<Boolean> createTCreateDBInputDbVirtual(Boolean value) {
        return new JAXBElement<Boolean>(_TCreateDBInput2DbVirtual_QNAME, Boolean.class, TCreateDBInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbExternRefNumber", scope = TCreateDBInput.class)
    public JAXBElement<String> createTCreateDBInputDbExternRefNumber(String value) {
        return new JAXBElement<String>(_TIdDBDUInputAttrs2DbExternRefNumber_QNAME, String.class, TCreateDBInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbFormerNames", scope = TCreateDBInput.class)
    public JAXBElement<String> createTCreateDBInputDbFormerNames(String value) {
        return new JAXBElement<String>(_TCreateDBInputDbFormerNames_QNAME, String.class, TCreateDBInput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "adAMCode", scope = TDbUserInfoExt.class)
    public JAXBElement<String> createTDbUserInfoExtAdAMCode(String value) {
        return new JAXBElement<String>(_TDbOwnerInfoExtAdAMCode_QNAME, String.class, TDbUserInfoExt.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "caState", scope = TDbUserInfoExt.class)
    public JAXBElement<String> createTDbUserInfoExtCaState(String value) {
        return new JAXBElement<String>(_TDbUserInfoCaState_QNAME, String.class, TDbUserInfoExt.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "adDistrict", scope = TDbUserInfoExt.class)
    public JAXBElement<String> createTDbUserInfoExtAdDistrict(String value) {
        return new JAXBElement<String>(_TDbOwnerInfoExtAdDistrict_QNAME, String.class, TDbUserInfoExt.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbID", scope = TAddDBUserOutput.class)
    public JAXBElement<String> createTAddDBUserOutputDbID(String value) {
        return new JAXBElement<String>(_TAddDBUserOutput2DbID_QNAME, String.class, TAddDBUserOutput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbAccessDataId", scope = TAddDBUserOutput.class)
    public JAXBElement<String> createTAddDBUserOutputDbAccessDataId(String value) {
        return new JAXBElement<String>(_TNewAccDataOutputDbAccessDataId_QNAME, String.class, TAddDBUserOutput.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbApproved", scope = TDisableExternallyInput2 .class)
    public JAXBElement<Boolean> createTDisableExternallyInput2DbApproved(Boolean value) {
        return new JAXBElement<Boolean>(_TIdDBDUInputAttrs2DbApproved_QNAME, Boolean.class, TDisableExternallyInput2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "dbExternRefNumber", scope = TDisableExternallyInput2 .class)
    public JAXBElement<String> createTDisableExternallyInput2DbExternRefNumber(String value) {
        return new JAXBElement<String>(_TIdDBDUInputAttrs2DbExternRefNumber_QNAME, String.class, TDisableExternallyInput2 .class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "pswExpDate", scope = TGetPasswInfoOutput.class)
    public JAXBElement<XMLGregorianCalendar> createTGetPasswInfoOutputPswExpDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_TGetPasswInfoOutputPswExpDate_QNAME, XMLGregorianCalendar.class, TGetPasswInfoOutput.class, value);
    }

}
