
package cz.czechpoint.isds.v20;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for tDeleteDBInput2 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tDeleteDBInput2">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;group ref="{http://isds.czechpoint.cz/v20}gDbIdInupt"/>
 *         &lt;element name="dbOwnerTerminationDate" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;group ref="{http://isds.czechpoint.cz/v20}gExtApproval"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tDeleteDBInput2", propOrder = {
    "dbID",
    "dbOwnerTerminationDate",
    "dbApproved",
    "dbExternRefNumber"
})
public class TDeleteDBInput2 {

    @XmlElement(required = true)
    protected String dbID;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dbOwnerTerminationDate;
    @XmlElementRef(name = "dbApproved", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<Boolean> dbApproved;
    @XmlElementRef(name = "dbExternRefNumber", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<String> dbExternRefNumber;

    /**
     * Gets the value of the dbID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbID() {
        return dbID;
    }

    /**
     * Sets the value of the dbID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbID(String value) {
        this.dbID = value;
    }

    /**
     * Gets the value of the dbOwnerTerminationDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDbOwnerTerminationDate() {
        return dbOwnerTerminationDate;
    }

    /**
     * Sets the value of the dbOwnerTerminationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDbOwnerTerminationDate(XMLGregorianCalendar value) {
        this.dbOwnerTerminationDate = value;
    }

    /**
     * Gets the value of the dbApproved property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public JAXBElement<Boolean> getDbApproved() {
        return dbApproved;
    }

    /**
     * Sets the value of the dbApproved property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public void setDbApproved(JAXBElement<Boolean> value) {
        this.dbApproved = value;
    }

    /**
     * Gets the value of the dbExternRefNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDbExternRefNumber() {
        return dbExternRefNumber;
    }

    /**
     * Sets the value of the dbExternRefNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDbExternRefNumber(JAXBElement<String> value) {
        this.dbExternRefNumber = value;
    }

}
