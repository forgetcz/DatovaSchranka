
package cz.czechpoint.isds.v20;

import java.math.BigInteger;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for tCiRecord complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tCiRecord">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;group ref="{http://isds.czechpoint.cz/v20}gCiRecord"/>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tCiRecord", propOrder = {
    "ciEventTime",
    "ciEventType",
    "ciCreditChange",
    "ciCreditAfter",
    "ciTransID",
    "ciRecipientID",
    "ciPDZID",
    "ciNewCapacity",
    "ciNewFrom",
    "ciNewTo",
    "ciOldCapacity",
    "ciOldFrom",
    "ciOldTo",
    "ciDoneBy"
})
public class TCiRecord {

    @XmlElement(required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar ciEventTime;
    @XmlElement(required = true)
    protected BigInteger ciEventType;
    @XmlElement(required = true)
    protected BigInteger ciCreditChange;
    @XmlElement(required = true)
    protected BigInteger ciCreditAfter;
    protected String ciTransID;
    protected String ciRecipientID;
    protected String ciPDZID;
    protected BigInteger ciNewCapacity;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar ciNewFrom;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar ciNewTo;
    @XmlElementRef(name = "ciOldCapacity", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<BigInteger> ciOldCapacity;
    @XmlElementRef(name = "ciOldFrom", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> ciOldFrom;
    @XmlElementRef(name = "ciOldTo", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> ciOldTo;
    @XmlElementRef(name = "ciDoneBy", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<String> ciDoneBy;

    /**
     * Gets the value of the ciEventTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCiEventTime() {
        return ciEventTime;
    }

    /**
     * Sets the value of the ciEventTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCiEventTime(XMLGregorianCalendar value) {
        this.ciEventTime = value;
    }

    /**
     * Gets the value of the ciEventType property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCiEventType() {
        return ciEventType;
    }

    /**
     * Sets the value of the ciEventType property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCiEventType(BigInteger value) {
        this.ciEventType = value;
    }

    /**
     * Gets the value of the ciCreditChange property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCiCreditChange() {
        return ciCreditChange;
    }

    /**
     * Sets the value of the ciCreditChange property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCiCreditChange(BigInteger value) {
        this.ciCreditChange = value;
    }

    /**
     * Gets the value of the ciCreditAfter property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCiCreditAfter() {
        return ciCreditAfter;
    }

    /**
     * Sets the value of the ciCreditAfter property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCiCreditAfter(BigInteger value) {
        this.ciCreditAfter = value;
    }

    /**
     * Gets the value of the ciTransID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCiTransID() {
        return ciTransID;
    }

    /**
     * Sets the value of the ciTransID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCiTransID(String value) {
        this.ciTransID = value;
    }

    /**
     * Gets the value of the ciRecipientID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCiRecipientID() {
        return ciRecipientID;
    }

    /**
     * Sets the value of the ciRecipientID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCiRecipientID(String value) {
        this.ciRecipientID = value;
    }

    /**
     * Gets the value of the ciPDZID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCiPDZID() {
        return ciPDZID;
    }

    /**
     * Sets the value of the ciPDZID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCiPDZID(String value) {
        this.ciPDZID = value;
    }

    /**
     * Gets the value of the ciNewCapacity property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCiNewCapacity() {
        return ciNewCapacity;
    }

    /**
     * Sets the value of the ciNewCapacity property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCiNewCapacity(BigInteger value) {
        this.ciNewCapacity = value;
    }

    /**
     * Gets the value of the ciNewFrom property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCiNewFrom() {
        return ciNewFrom;
    }

    /**
     * Sets the value of the ciNewFrom property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCiNewFrom(XMLGregorianCalendar value) {
        this.ciNewFrom = value;
    }

    /**
     * Gets the value of the ciNewTo property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCiNewTo() {
        return ciNewTo;
    }

    /**
     * Sets the value of the ciNewTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCiNewTo(XMLGregorianCalendar value) {
        this.ciNewTo = value;
    }

    /**
     * Gets the value of the ciOldCapacity property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigInteger }{@code >}
     *     
     */
    public JAXBElement<BigInteger> getCiOldCapacity() {
        return ciOldCapacity;
    }

    /**
     * Sets the value of the ciOldCapacity property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigInteger }{@code >}
     *     
     */
    public void setCiOldCapacity(JAXBElement<BigInteger> value) {
        this.ciOldCapacity = value;
    }

    /**
     * Gets the value of the ciOldFrom property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getCiOldFrom() {
        return ciOldFrom;
    }

    /**
     * Sets the value of the ciOldFrom property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setCiOldFrom(JAXBElement<XMLGregorianCalendar> value) {
        this.ciOldFrom = value;
    }

    /**
     * Gets the value of the ciOldTo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getCiOldTo() {
        return ciOldTo;
    }

    /**
     * Sets the value of the ciOldTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setCiOldTo(JAXBElement<XMLGregorianCalendar> value) {
        this.ciOldTo = value;
    }

    /**
     * Gets the value of the ciDoneBy property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCiDoneBy() {
        return ciDoneBy;
    }

    /**
     * Sets the value of the ciDoneBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCiDoneBy(JAXBElement<String> value) {
        this.ciDoneBy = value;
    }

}
