
package cz.czechpoint.isds.v20;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for tPDZRec complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tPDZRec">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PDZType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PDZRecip" type="{http://isds.czechpoint.cz/v20}tIdDb"/>
 *         &lt;element name="PDZPayer" type="{http://isds.czechpoint.cz/v20}tIdDb"/>
 *         &lt;element name="PDZExpire" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="PDZCnt" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger"/>
 *         &lt;element name="ODZIdent" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tPDZRec", propOrder = {
    "pdzType",
    "pdzRecip",
    "pdzPayer",
    "pdzExpire",
    "pdzCnt",
    "odzIdent"
})
public class TPDZRec {

    @XmlElement(name = "PDZType", required = true)
    protected String pdzType;
    @XmlElement(name = "PDZRecip", required = true, nillable = true)
    protected String pdzRecip;
    @XmlElement(name = "PDZPayer", required = true)
    protected String pdzPayer;
    @XmlElement(name = "PDZExpire", required = true, nillable = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar pdzExpire;
    @XmlElement(name = "PDZCnt", required = true, nillable = true)
    @XmlSchemaType(name = "nonNegativeInteger")
    protected BigInteger pdzCnt;
    @XmlElement(name = "ODZIdent", required = true, nillable = true)
    protected String odzIdent;

    /**
     * Gets the value of the pdzType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPDZType() {
        return pdzType;
    }

    /**
     * Sets the value of the pdzType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPDZType(String value) {
        this.pdzType = value;
    }

    /**
     * Gets the value of the pdzRecip property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPDZRecip() {
        return pdzRecip;
    }

    /**
     * Sets the value of the pdzRecip property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPDZRecip(String value) {
        this.pdzRecip = value;
    }

    /**
     * Gets the value of the pdzPayer property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPDZPayer() {
        return pdzPayer;
    }

    /**
     * Sets the value of the pdzPayer property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPDZPayer(String value) {
        this.pdzPayer = value;
    }

    /**
     * Gets the value of the pdzExpire property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getPDZExpire() {
        return pdzExpire;
    }

    /**
     * Sets the value of the pdzExpire property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setPDZExpire(XMLGregorianCalendar value) {
        this.pdzExpire = value;
    }

    /**
     * Gets the value of the pdzCnt property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getPDZCnt() {
        return pdzCnt;
    }

    /**
     * Sets the value of the pdzCnt property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setPDZCnt(BigInteger value) {
        this.pdzCnt = value;
    }

    /**
     * Gets the value of the odzIdent property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getODZIdent() {
        return odzIdent;
    }

    /**
     * Sets the value of the odzIdent property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setODZIdent(String value) {
        this.odzIdent = value;
    }

}
