
package cz.czechpoint.isds.v20;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for tUpdDBUserInput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tUpdDBUserInput">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="dbOwnerInfo" type="{http://isds.czechpoint.cz/v20}tDbOwnerInfoExt"/>
 *         &lt;element name="dbOldUserInfo" type="{http://isds.czechpoint.cz/v20}tDbUserInfoExt"/>
 *         &lt;element name="dbNewUserInfo" type="{http://isds.czechpoint.cz/v20}tDbUserInfoExt"/>
 *         &lt;group ref="{http://isds.czechpoint.cz/v20}gExtApproval"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tUpdDBUserInput", propOrder = {
    "dbOwnerInfo",
    "dbOldUserInfo",
    "dbNewUserInfo",
    "dbApproved",
    "dbExternRefNumber"
})
public class TUpdDBUserInput {

    @XmlElement(required = true)
    protected TDbOwnerInfoExt dbOwnerInfo;
    @XmlElement(required = true)
    protected TDbUserInfoExt dbOldUserInfo;
    @XmlElement(required = true)
    protected TDbUserInfoExt dbNewUserInfo;
    @XmlElementRef(name = "dbApproved", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<Boolean> dbApproved;
    @XmlElementRef(name = "dbExternRefNumber", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<String> dbExternRefNumber;

    /**
     * Gets the value of the dbOwnerInfo property.
     * 
     * @return
     *     possible object is
     *     {@link TDbOwnerInfoExt }
     *     
     */
    public TDbOwnerInfoExt getDbOwnerInfo() {
        return dbOwnerInfo;
    }

    /**
     * Sets the value of the dbOwnerInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link TDbOwnerInfoExt }
     *     
     */
    public void setDbOwnerInfo(TDbOwnerInfoExt value) {
        this.dbOwnerInfo = value;
    }

    /**
     * Gets the value of the dbOldUserInfo property.
     * 
     * @return
     *     possible object is
     *     {@link TDbUserInfoExt }
     *     
     */
    public TDbUserInfoExt getDbOldUserInfo() {
        return dbOldUserInfo;
    }

    /**
     * Sets the value of the dbOldUserInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link TDbUserInfoExt }
     *     
     */
    public void setDbOldUserInfo(TDbUserInfoExt value) {
        this.dbOldUserInfo = value;
    }

    /**
     * Gets the value of the dbNewUserInfo property.
     * 
     * @return
     *     possible object is
     *     {@link TDbUserInfoExt }
     *     
     */
    public TDbUserInfoExt getDbNewUserInfo() {
        return dbNewUserInfo;
    }

    /**
     * Sets the value of the dbNewUserInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link TDbUserInfoExt }
     *     
     */
    public void setDbNewUserInfo(TDbUserInfoExt value) {
        this.dbNewUserInfo = value;
    }

    /**
     * Gets the value of the dbApproved property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public JAXBElement<Boolean> getDbApproved() {
        return dbApproved;
    }

    /**
     * Sets the value of the dbApproved property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public void setDbApproved(JAXBElement<Boolean> value) {
        this.dbApproved = value;
    }

    /**
     * Gets the value of the dbExternRefNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDbExternRefNumber() {
        return dbExternRefNumber;
    }

    /**
     * Sets the value of the dbExternRefNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDbExternRefNumber(JAXBElement<String> value) {
        this.dbExternRefNumber = value;
    }

}
