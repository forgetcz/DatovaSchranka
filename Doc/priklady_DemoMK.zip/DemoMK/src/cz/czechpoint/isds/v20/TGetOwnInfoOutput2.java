
package cz.czechpoint.isds.v20;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for tGetOwnInfoOutput2 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tGetOwnInfoOutput2">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="dbOwnerInfo" type="{http://isds.czechpoint.cz/v20}tDbOwnerInfoExt2"/>
 *         &lt;element name="dbStatus" type="{http://isds.czechpoint.cz/v20}tDbReqStatus"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tGetOwnInfoOutput2", propOrder = {
    "dbOwnerInfo",
    "dbStatus"
})
public class TGetOwnInfoOutput2 {

    @XmlElement(required = true)
    protected TDbOwnerInfoExt2 dbOwnerInfo;
    @XmlElement(required = true)
    protected TDbReqStatus dbStatus;

    /**
     * Gets the value of the dbOwnerInfo property.
     * 
     * @return
     *     possible object is
     *     {@link TDbOwnerInfoExt2 }
     *     
     */
    public TDbOwnerInfoExt2 getDbOwnerInfo() {
        return dbOwnerInfo;
    }

    /**
     * Sets the value of the dbOwnerInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link TDbOwnerInfoExt2 }
     *     
     */
    public void setDbOwnerInfo(TDbOwnerInfoExt2 value) {
        this.dbOwnerInfo = value;
    }

    /**
     * Gets the value of the dbStatus property.
     * 
     * @return
     *     possible object is
     *     {@link TDbReqStatus }
     *     
     */
    public TDbReqStatus getDbStatus() {
        return dbStatus;
    }

    /**
     * Sets the value of the dbStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link TDbReqStatus }
     *     
     */
    public void setDbStatus(TDbReqStatus value) {
        this.dbStatus = value;
    }

}
