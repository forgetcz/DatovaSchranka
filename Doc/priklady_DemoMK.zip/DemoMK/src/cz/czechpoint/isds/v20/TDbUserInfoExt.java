
package cz.czechpoint.isds.v20;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * typ pro veškeré informace o uživateli schránky verze 1
 * 
 * <p>Java class for tDbUserInfoExt complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tDbUserInfoExt">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;group ref="{http://isds.czechpoint.cz/v20}gPersonName"/>
 *         &lt;group ref="{http://isds.czechpoint.cz/v20}gAddressExt"/>
 *         &lt;element name="biDate" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="userID" type="{http://isds.czechpoint.cz/v20}tUserID"/>
 *         &lt;element name="userType" type="{http://isds.czechpoint.cz/v20}tUserType"/>
 *         &lt;element name="userPrivils" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="ic">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="8"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="firmName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="caStreet" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="caCity" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="caZipCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="caState" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tDbUserInfoExt", propOrder = {
    "pnFirstName",
    "pnMiddleName",
    "pnLastName",
    "pnLastNameAtBirth",
    "adCity",
    "adDistrict",
    "adStreet",
    "adNumberInStreet",
    "adNumberInMunicipality",
    "adZipCode",
    "adState",
    "adAMCode",
    "biDate",
    "userID",
    "userType",
    "userPrivils",
    "ic",
    "firmName",
    "caStreet",
    "caCity",
    "caZipCode",
    "caState"
})
@XmlSeeAlso({
    cz.czechpoint.isds.v20.TAddDBUserInput.DbUserInfo.class,
    cz.czechpoint.isds.v20.TDbUsersArray.DbUserInfo.class
})
public class TDbUserInfoExt {

    @XmlElement(required = true, nillable = true)
    protected String pnFirstName;
    @XmlElement(required = true, nillable = true)
    protected String pnMiddleName;
    @XmlElement(required = true, nillable = true)
    protected String pnLastName;
    @XmlElement(required = true, nillable = true)
    protected String pnLastNameAtBirth;
    @XmlElement(required = true, nillable = true)
    protected String adCity;
    @XmlElementRef(name = "adDistrict", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<String> adDistrict;
    @XmlElement(required = true, nillable = true)
    protected String adStreet;
    @XmlElement(required = true, nillable = true)
    protected String adNumberInStreet;
    @XmlElement(required = true, nillable = true)
    protected String adNumberInMunicipality;
    @XmlElement(required = true, nillable = true)
    protected String adZipCode;
    @XmlElement(required = true, nillable = true)
    protected String adState;
    @XmlElementRef(name = "adAMCode", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<String> adAMCode;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar biDate;
    @XmlElement(required = true, nillable = true)
    protected String userID;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "string")
    protected TUserType userType;
    @XmlElement(required = true, type = Long.class, nillable = true)
    protected Long userPrivils;
    @XmlElement(required = true, nillable = true)
    protected String ic;
    @XmlElement(required = true, nillable = true)
    protected String firmName;
    @XmlElement(required = true, nillable = true)
    protected String caStreet;
    @XmlElement(required = true, nillable = true)
    protected String caCity;
    @XmlElement(required = true, nillable = true)
    protected String caZipCode;
    @XmlElementRef(name = "caState", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<String> caState;

    /**
     * Gets the value of the pnFirstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPnFirstName() {
        return pnFirstName;
    }

    /**
     * Sets the value of the pnFirstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPnFirstName(String value) {
        this.pnFirstName = value;
    }

    /**
     * Gets the value of the pnMiddleName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPnMiddleName() {
        return pnMiddleName;
    }

    /**
     * Sets the value of the pnMiddleName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPnMiddleName(String value) {
        this.pnMiddleName = value;
    }

    /**
     * Gets the value of the pnLastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPnLastName() {
        return pnLastName;
    }

    /**
     * Sets the value of the pnLastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPnLastName(String value) {
        this.pnLastName = value;
    }

    /**
     * Gets the value of the pnLastNameAtBirth property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPnLastNameAtBirth() {
        return pnLastNameAtBirth;
    }

    /**
     * Sets the value of the pnLastNameAtBirth property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPnLastNameAtBirth(String value) {
        this.pnLastNameAtBirth = value;
    }

    /**
     * Gets the value of the adCity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdCity() {
        return adCity;
    }

    /**
     * Sets the value of the adCity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdCity(String value) {
        this.adCity = value;
    }

    /**
     * Gets the value of the adDistrict property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAdDistrict() {
        return adDistrict;
    }

    /**
     * Sets the value of the adDistrict property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAdDistrict(JAXBElement<String> value) {
        this.adDistrict = value;
    }

    /**
     * Gets the value of the adStreet property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdStreet() {
        return adStreet;
    }

    /**
     * Sets the value of the adStreet property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdStreet(String value) {
        this.adStreet = value;
    }

    /**
     * Gets the value of the adNumberInStreet property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdNumberInStreet() {
        return adNumberInStreet;
    }

    /**
     * Sets the value of the adNumberInStreet property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdNumberInStreet(String value) {
        this.adNumberInStreet = value;
    }

    /**
     * Gets the value of the adNumberInMunicipality property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdNumberInMunicipality() {
        return adNumberInMunicipality;
    }

    /**
     * Sets the value of the adNumberInMunicipality property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdNumberInMunicipality(String value) {
        this.adNumberInMunicipality = value;
    }

    /**
     * Gets the value of the adZipCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdZipCode() {
        return adZipCode;
    }

    /**
     * Sets the value of the adZipCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdZipCode(String value) {
        this.adZipCode = value;
    }

    /**
     * Gets the value of the adState property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdState() {
        return adState;
    }

    /**
     * Sets the value of the adState property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdState(String value) {
        this.adState = value;
    }

    /**
     * Gets the value of the adAMCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAdAMCode() {
        return adAMCode;
    }

    /**
     * Sets the value of the adAMCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAdAMCode(JAXBElement<String> value) {
        this.adAMCode = value;
    }

    /**
     * Gets the value of the biDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getBiDate() {
        return biDate;
    }

    /**
     * Sets the value of the biDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setBiDate(XMLGregorianCalendar value) {
        this.biDate = value;
    }

    /**
     * Gets the value of the userID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserID() {
        return userID;
    }

    /**
     * Sets the value of the userID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserID(String value) {
        this.userID = value;
    }

    /**
     * Gets the value of the userType property.
     * 
     * @return
     *     possible object is
     *     {@link TUserType }
     *     
     */
    public TUserType getUserType() {
        return userType;
    }

    /**
     * Sets the value of the userType property.
     * 
     * @param value
     *     allowed object is
     *     {@link TUserType }
     *     
     */
    public void setUserType(TUserType value) {
        this.userType = value;
    }

    /**
     * Gets the value of the userPrivils property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getUserPrivils() {
        return userPrivils;
    }

    /**
     * Sets the value of the userPrivils property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setUserPrivils(Long value) {
        this.userPrivils = value;
    }

    /**
     * Gets the value of the ic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIc() {
        return ic;
    }

    /**
     * Sets the value of the ic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIc(String value) {
        this.ic = value;
    }

    /**
     * Gets the value of the firmName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFirmName() {
        return firmName;
    }

    /**
     * Sets the value of the firmName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFirmName(String value) {
        this.firmName = value;
    }

    /**
     * Gets the value of the caStreet property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCaStreet() {
        return caStreet;
    }

    /**
     * Sets the value of the caStreet property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCaStreet(String value) {
        this.caStreet = value;
    }

    /**
     * Gets the value of the caCity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCaCity() {
        return caCity;
    }

    /**
     * Sets the value of the caCity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCaCity(String value) {
        this.caCity = value;
    }

    /**
     * Gets the value of the caZipCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCaZipCode() {
        return caZipCode;
    }

    /**
     * Sets the value of the caZipCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCaZipCode(String value) {
        this.caZipCode = value;
    }

    /**
     * Gets the value of the caState property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCaState() {
        return caState;
    }

    /**
     * Sets the value of the caState property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCaState(JAXBElement<String> value) {
        this.caState = value;
    }

}
