
package cz.czechpoint.isds.v20;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for tDBCreditInfoOutput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tDBCreditInfoOutput">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="currentCredit" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="notifEmail" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ciRecords" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element name="ciRecord" type="{http://isds.czechpoint.cz/v20}tCiRecord" maxOccurs="unbounded" minOccurs="0"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="dbStatus" type="{http://isds.czechpoint.cz/v20}tDbReqStatus"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tDBCreditInfoOutput", propOrder = {
    "currentCredit",
    "notifEmail",
    "ciRecords",
    "dbStatus"
})
public class TDBCreditInfoOutput {

    protected BigInteger currentCredit;
    @XmlElementRef(name = "notifEmail", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<String> notifEmail;
    protected TDBCreditInfoOutput.CiRecords ciRecords;
    @XmlElement(required = true)
    protected TDbReqStatus dbStatus;

    /**
     * Gets the value of the currentCredit property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCurrentCredit() {
        return currentCredit;
    }

    /**
     * Sets the value of the currentCredit property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCurrentCredit(BigInteger value) {
        this.currentCredit = value;
    }

    /**
     * Gets the value of the notifEmail property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getNotifEmail() {
        return notifEmail;
    }

    /**
     * Sets the value of the notifEmail property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setNotifEmail(JAXBElement<String> value) {
        this.notifEmail = value;
    }

    /**
     * Gets the value of the ciRecords property.
     * 
     * @return
     *     possible object is
     *     {@link TDBCreditInfoOutput.CiRecords }
     *     
     */
    public TDBCreditInfoOutput.CiRecords getCiRecords() {
        return ciRecords;
    }

    /**
     * Sets the value of the ciRecords property.
     * 
     * @param value
     *     allowed object is
     *     {@link TDBCreditInfoOutput.CiRecords }
     *     
     */
    public void setCiRecords(TDBCreditInfoOutput.CiRecords value) {
        this.ciRecords = value;
    }

    /**
     * Gets the value of the dbStatus property.
     * 
     * @return
     *     possible object is
     *     {@link TDbReqStatus }
     *     
     */
    public TDbReqStatus getDbStatus() {
        return dbStatus;
    }

    /**
     * Sets the value of the dbStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link TDbReqStatus }
     *     
     */
    public void setDbStatus(TDbReqStatus value) {
        this.dbStatus = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element name="ciRecord" type="{http://isds.czechpoint.cz/v20}tCiRecord" maxOccurs="unbounded" minOccurs="0"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "ciRecord"
    })
    public static class CiRecords {

        @XmlElement(nillable = true)
        protected List<TCiRecord> ciRecord;

        /**
         * Gets the value of the ciRecord property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the ciRecord property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getCiRecord().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link TCiRecord }
         * 
         * 
         */
        public List<TCiRecord> getCiRecord() {
            if (ciRecord == null) {
                ciRecord = new ArrayList<TCiRecord>();
            }
            return this.ciRecord;
        }

    }

}
