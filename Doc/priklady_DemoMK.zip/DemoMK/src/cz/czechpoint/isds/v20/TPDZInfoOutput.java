
package cz.czechpoint.isds.v20;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for tPDZInfoOutput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tPDZInfoOutput">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="dbPDZRecords" type="{http://isds.czechpoint.cz/v20}tPDZRecArray" minOccurs="0"/>
 *         &lt;element name="dbStatus" type="{http://isds.czechpoint.cz/v20}tDbReqStatus"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tPDZInfoOutput", propOrder = {
    "dbPDZRecords",
    "dbStatus"
})
public class TPDZInfoOutput {

    protected TPDZRecArray dbPDZRecords;
    @XmlElement(required = true)
    protected TDbReqStatus dbStatus;

    /**
     * Gets the value of the dbPDZRecords property.
     * 
     * @return
     *     possible object is
     *     {@link TPDZRecArray }
     *     
     */
    public TPDZRecArray getDbPDZRecords() {
        return dbPDZRecords;
    }

    /**
     * Sets the value of the dbPDZRecords property.
     * 
     * @param value
     *     allowed object is
     *     {@link TPDZRecArray }
     *     
     */
    public void setDbPDZRecords(TPDZRecArray value) {
        this.dbPDZRecords = value;
    }

    /**
     * Gets the value of the dbStatus property.
     * 
     * @return
     *     possible object is
     *     {@link TDbReqStatus }
     *     
     */
    public TDbReqStatus getDbStatus() {
        return dbStatus;
    }

    /**
     * Sets the value of the dbStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link TDbReqStatus }
     *     
     */
    public void setDbStatus(TDbReqStatus value) {
        this.dbStatus = value;
    }

}
