
package cz.czechpoint.isds.v20;

import java.math.BigInteger;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for tDTInfoOutput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tDTInfoOutput">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ActDTType" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" minOccurs="0"/>
 *         &lt;element name="ActDTCapacity" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" minOccurs="0"/>
 *         &lt;element name="ActDTFrom" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="ActDTTo" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="ActDTCapUsed" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" minOccurs="0"/>
 *         &lt;element name="FutDTType" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" minOccurs="0"/>
 *         &lt;element name="FutDTCapacity" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" minOccurs="0"/>
 *         &lt;element name="FutDTFrom" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="FutDTTo" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="FutDTPaid" type="{http://www.w3.org/2001/XMLSchema}nonNegativeInteger" minOccurs="0"/>
 *         &lt;element name="dbStatus" type="{http://isds.czechpoint.cz/v20}tDbReqStatus"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tDTInfoOutput", propOrder = {
    "actDTType",
    "actDTCapacity",
    "actDTFrom",
    "actDTTo",
    "actDTCapUsed",
    "futDTType",
    "futDTCapacity",
    "futDTFrom",
    "futDTTo",
    "futDTPaid",
    "dbStatus"
})
public class TDTInfoOutput {

    @XmlElement(name = "ActDTType")
    @XmlSchemaType(name = "nonNegativeInteger")
    protected BigInteger actDTType;
    @XmlElementRef(name = "ActDTCapacity", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<BigInteger> actDTCapacity;
    @XmlElementRef(name = "ActDTFrom", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> actDTFrom;
    @XmlElementRef(name = "ActDTTo", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> actDTTo;
    @XmlElementRef(name = "ActDTCapUsed", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<BigInteger> actDTCapUsed;
    @XmlElement(name = "FutDTType")
    @XmlSchemaType(name = "nonNegativeInteger")
    protected BigInteger futDTType;
    @XmlElementRef(name = "FutDTCapacity", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<BigInteger> futDTCapacity;
    @XmlElementRef(name = "FutDTFrom", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> futDTFrom;
    @XmlElementRef(name = "FutDTTo", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<XMLGregorianCalendar> futDTTo;
    @XmlElementRef(name = "FutDTPaid", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<BigInteger> futDTPaid;
    @XmlElement(required = true)
    protected TDbReqStatus dbStatus;

    /**
     * Gets the value of the actDTType property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getActDTType() {
        return actDTType;
    }

    /**
     * Sets the value of the actDTType property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setActDTType(BigInteger value) {
        this.actDTType = value;
    }

    /**
     * Gets the value of the actDTCapacity property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigInteger }{@code >}
     *     
     */
    public JAXBElement<BigInteger> getActDTCapacity() {
        return actDTCapacity;
    }

    /**
     * Sets the value of the actDTCapacity property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigInteger }{@code >}
     *     
     */
    public void setActDTCapacity(JAXBElement<BigInteger> value) {
        this.actDTCapacity = value;
    }

    /**
     * Gets the value of the actDTFrom property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getActDTFrom() {
        return actDTFrom;
    }

    /**
     * Sets the value of the actDTFrom property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setActDTFrom(JAXBElement<XMLGregorianCalendar> value) {
        this.actDTFrom = value;
    }

    /**
     * Gets the value of the actDTTo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getActDTTo() {
        return actDTTo;
    }

    /**
     * Sets the value of the actDTTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setActDTTo(JAXBElement<XMLGregorianCalendar> value) {
        this.actDTTo = value;
    }

    /**
     * Gets the value of the actDTCapUsed property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigInteger }{@code >}
     *     
     */
    public JAXBElement<BigInteger> getActDTCapUsed() {
        return actDTCapUsed;
    }

    /**
     * Sets the value of the actDTCapUsed property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigInteger }{@code >}
     *     
     */
    public void setActDTCapUsed(JAXBElement<BigInteger> value) {
        this.actDTCapUsed = value;
    }

    /**
     * Gets the value of the futDTType property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getFutDTType() {
        return futDTType;
    }

    /**
     * Sets the value of the futDTType property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setFutDTType(BigInteger value) {
        this.futDTType = value;
    }

    /**
     * Gets the value of the futDTCapacity property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigInteger }{@code >}
     *     
     */
    public JAXBElement<BigInteger> getFutDTCapacity() {
        return futDTCapacity;
    }

    /**
     * Sets the value of the futDTCapacity property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigInteger }{@code >}
     *     
     */
    public void setFutDTCapacity(JAXBElement<BigInteger> value) {
        this.futDTCapacity = value;
    }

    /**
     * Gets the value of the futDTFrom property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getFutDTFrom() {
        return futDTFrom;
    }

    /**
     * Sets the value of the futDTFrom property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setFutDTFrom(JAXBElement<XMLGregorianCalendar> value) {
        this.futDTFrom = value;
    }

    /**
     * Gets the value of the futDTTo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public JAXBElement<XMLGregorianCalendar> getFutDTTo() {
        return futDTTo;
    }

    /**
     * Sets the value of the futDTTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}
     *     
     */
    public void setFutDTTo(JAXBElement<XMLGregorianCalendar> value) {
        this.futDTTo = value;
    }

    /**
     * Gets the value of the futDTPaid property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BigInteger }{@code >}
     *     
     */
    public JAXBElement<BigInteger> getFutDTPaid() {
        return futDTPaid;
    }

    /**
     * Sets the value of the futDTPaid property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BigInteger }{@code >}
     *     
     */
    public void setFutDTPaid(JAXBElement<BigInteger> value) {
        this.futDTPaid = value;
    }

    /**
     * Gets the value of the dbStatus property.
     * 
     * @return
     *     possible object is
     *     {@link TDbReqStatus }
     *     
     */
    public TDbReqStatus getDbStatus() {
        return dbStatus;
    }

    /**
     * Sets the value of the dbStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link TDbReqStatus }
     *     
     */
    public void setDbStatus(TDbReqStatus value) {
        this.dbStatus = value;
    }

}
