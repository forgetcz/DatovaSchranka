
package cz.czechpoint.isds.v20;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * návratový typ WS
 * 
 * <p>Java class for tDbReqStatus complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tDbReqStatus">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;group ref="{http://isds.czechpoint.cz/v20}gDbReqStatus"/>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tDbReqStatus", propOrder = {
    "dbStatusCode",
    "dbStatusMessage",
    "dbStatusRefNumber"
})
public class TDbReqStatus {

    @XmlElement(required = true)
    protected String dbStatusCode;
    @XmlElement(required = true)
    protected String dbStatusMessage;
    @XmlElementRef(name = "dbStatusRefNumber", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<String> dbStatusRefNumber;

    /**
     * Gets the value of the dbStatusCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbStatusCode() {
        return dbStatusCode;
    }

    /**
     * Sets the value of the dbStatusCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbStatusCode(String value) {
        this.dbStatusCode = value;
    }

    /**
     * Gets the value of the dbStatusMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbStatusMessage() {
        return dbStatusMessage;
    }

    /**
     * Sets the value of the dbStatusMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbStatusMessage(String value) {
        this.dbStatusMessage = value;
    }

    /**
     * Gets the value of the dbStatusRefNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDbStatusRefNumber() {
        return dbStatusRefNumber;
    }

    /**
     * Sets the value of the dbStatusRefNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDbStatusRefNumber(JAXBElement<String> value) {
        this.dbStatusRefNumber = value;
    }

}
