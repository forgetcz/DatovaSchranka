
package cz.czechpoint.isds.v20;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for tAddDBUserInput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tAddDBUserInput">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="dbOwnerInfo" type="{http://isds.czechpoint.cz/v20}tDbOwnerInfoExt"/>
 *         &lt;element name="dbUserInfo">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;extension base="{http://isds.czechpoint.cz/v20}tDbUserInfoExt">
 *                 &lt;attribute name="AIFOTicket" type="{http://www.w3.org/2001/XMLSchema}string" />
 *               &lt;/extension>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="dbVirtual" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="email" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;group ref="{http://isds.czechpoint.cz/v20}gExtApproval"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tAddDBUserInput", propOrder = {
    "dbOwnerInfo",
    "dbUserInfo",
    "dbVirtual",
    "email",
    "dbApproved",
    "dbExternRefNumber"
})
public class TAddDBUserInput {

    @XmlElement(required = true)
    protected TDbOwnerInfoExt dbOwnerInfo;
    @XmlElement(required = true)
    protected TAddDBUserInput.DbUserInfo dbUserInfo;
    protected Boolean dbVirtual;
    @XmlElementRef(name = "email", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<String> email;
    @XmlElementRef(name = "dbApproved", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<Boolean> dbApproved;
    @XmlElementRef(name = "dbExternRefNumber", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<String> dbExternRefNumber;

    /**
     * Gets the value of the dbOwnerInfo property.
     * 
     * @return
     *     possible object is
     *     {@link TDbOwnerInfoExt }
     *     
     */
    public TDbOwnerInfoExt getDbOwnerInfo() {
        return dbOwnerInfo;
    }

    /**
     * Sets the value of the dbOwnerInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link TDbOwnerInfoExt }
     *     
     */
    public void setDbOwnerInfo(TDbOwnerInfoExt value) {
        this.dbOwnerInfo = value;
    }

    /**
     * Gets the value of the dbUserInfo property.
     * 
     * @return
     *     possible object is
     *     {@link TAddDBUserInput.DbUserInfo }
     *     
     */
    public TAddDBUserInput.DbUserInfo getDbUserInfo() {
        return dbUserInfo;
    }

    /**
     * Sets the value of the dbUserInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link TAddDBUserInput.DbUserInfo }
     *     
     */
    public void setDbUserInfo(TAddDBUserInput.DbUserInfo value) {
        this.dbUserInfo = value;
    }

    /**
     * Gets the value of the dbVirtual property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDbVirtual() {
        return dbVirtual;
    }

    /**
     * Sets the value of the dbVirtual property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDbVirtual(Boolean value) {
        this.dbVirtual = value;
    }

    /**
     * Gets the value of the email property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getEmail() {
        return email;
    }

    /**
     * Sets the value of the email property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setEmail(JAXBElement<String> value) {
        this.email = value;
    }

    /**
     * Gets the value of the dbApproved property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public JAXBElement<Boolean> getDbApproved() {
        return dbApproved;
    }

    /**
     * Sets the value of the dbApproved property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public void setDbApproved(JAXBElement<Boolean> value) {
        this.dbApproved = value;
    }

    /**
     * Gets the value of the dbExternRefNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDbExternRefNumber() {
        return dbExternRefNumber;
    }

    /**
     * Sets the value of the dbExternRefNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDbExternRefNumber(JAXBElement<String> value) {
        this.dbExternRefNumber = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;extension base="{http://isds.czechpoint.cz/v20}tDbUserInfoExt">
     *       &lt;attribute name="AIFOTicket" type="{http://www.w3.org/2001/XMLSchema}string" />
     *     &lt;/extension>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class DbUserInfo
        extends TDbUserInfoExt
    {

        @XmlAttribute(name = "AIFOTicket")
        protected String aifoTicket;

        /**
         * Gets the value of the aifoTicket property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getAIFOTicket() {
            return aifoTicket;
        }

        /**
         * Sets the value of the aifoTicket property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setAIFOTicket(String value) {
            this.aifoTicket = value;
        }

    }

}
