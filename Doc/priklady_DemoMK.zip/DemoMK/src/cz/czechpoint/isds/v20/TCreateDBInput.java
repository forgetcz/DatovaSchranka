
package cz.czechpoint.isds.v20;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for tCreateDBInput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tCreateDBInput">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="dbOwnerInfo">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;extension base="{http://isds.czechpoint.cz/v20}tDbOwnerInfoExt">
 *                 &lt;attribute name="guid" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="formdataid" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="identityDocumentNum" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="identityDocumentType" type="{http://www.w3.org/2001/XMLSchema}string" />
 *                 &lt;attribute name="PDZ">
 *                   &lt;simpleType>
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *                       &lt;maxLength value="1"/>
 *                       &lt;minLength value="1"/>
 *                     &lt;/restriction>
 *                   &lt;/simpleType>
 *                 &lt;/attribute>
 *               &lt;/extension>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="dbPrimaryUsers" type="{http://isds.czechpoint.cz/v20}tDbUsersArray"/>
 *         &lt;element name="dbFormerNames" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dbUpperDBId" type="{http://isds.czechpoint.cz/v20}tIdDb" minOccurs="0"/>
 *         &lt;element name="dbCEOLabel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dbVirtual" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="email" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;group ref="{http://isds.czechpoint.cz/v20}gExtApproval"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tCreateDBInput", propOrder = {
    "dbOwnerInfo",
    "dbPrimaryUsers",
    "dbFormerNames",
    "dbUpperDBId",
    "dbCEOLabel",
    "dbVirtual",
    "email",
    "dbApproved",
    "dbExternRefNumber"
})
public class TCreateDBInput {

    @XmlElement(required = true)
    protected TCreateDBInput.DbOwnerInfo dbOwnerInfo;
    @XmlElement(required = true)
    protected TDbUsersArray dbPrimaryUsers;
    @XmlElementRef(name = "dbFormerNames", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<String> dbFormerNames;
    @XmlElementRef(name = "dbUpperDBId", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<String> dbUpperDBId;
    @XmlElementRef(name = "dbCEOLabel", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<String> dbCEOLabel;
    @XmlElementRef(name = "dbVirtual", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<Boolean> dbVirtual;
    @XmlElementRef(name = "email", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<String> email;
    @XmlElementRef(name = "dbApproved", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<Boolean> dbApproved;
    @XmlElementRef(name = "dbExternRefNumber", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<String> dbExternRefNumber;

    /**
     * Gets the value of the dbOwnerInfo property.
     * 
     * @return
     *     possible object is
     *     {@link TCreateDBInput.DbOwnerInfo }
     *     
     */
    public TCreateDBInput.DbOwnerInfo getDbOwnerInfo() {
        return dbOwnerInfo;
    }

    /**
     * Sets the value of the dbOwnerInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link TCreateDBInput.DbOwnerInfo }
     *     
     */
    public void setDbOwnerInfo(TCreateDBInput.DbOwnerInfo value) {
        this.dbOwnerInfo = value;
    }

    /**
     * Gets the value of the dbPrimaryUsers property.
     * 
     * @return
     *     possible object is
     *     {@link TDbUsersArray }
     *     
     */
    public TDbUsersArray getDbPrimaryUsers() {
        return dbPrimaryUsers;
    }

    /**
     * Sets the value of the dbPrimaryUsers property.
     * 
     * @param value
     *     allowed object is
     *     {@link TDbUsersArray }
     *     
     */
    public void setDbPrimaryUsers(TDbUsersArray value) {
        this.dbPrimaryUsers = value;
    }

    /**
     * Gets the value of the dbFormerNames property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDbFormerNames() {
        return dbFormerNames;
    }

    /**
     * Sets the value of the dbFormerNames property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDbFormerNames(JAXBElement<String> value) {
        this.dbFormerNames = value;
    }

    /**
     * Gets the value of the dbUpperDBId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDbUpperDBId() {
        return dbUpperDBId;
    }

    /**
     * Sets the value of the dbUpperDBId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDbUpperDBId(JAXBElement<String> value) {
        this.dbUpperDBId = value;
    }

    /**
     * Gets the value of the dbCEOLabel property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDbCEOLabel() {
        return dbCEOLabel;
    }

    /**
     * Sets the value of the dbCEOLabel property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDbCEOLabel(JAXBElement<String> value) {
        this.dbCEOLabel = value;
    }

    /**
     * Gets the value of the dbVirtual property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public JAXBElement<Boolean> getDbVirtual() {
        return dbVirtual;
    }

    /**
     * Sets the value of the dbVirtual property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public void setDbVirtual(JAXBElement<Boolean> value) {
        this.dbVirtual = value;
    }

    /**
     * Gets the value of the email property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getEmail() {
        return email;
    }

    /**
     * Sets the value of the email property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setEmail(JAXBElement<String> value) {
        this.email = value;
    }

    /**
     * Gets the value of the dbApproved property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public JAXBElement<Boolean> getDbApproved() {
        return dbApproved;
    }

    /**
     * Sets the value of the dbApproved property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public void setDbApproved(JAXBElement<Boolean> value) {
        this.dbApproved = value;
    }

    /**
     * Gets the value of the dbExternRefNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDbExternRefNumber() {
        return dbExternRefNumber;
    }

    /**
     * Sets the value of the dbExternRefNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDbExternRefNumber(JAXBElement<String> value) {
        this.dbExternRefNumber = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;extension base="{http://isds.czechpoint.cz/v20}tDbOwnerInfoExt">
     *       &lt;attribute name="guid" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="formdataid" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="identityDocumentNum" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="identityDocumentType" type="{http://www.w3.org/2001/XMLSchema}string" />
     *       &lt;attribute name="PDZ">
     *         &lt;simpleType>
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
     *             &lt;maxLength value="1"/>
     *             &lt;minLength value="1"/>
     *           &lt;/restriction>
     *         &lt;/simpleType>
     *       &lt;/attribute>
     *     &lt;/extension>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class DbOwnerInfo
        extends TDbOwnerInfoExt
    {

        @XmlAttribute(name = "guid")
        protected String guid;
        @XmlAttribute(name = "formdataid")
        protected String formdataid;
        @XmlAttribute(name = "identityDocumentNum")
        protected String identityDocumentNum;
        @XmlAttribute(name = "identityDocumentType")
        protected String identityDocumentType;
        @XmlAttribute(name = "PDZ")
        protected String pdz;

        /**
         * Gets the value of the guid property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getGuid() {
            return guid;
        }

        /**
         * Sets the value of the guid property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setGuid(String value) {
            this.guid = value;
        }

        /**
         * Gets the value of the formdataid property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getFormdataid() {
            return formdataid;
        }

        /**
         * Sets the value of the formdataid property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setFormdataid(String value) {
            this.formdataid = value;
        }

        /**
         * Gets the value of the identityDocumentNum property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getIdentityDocumentNum() {
            return identityDocumentNum;
        }

        /**
         * Sets the value of the identityDocumentNum property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setIdentityDocumentNum(String value) {
            this.identityDocumentNum = value;
        }

        /**
         * Gets the value of the identityDocumentType property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getIdentityDocumentType() {
            return identityDocumentType;
        }

        /**
         * Sets the value of the identityDocumentType property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setIdentityDocumentType(String value) {
            this.identityDocumentType = value;
        }

        /**
         * Gets the value of the pdz property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPDZ() {
            return pdz;
        }

        /**
         * Sets the value of the pdz property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPDZ(String value) {
            this.pdz = value;
        }

    }

}
