
package cz.czechpoint.isds.v20;

import java.math.BigInteger;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for tISDSSearchInput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tISDSSearchInput">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="searchText" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="searchType">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="GENERAL"/>
 *               &lt;enumeration value="ADDRESS"/>
 *               &lt;enumeration value="ICO"/>
 *               &lt;enumeration value="DBID"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="searchScope">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="ALL"/>
 *               &lt;enumeration value="OVM"/>
 *               &lt;enumeration value="OVM_MAIN"/>
 *               &lt;enumeration value="OVM_REQ"/>
 *               &lt;enumeration value="OVM_NOTAR"/>
 *               &lt;enumeration value="OVM_EXEKUT"/>
 *               &lt;enumeration value="OVM_FO"/>
 *               &lt;enumeration value="OVM_PFO"/>
 *               &lt;enumeration value="OVM_PO"/>
 *               &lt;enumeration value="PO"/>
 *               &lt;enumeration value="PO_ZAK"/>
 *               &lt;enumeration value="PO_REQ"/>
 *               &lt;enumeration value="PFO"/>
 *               &lt;enumeration value="PFO_ADVOK"/>
 *               &lt;enumeration value="PFO_INSSPR"/>
 *               &lt;enumeration value="PFO_DANPOR"/>
 *               &lt;enumeration value="PFO_AUDITOR"/>
 *               &lt;enumeration value="FO"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="page" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *         &lt;element name="pageSize" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *         &lt;element name="highlighting" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tISDSSearchInput", propOrder = {
    "searchText",
    "searchType",
    "searchScope",
    "page",
    "pageSize",
    "highlighting"
})
public class TISDSSearchInput {

    @XmlElement(required = true)
    protected String searchText;
    @XmlElement(required = true, nillable = true)
    protected String searchType;
    @XmlElement(required = true, nillable = true)
    protected String searchScope;
    @XmlElement(required = true, nillable = true)
    protected BigInteger page;
    @XmlElement(required = true, nillable = true)
    protected BigInteger pageSize;
    @XmlElementRef(name = "highlighting", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<Boolean> highlighting;

    /**
     * Gets the value of the searchText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSearchText() {
        return searchText;
    }

    /**
     * Sets the value of the searchText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSearchText(String value) {
        this.searchText = value;
    }

    /**
     * Gets the value of the searchType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSearchType() {
        return searchType;
    }

    /**
     * Sets the value of the searchType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSearchType(String value) {
        this.searchType = value;
    }

    /**
     * Gets the value of the searchScope property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSearchScope() {
        return searchScope;
    }

    /**
     * Sets the value of the searchScope property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSearchScope(String value) {
        this.searchScope = value;
    }

    /**
     * Gets the value of the page property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getPage() {
        return page;
    }

    /**
     * Sets the value of the page property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setPage(BigInteger value) {
        this.page = value;
    }

    /**
     * Gets the value of the pageSize property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getPageSize() {
        return pageSize;
    }

    /**
     * Sets the value of the pageSize property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setPageSize(BigInteger value) {
        this.pageSize = value;
    }

    /**
     * Gets the value of the highlighting property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public JAXBElement<Boolean> getHighlighting() {
        return highlighting;
    }

    /**
     * Sets the value of the highlighting property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     *     
     */
    public void setHighlighting(JAXBElement<Boolean> value) {
        this.highlighting = value;
    }

}
