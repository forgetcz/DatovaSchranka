
package cz.czechpoint.isds.v20;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for tdbPersonalOwnerInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tdbPersonalOwnerInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="dbID" type="{http://isds.czechpoint.cz/v20}tIdDb"/>
 *         &lt;element name="aifoIsds" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="pnFirstName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="pnMiddleName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="pnLastName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="biDate" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="biCity" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="biCounty" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="biState" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="adCode" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *         &lt;element name="adCity" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="adDistrict" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="adStreet" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="adNumberInStreet" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="adNumberInMunicipality" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="adZipCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="adState" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="nationality" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tdbPersonalOwnerInfo", propOrder = {
    "dbID",
    "aifoIsds",
    "pnFirstName",
    "pnMiddleName",
    "pnLastName",
    "biDate",
    "biCity",
    "biCounty",
    "biState",
    "adCode",
    "adCity",
    "adDistrict",
    "adStreet",
    "adNumberInStreet",
    "adNumberInMunicipality",
    "adZipCode",
    "adState",
    "nationality"
})
public class TdbPersonalOwnerInfo {

    @XmlElement(required = true, nillable = true)
    protected String dbID;
    @XmlElement(required = true, type = Boolean.class, nillable = true)
    protected Boolean aifoIsds;
    @XmlElement(required = true, nillable = true)
    protected String pnFirstName;
    @XmlElement(required = true, nillable = true)
    protected String pnMiddleName;
    @XmlElement(required = true, nillable = true)
    protected String pnLastName;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar biDate;
    @XmlElement(required = true, nillable = true)
    protected String biCity;
    @XmlElement(required = true, nillable = true)
    protected String biCounty;
    @XmlElement(required = true, nillable = true)
    protected String biState;
    @XmlElement(required = true, nillable = true)
    protected BigInteger adCode;
    @XmlElement(required = true, nillable = true)
    protected String adCity;
    @XmlElement(required = true, nillable = true)
    protected String adDistrict;
    @XmlElement(required = true, nillable = true)
    protected String adStreet;
    @XmlElement(required = true, nillable = true)
    protected String adNumberInStreet;
    @XmlElement(required = true, nillable = true)
    protected String adNumberInMunicipality;
    @XmlElement(required = true, nillable = true)
    protected String adZipCode;
    @XmlElement(required = true, nillable = true)
    protected String adState;
    @XmlElement(required = true, nillable = true)
    protected String nationality;

    /**
     * Gets the value of the dbID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbID() {
        return dbID;
    }

    /**
     * Sets the value of the dbID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbID(String value) {
        this.dbID = value;
    }

    /**
     * Gets the value of the aifoIsds property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isAifoIsds() {
        return aifoIsds;
    }

    /**
     * Sets the value of the aifoIsds property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setAifoIsds(Boolean value) {
        this.aifoIsds = value;
    }

    /**
     * Gets the value of the pnFirstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPnFirstName() {
        return pnFirstName;
    }

    /**
     * Sets the value of the pnFirstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPnFirstName(String value) {
        this.pnFirstName = value;
    }

    /**
     * Gets the value of the pnMiddleName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPnMiddleName() {
        return pnMiddleName;
    }

    /**
     * Sets the value of the pnMiddleName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPnMiddleName(String value) {
        this.pnMiddleName = value;
    }

    /**
     * Gets the value of the pnLastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPnLastName() {
        return pnLastName;
    }

    /**
     * Sets the value of the pnLastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPnLastName(String value) {
        this.pnLastName = value;
    }

    /**
     * Gets the value of the biDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getBiDate() {
        return biDate;
    }

    /**
     * Sets the value of the biDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setBiDate(XMLGregorianCalendar value) {
        this.biDate = value;
    }

    /**
     * Gets the value of the biCity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBiCity() {
        return biCity;
    }

    /**
     * Sets the value of the biCity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBiCity(String value) {
        this.biCity = value;
    }

    /**
     * Gets the value of the biCounty property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBiCounty() {
        return biCounty;
    }

    /**
     * Sets the value of the biCounty property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBiCounty(String value) {
        this.biCounty = value;
    }

    /**
     * Gets the value of the biState property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBiState() {
        return biState;
    }

    /**
     * Sets the value of the biState property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBiState(String value) {
        this.biState = value;
    }

    /**
     * Gets the value of the adCode property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getAdCode() {
        return adCode;
    }

    /**
     * Sets the value of the adCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setAdCode(BigInteger value) {
        this.adCode = value;
    }

    /**
     * Gets the value of the adCity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdCity() {
        return adCity;
    }

    /**
     * Sets the value of the adCity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdCity(String value) {
        this.adCity = value;
    }

    /**
     * Gets the value of the adDistrict property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdDistrict() {
        return adDistrict;
    }

    /**
     * Sets the value of the adDistrict property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdDistrict(String value) {
        this.adDistrict = value;
    }

    /**
     * Gets the value of the adStreet property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdStreet() {
        return adStreet;
    }

    /**
     * Sets the value of the adStreet property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdStreet(String value) {
        this.adStreet = value;
    }

    /**
     * Gets the value of the adNumberInStreet property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdNumberInStreet() {
        return adNumberInStreet;
    }

    /**
     * Sets the value of the adNumberInStreet property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdNumberInStreet(String value) {
        this.adNumberInStreet = value;
    }

    /**
     * Gets the value of the adNumberInMunicipality property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdNumberInMunicipality() {
        return adNumberInMunicipality;
    }

    /**
     * Sets the value of the adNumberInMunicipality property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdNumberInMunicipality(String value) {
        this.adNumberInMunicipality = value;
    }

    /**
     * Gets the value of the adZipCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdZipCode() {
        return adZipCode;
    }

    /**
     * Sets the value of the adZipCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdZipCode(String value) {
        this.adZipCode = value;
    }

    /**
     * Gets the value of the adState property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdState() {
        return adState;
    }

    /**
     * Sets the value of the adState property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdState(String value) {
        this.adState = value;
    }

    /**
     * Gets the value of the nationality property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNationality() {
        return nationality;
    }

    /**
     * Sets the value of the nationality property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNationality(String value) {
        this.nationality = value;
    }

}
