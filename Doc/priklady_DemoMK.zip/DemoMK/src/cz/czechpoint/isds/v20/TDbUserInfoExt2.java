
package cz.czechpoint.isds.v20;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * typ pro veškeré informace o uživateli schránky verze 3 (2018)
 * 
 * <p>Java class for tDbUserInfoExt2 complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tDbUserInfoExt2">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="aifoIsds" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;group ref="{http://isds.czechpoint.cz/v20}gPersonName2"/>
 *         &lt;group ref="{http://isds.czechpoint.cz/v20}gAddressExt2"/>
 *         &lt;element name="biDate" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="isdsID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="userType" type="{http://isds.czechpoint.cz/v20}tUserType"/>
 *         &lt;element name="userPrivils" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="ic">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="8"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="firmName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="caStreet" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="caCity" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="caZipCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="caState" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tDbUserInfoExt2", propOrder = {
    "aifoIsds",
    "pnGivenNames",
    "pnLastName",
    "adCode",
    "adCity",
    "adDistrict",
    "adStreet",
    "adNumberInStreet",
    "adNumberInMunicipality",
    "adZipCode",
    "adState",
    "biDate",
    "isdsID",
    "userType",
    "userPrivils",
    "ic",
    "firmName",
    "caStreet",
    "caCity",
    "caZipCode",
    "caState"
})
@XmlSeeAlso({
    cz.czechpoint.isds.v20.TAddDBUserInput2 .DbUserInfo.class,
    cz.czechpoint.isds.v20.TDbUsersArray2 .DbUserInfo.class
})
public class TDbUserInfoExt2 {

    protected boolean aifoIsds;
    @XmlElement(required = true, nillable = true)
    protected String pnGivenNames;
    @XmlElement(required = true, nillable = true)
    protected String pnLastName;
    @XmlElement(required = true, nillable = true)
    protected String adCode;
    @XmlElement(required = true, nillable = true)
    protected String adCity;
    @XmlElement(required = true, nillable = true)
    protected String adDistrict;
    @XmlElement(required = true, nillable = true)
    protected String adStreet;
    @XmlElement(required = true, nillable = true)
    protected String adNumberInStreet;
    @XmlElement(required = true, nillable = true)
    protected String adNumberInMunicipality;
    @XmlElement(required = true, nillable = true)
    protected String adZipCode;
    @XmlElement(required = true, nillable = true)
    protected String adState;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar biDate;
    @XmlElement(required = true, nillable = true)
    protected String isdsID;
    @XmlElement(required = true, nillable = true)
    @XmlSchemaType(name = "string")
    protected TUserType userType;
    @XmlElement(required = true, type = Long.class, nillable = true)
    protected Long userPrivils;
    @XmlElement(required = true, nillable = true)
    protected String ic;
    @XmlElement(required = true, nillable = true)
    protected String firmName;
    @XmlElement(required = true, nillable = true)
    protected String caStreet;
    @XmlElement(required = true, nillable = true)
    protected String caCity;
    @XmlElement(required = true, nillable = true)
    protected String caZipCode;
    @XmlElementRef(name = "caState", namespace = "http://isds.czechpoint.cz/v20", type = JAXBElement.class, required = false)
    protected JAXBElement<String> caState;

    /**
     * Gets the value of the aifoIsds property.
     * 
     */
    public boolean isAifoIsds() {
        return aifoIsds;
    }

    /**
     * Sets the value of the aifoIsds property.
     * 
     */
    public void setAifoIsds(boolean value) {
        this.aifoIsds = value;
    }

    /**
     * Gets the value of the pnGivenNames property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPnGivenNames() {
        return pnGivenNames;
    }

    /**
     * Sets the value of the pnGivenNames property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPnGivenNames(String value) {
        this.pnGivenNames = value;
    }

    /**
     * Gets the value of the pnLastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPnLastName() {
        return pnLastName;
    }

    /**
     * Sets the value of the pnLastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPnLastName(String value) {
        this.pnLastName = value;
    }

    /**
     * Gets the value of the adCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdCode() {
        return adCode;
    }

    /**
     * Sets the value of the adCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdCode(String value) {
        this.adCode = value;
    }

    /**
     * Gets the value of the adCity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdCity() {
        return adCity;
    }

    /**
     * Sets the value of the adCity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdCity(String value) {
        this.adCity = value;
    }

    /**
     * Gets the value of the adDistrict property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdDistrict() {
        return adDistrict;
    }

    /**
     * Sets the value of the adDistrict property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdDistrict(String value) {
        this.adDistrict = value;
    }

    /**
     * Gets the value of the adStreet property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdStreet() {
        return adStreet;
    }

    /**
     * Sets the value of the adStreet property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdStreet(String value) {
        this.adStreet = value;
    }

    /**
     * Gets the value of the adNumberInStreet property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdNumberInStreet() {
        return adNumberInStreet;
    }

    /**
     * Sets the value of the adNumberInStreet property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdNumberInStreet(String value) {
        this.adNumberInStreet = value;
    }

    /**
     * Gets the value of the adNumberInMunicipality property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdNumberInMunicipality() {
        return adNumberInMunicipality;
    }

    /**
     * Sets the value of the adNumberInMunicipality property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdNumberInMunicipality(String value) {
        this.adNumberInMunicipality = value;
    }

    /**
     * Gets the value of the adZipCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdZipCode() {
        return adZipCode;
    }

    /**
     * Sets the value of the adZipCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdZipCode(String value) {
        this.adZipCode = value;
    }

    /**
     * Gets the value of the adState property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdState() {
        return adState;
    }

    /**
     * Sets the value of the adState property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdState(String value) {
        this.adState = value;
    }

    /**
     * Gets the value of the biDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getBiDate() {
        return biDate;
    }

    /**
     * Sets the value of the biDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setBiDate(XMLGregorianCalendar value) {
        this.biDate = value;
    }

    /**
     * Gets the value of the isdsID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsdsID() {
        return isdsID;
    }

    /**
     * Sets the value of the isdsID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsdsID(String value) {
        this.isdsID = value;
    }

    /**
     * Gets the value of the userType property.
     * 
     * @return
     *     possible object is
     *     {@link TUserType }
     *     
     */
    public TUserType getUserType() {
        return userType;
    }

    /**
     * Sets the value of the userType property.
     * 
     * @param value
     *     allowed object is
     *     {@link TUserType }
     *     
     */
    public void setUserType(TUserType value) {
        this.userType = value;
    }

    /**
     * Gets the value of the userPrivils property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getUserPrivils() {
        return userPrivils;
    }

    /**
     * Sets the value of the userPrivils property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setUserPrivils(Long value) {
        this.userPrivils = value;
    }

    /**
     * Gets the value of the ic property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIc() {
        return ic;
    }

    /**
     * Sets the value of the ic property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIc(String value) {
        this.ic = value;
    }

    /**
     * Gets the value of the firmName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFirmName() {
        return firmName;
    }

    /**
     * Sets the value of the firmName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFirmName(String value) {
        this.firmName = value;
    }

    /**
     * Gets the value of the caStreet property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCaStreet() {
        return caStreet;
    }

    /**
     * Sets the value of the caStreet property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCaStreet(String value) {
        this.caStreet = value;
    }

    /**
     * Gets the value of the caCity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCaCity() {
        return caCity;
    }

    /**
     * Sets the value of the caCity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCaCity(String value) {
        this.caCity = value;
    }

    /**
     * Gets the value of the caZipCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCaZipCode() {
        return caZipCode;
    }

    /**
     * Sets the value of the caZipCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCaZipCode(String value) {
        this.caZipCode = value;
    }

    /**
     * Gets the value of the caState property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCaState() {
        return caState;
    }

    /**
     * Sets the value of the caState property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCaState(JAXBElement<String> value) {
        this.caState = value;
    }

}
