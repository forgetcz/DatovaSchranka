
package cz.czechpoint.isds.v20;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for tDbType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="tDbType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="FO"/>
 *     &lt;enumeration value="PFO"/>
 *     &lt;enumeration value="PFO_ADVOK"/>
 *     &lt;enumeration value="PFO_DANPOR"/>
 *     &lt;enumeration value="PFO_INSSPR"/>
 *     &lt;enumeration value="PFO_AUDITOR"/>
 *     &lt;enumeration value="PO"/>
 *     &lt;enumeration value="PO_ZAK"/>
 *     &lt;enumeration value="PO_REQ"/>
 *     &lt;enumeration value="OVM"/>
 *     &lt;enumeration value="OVM_NOTAR"/>
 *     &lt;enumeration value="OVM_EXEKUT"/>
 *     &lt;enumeration value="OVM_REQ"/>
 *     &lt;enumeration value="OVM_FO"/>
 *     &lt;enumeration value="OVM_PFO"/>
 *     &lt;enumeration value="OVM_PO"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "tDbType")
@XmlEnum
public enum TDbType {

    FO,
    PFO,
    PFO_ADVOK,
    PFO_DANPOR,
    PFO_INSSPR,
    PFO_AUDITOR,
    PO,
    PO_ZAK,
    PO_REQ,
    OVM,
    OVM_NOTAR,
    OVM_EXEKUT,
    OVM_REQ,
    OVM_FO,
    OVM_PFO,
    OVM_PO;

    public String value() {
        return name();
    }

    public static TDbType fromValue(String v) {
        return valueOf(v);
    }

}
