package demomk;

/**
 * Trida obsahujici naparsovane informace o jedne http cookie.
 */
public class Cookie {

  private String name = "";
  private String value = "";
  private String domain = "";
  private String path = "/";
  private Boolean secure = false;
  //expires ignored

  /**
   * Naparsuje cookie z obsahu http hlavicky Set-Cookie
   *
   * @param cookieHeaderValue obsah http hlavicky.
   */
  public Cookie(String cookieHeaderValue) {
    String[] headerParts = cookieHeaderValue.split(";");
    if (headerParts.length > 0) {
      headerParts[0] = headerParts[0].trim();
      String[] cookieParts = headerParts[0].split("=");
      if (cookieParts.length > 0) {
        this.name = cookieParts[0];
      }
      if (cookieParts.length > 1) {
        value = cookieParts[1];
      }
    }
    for (int i = 1; i < headerParts.length; i++) {
      headerParts[i] = headerParts[i].trim();
      String partInLowerCase = headerParts[i].toLowerCase();
      if (partInLowerCase.startsWith("domain")) {
        this.domain = headerParts[i].substring("domain=".length());
      } else if (partInLowerCase.startsWith("path")) {
        this.path = headerParts[i].substring("path=".length());
      } else if (partInLowerCase.startsWith("secure")) {
        this.secure = true;
      }
    }
  }

  /**
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * @return the value
   */
  public String getValue() {
    return value;
  }

  /**
   * @return the domain
   */
  public String getDomain() {
    return domain;
  }

  /**
   * @return the path
   */
  public String getPath() {
    return path;
  }

  /**
   * @return the secure
   */
  public Boolean getSecure() {
    return secure;
  }

  /**
   * Returns true jestlize jsou cookies "stejne". Stejny objekt, nebo stejne
   * jmeno, domena a cesta.
   *
   * @param cookieToCompare
   * @return
   */
  public boolean canBeRewrited(Cookie cookieToCompare) {
    return (cookieToCompare == this) || (this.name.compareToIgnoreCase(cookieToCompare.getName()) == 0
            && this.domain.compareToIgnoreCase(cookieToCompare.getDomain()) == 0
            && this.path.compareToIgnoreCase(cookieToCompare.getPath()) == 0);
  }
}
