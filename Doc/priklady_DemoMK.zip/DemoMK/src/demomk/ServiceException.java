package demomk;

/**
 * Vyjimka, kterou mohou generovat tridy z tohoto prikladu
 */
public class ServiceException extends Exception {

  public ServiceException(String message) {
    super(message);
  }
}
