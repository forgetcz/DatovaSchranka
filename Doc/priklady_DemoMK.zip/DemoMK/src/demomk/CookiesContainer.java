package demomk;

import java.net.URL;
import java.util.ArrayList;

/**
 * Trida obsahuje seznam cookie a umi generovat pro dane url spravne cookie
 * hlavicky.
 */
public class CookiesContainer {

  private ArrayList<Cookie> list = new ArrayList<>();

  /**
   * Prida cookie do seznamu.
   *
   * @param addingCookie pridavana cookie.
   */
  public void addCookie(Cookie addingCookie) {
    for (int i = 0; i < list.size(); i++) {
      Cookie cookieInList = list.get(i);
      // prepis hodnotu e
      if (cookieInList.canBeRewrited(addingCookie)) {
        list.set(i, addingCookie);
        return;
      }
    }
    list.add(list.size(), addingCookie);
  }

  /**
   * Vrati cookie s prefixem jmena.
   *
   * @param nameprefix prefix jmena.
   * @return cookie
   */
  public Cookie getCookie(String nameprefix) {
    return list.stream().filter(cookie -> cookie.getName().startsWith(nameprefix)).findFirst().orElse(null);
  }

  /**
   * Vrati cookie oddelene strednikem, ktere jsou platne pro danou url.
   *
   * @param url dana url.
   * @return retezec s cookiesString.
   */
  public String getCookieHeaderValueForUrl(URL url) {
    String cookiesString = "";
    String host = url.getHost().toLowerCase();
    String path = url.getPath().toLowerCase();
    Boolean isHttps = url.getProtocol().equalsIgnoreCase("https");

    for (int i = 0; i < list.size(); i++) {
      Cookie cookie = list.get(i);
      if ( // nesplnuje podminku na domenu
              (cookie.getDomain().length() > 0 && !host.endsWith(cookie.getDomain().toLowerCase()))
              || // nesplnuje podminku na cestu
              (!path.startsWith(cookie.getPath().toLowerCase()))
              || //cookie jen pro https
              (cookie.getSecure() && !isHttps)) {
        continue;
      }

      if (cookiesString.length() > 0) {
        cookiesString += "; ";
      }
      cookiesString += cookie.getName() + "=" + cookie.getValue();
    }
    return (cookiesString.length() == 0) ? null : cookiesString;
  }
}
