package demomk;

import java.io.Console;

/**
 * Trida pro uchovani uzivatelskeho jmena a hesla
 */
public class Credentials {

  private String login = "";
  private String applicationName = "";
  /**
   * Komunikacni kod - lze nalezt/vygenerovat na portale nastaveni/moznosti
   * prihlaseni/Prihlaseni mobilnim klicem/prihlasovani ostatnich aplikaci
   * (uplne dole)
   */
  private String MKtoken = "";

  /**
   * @return the login
   */
  public String getLogin() {
    return login;
  }

  /**
   * @return the applicationName
   */
  public String getPassword() {
    return getApplicationName();
  }

  public void readCredentials() {
    System.out.println("\r\nTohle je priklad nacteni prihlasovacich udaju. "
            + "Ulozeni jmena ci jinych pristupoivach udaju primo ve zdrojovem kodu aplikace neni bezpecne.\r\n");

    Console console = System.console();
    if (console == null) {
      throw new Error("Toto nacteni udaju funguje jen pri spusteni programu "
              + "v prikazovem radku (cmd.exe, bash).\r\n");
    }

    setApplicationName(console.readLine("Zadejte jmeno aplikace: "));
    setLogin(console.readLine("Zadejte uzivatelske jmeno: "));
    setMKtoken(console.readLine("Zadejte komunikacni kod: "));

  }

  /**
   * @return the MKtoken
   */
  public String getMKtoken() {
    return MKtoken;
  }

  /**
   * @param login the login to set
   */
  public void setLogin(String login) {
    this.login = login;
  }

  /**
   * @param MKtoken the MKtoken to set
   */
  public void setMKtoken(String MKtoken) {
    this.MKtoken = MKtoken;
  }

  /**
   * @return the applicationName
   */
  public String getApplicationName() {
    return applicationName;
  }

  /**
   * @param applicationName the applicationName to set
   */
  public void setApplicationName(String applicationName) {
    this.applicationName = applicationName;
  }
}
