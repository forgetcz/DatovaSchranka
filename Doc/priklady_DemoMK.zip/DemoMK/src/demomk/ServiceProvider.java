package demomk;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URISyntaxException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.*;
import java.util.List;
import javax.net.ssl.HttpsURLConnection;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.MessageContext;

public class ServiceProvider {

  private final int MAX_REDIRECT_CNT = 20;
  // timeout cookie, po nem je treba znovu cookie ziskat. Nastaven na 30 minut
  private static final int COOKIE_TIMEOUT_MS = 30 * 60 * 1000;
  private String reqBaseURI = null;
  private static final String MK_LOGIN_URL_PART = "/as/processLogin?type=mep-ws&applicationName=";
  // kontejner pro cookie ziskane pri prihlasovani
  private CookiesContainer cookiesContainer = new CookiesContainer();
  // auth. cookie
  private String authCookie = null;
  private Date authCookieTime = null;

  /**
   * Hodnoty, kterych muze nabyvat stav pozadavku na MK autentizaci.
   */
  private static final Map<String, String> STATE_DESCRIPTION = Collections.unmodifiableMap(new HashMap<String, String>() {
    {
      put("-1", "Nerozpoznany");
      put("1", "Ceka na potvrzeni");
      put("2", "Potvrzeny");
      put("3", "Expirovany");
    }
  });

  public ServiceProvider(String uri) {
    this.reqBaseURI = uri;
  }

  /**
   * Metoda, ktera ziska autentizacni cookie, ktera se nasledne pouziva pro volani WS.
   *
   * Prihlasovani pro WS pomoci MK:
   *
   * 1. POST request na adresu:
   * https://[adresa_prostredi]/as/processLogin?type=mep-ws&applicationName=[jmeno_aplikace]&uri=https://[adresa_prostredi]/apps/DS/[endpoint_webove_sluzby]
   * s basic autentizaci:] Basic Auth [userName]:[isdsMKToken]
   *
   * Odpoved uspesneho requestu vrati http status 302 a redirect url:
   * https://[adresa_prostredi]/as/mepWsStateUpdate s vyplnenenou S-Cookie,
   * kterou je treba uchovat pocas celeho procesu.
   *
   * ---------------------------------------------------------------------------
   *
   * 2. V dalsim kroku si treba periodicky kontrolovat status prihlasovani na
   * adrese: https://[adresa_prostredi]/as/mepWsStateUpdate s S-Cookie ziskanou
   * v kroku 1
   *
   * Mozne hodnoty odpovedi v tele (payloadu) pozadavku: "-1": request
   * nerozpoznan "1": zatim nepotvrzeny pozadavek / ceka na potvrzeni v MK "2":
   * pozadavek potvrzeny "3": pozadaku vyprsela platnost (expirovany)
   *
   * ---------------------------------------------------------------------------
   *
   * 3. Jestlize v kroku 2 request vratil "2" v tele odpovedi, je nutne zaslat POST
   * pozadavek na adresu
   * https://[adresa_prostredi]/as/processLogin?type=mep-ws&applicationName=[jmeno_aplikaci]&uri=https://[adresa_prostredi]/apps/DS/[endpoint_webove_sluzby]
   * s basic authentizaci - Basic Auth [userName]:[isdsMKToken] a s S-Cookie
   * ziskanou v prvnim kroku.
   *
   * Odpoved uspesneho requestu vrati http status 302 a autentizacni
   * IPCZ-X-COOKIE Set-Cookie:IPCZ-X-COOKIE=....... Tato cookie slouzi k
   * autentizaci pro volani WS a ma platnost 30 minut.
   *
   *
   *
   * @param credentials pristupove udaje
   * @param serviceSuffix
   * @return
   * @throws MalformedURLException
   * @throws IOException
   * @throws URISyntaxException
   * @throws ServiceException
   * @throws java.lang.InterruptedException
   */
  public String getAuthCookie(Credentials credentials, String serviceSuffix) throws MalformedURLException, IOException, URISyntaxException, ServiceException, InterruptedException {

    // hlavicka basic autentizace
    String loginParts = credentials.getLogin() + ":" + credentials.getMKtoken();
    String encodedBasicAuthString = "Basic " + Base64.getEncoder().encodeToString(loginParts.getBytes());

    /**
     * *** 1. pozadavek o autentizaci pomoci MK ****
     */
    URL redirectUrlString = getXCookie(encodedBasicAuthString, credentials.getApplicationName(), serviceSuffix);

    /**
     * *** 2. cyklicke dotazovani na stav pozadavku (zda byl jiz potvrzen)
     */
    if (!waitForConfirmation(redirectUrlString)) {
      throw new ServiceException("Pozadavek na MK autentizaci nebyl rozpoznan nebo expiroval.");
    }

    /**
     * *** 3. pozadavek o auth. cookie ****
     */
    return getAuthCookie(encodedBasicAuthString, authCookie, serviceSuffix);

  }

  /**
   * Prida k webove sluzbe do request hlavicek autentizacni cookie.
   *
   * @param provider port webove sluzby.
   */
  private void addAuthCookie(BindingProvider provider, String authentizationCookie) {
    Map requestContext = provider.getRequestContext();
    requestContext.put(BindingProvider.SESSION_MAINTAIN_PROPERTY, true);

    Map<String, List> requestHeaders = new HashMap<>();
    List cookies = new ArrayList();

    cookies.add(authentizationCookie);

    requestHeaders.put("Cookie", cookies);
    requestContext.put(MessageContext.HTTP_REQUEST_HEADERS, requestHeaders);
  }

  /* Nastavi autentizacni cookie. Pro autentizaci vyuzije jmeno a MK token.
   * kod.
   * @param provider
   * @param cr
   * @param serviceSuffix
   * @throws NoSuchAlgorithmException
   * @throws KeyStoreException
   * @throws FileNotFoundException
   * @throws IOException
   * @throws CertificateException
   * @throws UnrecoverableKeyException
   * @throws KeyManagementException
   * @throws MalformedURLException
   * @throws ServiceException
   * @throws URISyntaxException
   * @throws InterruptedException 
   */
  public void authenticate(BindingProvider provider, Credentials cr, String serviceSuffix)
          throws NoSuchAlgorithmException, KeyStoreException, FileNotFoundException, IOException,
          CertificateException, UnrecoverableKeyException, KeyManagementException,
          MalformedURLException, ServiceException, URISyntaxException, InterruptedException {

    Date now = new Date();
    if (authCookie == null || cookiesContainer == null || authCookieTime == null
            || authCookieTime.getTime() + COOKIE_TIMEOUT_MS < now.getTime()) {
      authCookie = getAuthCookie(cr, serviceSuffix);
      authCookieTime = now;
    }

    if (provider != null) {
      addAuthCookie(provider, authCookie);
    }
  }

  /**
   * Nastavi klientovi webove sluzby adresu, kam se ma pripojovat.
   *
   * @param provider proxy webove sluzby.
   * @param uri uri pripojeni.
   * @throws java.net.URISyntaxException
   */
  public void setServiceUri(BindingProvider provider, String uri) throws URISyntaxException {
    System.out.println("Setting service uri to: " + uri);
    provider.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, uri);
  }

  /**
   * Provede zneplatneni obdrzene auth. cookie
   */
  public void logout() {
    if (cookiesContainer == null) {
      return; // nejsme prihlaseni - neni zadna cookie pro zneplatneni
    }

    try {
      String logoutUriStr = reqBaseURI + "/as/processLogout?uri=" + reqBaseURI + "/apps/DS/DsManage";
      URL logoutUrl = new URL(logoutUriStr);
      HttpsURLConnection con = (HttpsURLConnection) logoutUrl.openConnection();
      int responseCode = 0;
      try {
        String cookies = cookiesContainer.getCookieHeaderValueForUrl(logoutUrl);
        con.setRequestProperty("Cookie", cookies); // nastavuje autentifikační cookie
        con.setRequestMethod("GET");
        con.setDoOutput(true);
        responseCode = con.getResponseCode();
      } finally {
        con.disconnect();
      }

      if (responseCode == 200) {
        System.out.println("Uspesne odhlaseno.");
      } else {
        System.out.println("Chyba pri odhlasovani: http code: " + responseCode);
      }
    } catch (Exception ex) {
      System.out.println("Pri odhlasovani doslo k vyjimce: " + ex);
    }
  }

  /**
   * Vlozi vsechny cookie s ne-null hodnotou do cookie kontejneru.
   *
   * @param cookiesList
   */
  private void storeCookies(List<String> cookiesList) {
    if (cookiesList != null) {
      cookiesList.stream().filter((cookieValue) -> (cookieValue != null)).forEachOrdered((cookieValue) -> {
        cookiesContainer.addCookie(new Cookie(cookieValue));
      });
    }
  }

  /**
   * Vraci payload requestu
   *
   * @param inputStream
   * @return
   * @throws IOException
   */
  private String getPayload(InputStream inputStream) throws IOException {
    try (BufferedReader in = new BufferedReader(new InputStreamReader(inputStream))) {
      String inputLine;
      StringBuilder content = new StringBuilder();
      while ((inputLine = in.readLine()) != null) {
        content.append(inputLine);
      }
      return content.toString();
    }
  }

  /**
   * Obdrzi a uchova IPCZ-X-COOKIE a zaroven zahajuje MK autentizaci (vytvori
   * pozadavek na prihlaseni).
   *
   * @return redirect URL for 2nd request.
   */
  private URL getXCookie(String encodedBasicAuthString, String applicationName, String serviceSuffix) throws MalformedURLException, IOException, ServiceException {

    //url pro pozadavek na MK autentizaci
    URL requestUrl = new URL(reqBaseURI + MK_LOGIN_URL_PART + applicationName + "&uri=" + reqBaseURI + serviceSuffix);

    //HTTPS connection
    HttpsURLConnection connection = (HttpsURLConnection) requestUrl.openConnection();
    //nastaveni hlavicek pro pozadavek o MK autentizaci
    try {
      connection.setRequestProperty("Authorization", encodedBasicAuthString);
      connection.setRequestProperty("Content-Type", "text/xml");
      connection.setRequestProperty("Content-Length", "0");
      connection.setRequestProperty("Cache-Control", "no-cache");

      //sestaveni POST pozadavku
      connection.setRequestMethod("POST");
      connection.setDoOutput(true);
      connection.setInstanceFollowRedirects(false);

      System.out.println("Zasilam pozadavek na autentizaci pomoci MK.");

      // precteni hlavicek odpovedi + uchovani prijatych cookies
      storeCookies(connection.getHeaderFields().get("Set-Cookie"));

      // adresa presmerovani
      if (connection.getResponseCode() == 302) {
        System.out.println("Pozadavek na autentizaci pomoci MK byl prijat serverem.");
        return new URL(connection.getHeaderField("Location"));
      } else {
        throw new ServiceException("Nedoslo k predpokladanemu presmerovani. Server odpovedel error code " + connection.getResponseCode());
      }
    } finally {
      connection.disconnect();
    }
  }

  /**
   * Opakovane (1x za vterinu) se taze na stav pozadavku, dokud neni pozadavek
   * potvrzen v MK nebo nevyexpiruje.
   *
   * @param requestUrl
   * @return
   * @throws IOException
   * @throws InterruptedException
   */
  public boolean waitForConfirmation(URL requestUrl) throws IOException, InterruptedException {
    String serverResponse;
    String cookies;
    do {
      //HTTPS connection
      HttpsURLConnection connection = (HttpsURLConnection) requestUrl.openConnection();
      try {
        // najdi cookie platne pro dane url (
        cookies = cookiesContainer.getCookieHeaderValueForUrl(requestUrl);

        if (cookies != null) {
          connection.setRequestProperty("Cookie", cookies);
        }

        System.out.println("Zjistuji stav pozadavku na MK autentizaci.");
        serverResponse = (getPayload(connection.getInputStream()));
        System.out.println("Stav pozadavku: " + serverResponse + " (" + STATE_DESCRIPTION.get(serverResponse) + ")");
        //kod odpovedi serveru
        if (serverResponse.equals("2")) { // potvrzeno
          return true;
        } else if (serverResponse.equals("3") || serverResponse.equals("-1")) { // expirovany, nebo nerozpoznany/neexistujici
          return false;
        }
        Thread.sleep(1000); // pockej vterinu
      } finally {
        connection.disconnect();
      }
    } while (true);
  }

  /**
   * Ziska a vrati autentizacni cookie (IPCZ-X-COOKIE).
   * @param encodedBasicAuthString
   * @param applicationName
   * @param serviceSuffix
   * @return
   * @throws MalformedURLException
   * @throws ProtocolException
   * @throws IOException
   * @throws ServiceException 
   */
  private String getAuthCookie(String encodedBasicAuthString, String applicationName, String serviceSuffix) throws MalformedURLException, ProtocolException, IOException, ServiceException {
    /**
     * Pozadavek zasilany po potvrzeni prihlaseni. Slouzi pro ziskani autentizacni cookie
     */
    URL requestUrl = new URL(reqBaseURI + MK_LOGIN_URL_PART + applicationName + "&uri=" + reqBaseURI + serviceSuffix);
    HashSet<String> usedUrls = new HashSet<>();
    String cookies;
    int response;

    // maximalni pocet presmerovani 20
    for (int i = 0; i < MAX_REDIRECT_CNT; i++) {
      HttpsURLConnection connection = (HttpsURLConnection) requestUrl.openConnection();
      try {
        connection.setRequestProperty("Authorization", encodedBasicAuthString);
        connection.setRequestMethod("POST");
        connection.setDoOutput(true);
        connection.setInstanceFollowRedirects(false);
        // nastavime cookies pro dane URL
        cookies = cookiesContainer.getCookieHeaderValueForUrl(requestUrl);
        if (cookies != null) {
          connection.setRequestProperty("Cookie", cookies);
        }

        // ulozime prijate cookies
        storeCookies(connection.getHeaderFields().get("Set-Cookie"));
        
        // jiz se podarilo ziskat IPCZ-X-COOKIE
        Cookie ipczXCookie = cookiesContainer.getCookie("IPCZ-X-COOKIE");
        if (ipczXCookie != null) {
          return ipczXCookie.getName() + "=" + ipczXCookie.getValue();
        }

        response = connection.getResponseCode();

        //kod odpovedi serveru
        // presmerovani 
        if (response == 301 || response == 302) {
          String requestUrlString = connection.getHeaderField("Location");
          requestUrl = new URL(requestUrlString);
          if (usedUrls.contains(requestUrlString)) {
            System.out.println("Cyklicke presmerovani");
          }
          usedUrls.add(requestUrlString);
        } else if (response == 401) {
          System.out.println("Unathorized (401)");
          break;
        } else if (response == 200) {
          System.out.println("OK (200)");
          break;
        } else {
          System.out.println("Neocekavana odpoved.");
          break;
        }
      } finally {
        connection.disconnect();
      }
    }
    throw new ServiceException("Nepodarilo se ziskat auth. cookie.");
  }
}
