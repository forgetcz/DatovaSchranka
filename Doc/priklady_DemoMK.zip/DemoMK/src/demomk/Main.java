package demomk;

import cz.czechpoint.isds.v20.DataBoxSearch;
import cz.czechpoint.isds.v20.DataBoxSearchPortType;
import cz.czechpoint.isds.v20.TDbOwnerInfoExt2;
import cz.czechpoint.isds.v20.TDbOwnersArray2;
import cz.czechpoint.isds.v20.TDbReqStatus;
import cz.czechpoint.isds.v20.TDbType;
import java.util.Iterator;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Holder;

/**
 * Program vyzve uzivatele k zadani PU (uzivatelskeho jmena a MK loginu, pote
 * se prihlasi pomoci MK (mobilniho klice), vyhleda schranku "Ministerstvo vnitra" a odhlasi se.
 *
 * Priklad je psan pro VEREJNY TEST (https://www.czebox.cz). Pro produkcni
 * prostredi je treba nastavit DESTINATION_URI na "www.mojedatovaschranka.cz"
 *
 * Pro uspesne prihlaseni je treba nejprve nastavit prislusny typ
 * prihlasovani(Mobilni klic) v datove schrance
 *
 * Pro uspesne volani WS v tomto prikladu je nutne mit naimportovane https
 * serverove certifikaty z http://vca.postsignum.cz/www/authorities.php do java
 * key store
 *
 * Automaticky generovane tridy jsou vygenerovany z db_search.wsdl ve verzi 2.31
 * dostupneho na https://www.czebox.cz/static/wsdl/v20/db_search.wsdl pomoci
 * utility wsimport (pozor na kodovani windows-1250). Toto je wsdl z testovaciho 
 * prostredi, pro produkcni pouziti je urceno wsdl umistene na
 * https://www.mojedatovaschranka.cz/static/wsdl/v20/db_search.wsdl
 *
 */
public class Main {

  // URI pouzivaneho prostredi
  static String DESTINATION_URI = "https://www.czebox.cz";

  // Suffix vyhledavacih sluzeb
  private static final String SEARCH_SERVICE_SUFFIX = "/apps/DS/df";

  /**
   * @param args the command line arguments
   * @throws java.lang.Exception
   */
  public static void main(String[] args) throws Exception {

    System.out.println("Pouzivane prostredi: " + DESTINATION_URI);

    // init
    Credentials credentials = new Credentials();
    ServiceProvider serviceProvider = new ServiceProvider(DESTINATION_URI);

    // nacteni jmena a hesla z konzole
    credentials.readCredentials();

    // URI vzhledavacich sluzeb
    String dbSearchServiceUri = DESTINATION_URI + SEARCH_SERVICE_SUFFIX;

    // ziskame remote interface pro dataBoxSearchService
    DataBoxSearch dataBoxSearchService = new DataBoxSearch();
    DataBoxSearchPortType dataBoxSearchPort = dataBoxSearchService.getDataBoxSearchPortType();

    // nastavime uri pro pripojeni
    serviceProvider.setServiceUri((BindingProvider) dataBoxSearchPort, dbSearchServiceUri);

    // autentizujeme se
    serviceProvider.authenticate((BindingProvider) dataBoxSearchPort, credentials, SEARCH_SERVICE_SUFFIX);

    // vyhledame schranku
    findDatabox(dataBoxSearchPort);

    // zneplatneni auth. cookie
    serviceProvider.logout();
  }

  /**
   * Vyhleda schranku podle ukazkove struktury dbOwnerInfo, kde vyplni jen
   * polozku nazev firmy. Nazev firmy musi mit alespon 3 pismena.
   *
   * @param dataBoxSearchPort
   * @throws java.lang.Exception
   */
  private static void findDatabox(DataBoxSearchPortType dataBoxSearchPort) throws Exception {

    // Vyhledame schranku s nazvem "Ministerstvo vnitra"
    TDbOwnerInfoExt2 dbOwnerInfo = new TDbOwnerInfoExt2();
    dbOwnerInfo.setDbType(TDbType.OVM);
    dbOwnerInfo.setFirmName("Ministerstvo vnitra");

    // vytvorime holdery pro vysledek volani WS
    Holder<TDbOwnersArray2> dbResults = new Holder<>();
    Holder<TDbReqStatus> dbStatus = new Holder<>();

    // vyhledame schranku
    dataBoxSearchPort.findDataBox2(dbOwnerInfo, dbResults, dbStatus);

    //vypiseme status volani WS
    System.out.println("searchDatabox status: " + dbStatus.value.getDbStatusMessage());

    // volani WS dopadlo uspesne
    if (dbStatus.value.getDbStatusCode().startsWith("0")) {
      Iterator<TDbOwnerInfoExt2> it = dbResults.value.getDbOwnerInfo().iterator();
      // projdeme seznam vracenych schranek
      while (it.hasNext()) {
        TDbOwnerInfoExt2 owner = it.next();
        // a vypiseme jejich nazev a DbId
        System.out.println("Nazev: " + owner.getFirmName() + ", id schranky: " + owner.getDbID());
      }
    }
  }
}
