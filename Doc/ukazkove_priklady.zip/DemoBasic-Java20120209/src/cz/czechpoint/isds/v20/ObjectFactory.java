
package cz.czechpoint.isds.v20;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the cz.czechpoint.isds.v20 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _NumOfMessagesResponse_QNAME = new QName("http://isds.czechpoint.cz/v20", "NumOfMessagesResponse");
    private final static QName _NumOfMessages_QNAME = new QName("http://isds.czechpoint.cz/v20", "NumOfMessages");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: cz.czechpoint.isds.v20
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link TStatReqStatus }
     * 
     */
    public TStatReqStatus createTStatReqStatus() {
        return new TStatReqStatus();
    }

    /**
     * Create an instance of {@link TNumOfMessagesInput }
     * 
     */
    public TNumOfMessagesInput createTNumOfMessagesInput() {
        return new TNumOfMessagesInput();
    }

    /**
     * Create an instance of {@link TNumOfMessagesOutput }
     * 
     */
    public TNumOfMessagesOutput createTNumOfMessagesOutput() {
        return new TNumOfMessagesOutput();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TNumOfMessagesOutput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "NumOfMessagesResponse")
    public JAXBElement<TNumOfMessagesOutput> createNumOfMessagesResponse(TNumOfMessagesOutput value) {
        return new JAXBElement<TNumOfMessagesOutput>(_NumOfMessagesResponse_QNAME, TNumOfMessagesOutput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TNumOfMessagesInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isds.czechpoint.cz/v20", name = "NumOfMessages")
    public JAXBElement<TNumOfMessagesInput> createNumOfMessages(TNumOfMessagesInput value) {
        return new JAXBElement<TNumOfMessagesInput>(_NumOfMessages_QNAME, TNumOfMessagesInput.class, null, value);
    }

}
