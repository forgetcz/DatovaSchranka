@javax.xml.bind.annotation.XmlSchema(namespace = "http://isds.czechpoint.cz/v20", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package cz.czechpoint.isds.v20;
