
package cz.czechpoint.isds.v20;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * n�vratov� typ WS
 * 
 * <p>Java class for tStatReqStatus complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tStatReqStatus">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;group ref="{http://isds.czechpoint.cz/v20}gDbSReqStatus"/>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tStatReqStatus", propOrder = {
    "dbStatusCode",
    "dbStatusMessage"
})
public class TStatReqStatus {

    @XmlElement(required = true)
    protected String dbStatusCode;
    @XmlElement(required = true)
    protected String dbStatusMessage;

    /**
     * Gets the value of the dbStatusCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbStatusCode() {
        return dbStatusCode;
    }

    /**
     * Sets the value of the dbStatusCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbStatusCode(String value) {
        this.dbStatusCode = value;
    }

    /**
     * Gets the value of the dbStatusMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDbStatusMessage() {
        return dbStatusMessage;
    }

    /**
     * Sets the value of the dbStatusMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDbStatusMessage(String value) {
        this.dbStatusMessage = value;
    }

}
