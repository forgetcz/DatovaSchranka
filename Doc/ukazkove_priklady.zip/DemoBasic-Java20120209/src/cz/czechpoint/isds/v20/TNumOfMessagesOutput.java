
package cz.czechpoint.isds.v20;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for tNumOfMessagesOutput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="tNumOfMessagesOutput">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="statResult" type="{http://www.w3.org/2001/XMLSchema}integer"/>
 *         &lt;element name="statTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="dbStatus" type="{http://isds.czechpoint.cz/v20}tStatReqStatus" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "tNumOfMessagesOutput", propOrder = {
    "statResult",
    "statTime",
    "dbStatus"
})
public class TNumOfMessagesOutput {

    @XmlElement(required = true, nillable = true)
    protected BigInteger statResult;
    @XmlElement(required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar statTime;
    protected TStatReqStatus dbStatus;

    /**
     * Gets the value of the statResult property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getStatResult() {
        return statResult;
    }

    /**
     * Sets the value of the statResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setStatResult(BigInteger value) {
        this.statResult = value;
    }

    /**
     * Gets the value of the statTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getStatTime() {
        return statTime;
    }

    /**
     * Sets the value of the statTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setStatTime(XMLGregorianCalendar value) {
        this.statTime = value;
    }

    /**
     * Gets the value of the dbStatus property.
     * 
     * @return
     *     possible object is
     *     {@link TStatReqStatus }
     *     
     */
    public TStatReqStatus getDbStatus() {
        return dbStatus;
    }

    /**
     * Sets the value of the dbStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link TStatReqStatus }
     *     
     */
    public void setDbStatus(TStatReqStatus value) {
        this.dbStatus = value;
    }

}
