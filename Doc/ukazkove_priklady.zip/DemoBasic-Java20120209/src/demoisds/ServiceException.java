
package demoisds;

/**
 * Výjimka, kterou mohou generovat třídy z příkladu
 * @author Jan Vávra, isds@602.cz
 */
public class ServiceException extends Exception { 
    public ServiceException(String message) {
        super(message);
    }
}
