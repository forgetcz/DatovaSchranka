package demoisds;

import cz.czechpoint.isds.v20.DataBoxAccess;
import cz.czechpoint.isds.v20.DataBoxAccessPortType;
import cz.czechpoint.isds.v20.DataBoxSearch;
import cz.czechpoint.isds.v20.DataBoxSearchPortType;
import cz.czechpoint.isds.v20.DmInfoPortType;
import cz.czechpoint.isds.v20.DmInfoWebService;
import cz.czechpoint.isds.v20.DmOperationsPortType;
import cz.czechpoint.isds.v20.DmOperationsWebService;
import cz.czechpoint.isds.v20.IsdsStat;
import cz.czechpoint.isds.v20.IsdsStatPortType;
import cz.czechpoint.isds.v20.TDbOwnerInfo;
import cz.czechpoint.isds.v20.TDbOwnersArray;
import cz.czechpoint.isds.v20.TDbReqStatus;
import cz.czechpoint.isds.v20.TDbType;
import cz.czechpoint.isds.v20.TDbUserInfo;
import cz.czechpoint.isds.v20.TFilesArray;
import cz.czechpoint.isds.v20.TMessageCreateInput.DmEnvelope;
import cz.czechpoint.isds.v20.TRecord;
import cz.czechpoint.isds.v20.TRecordsArray;
import cz.czechpoint.isds.v20.TStatReqStatus;
import cz.czechpoint.isds.v20.TStateChangesArray;
import cz.czechpoint.isds.v20.TStateChangesRecord;
import cz.czechpoint.isds.v20.TStatus;
import java.io.File;
import java.io.FileOutputStream;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Holder;

/**
 * Hlavni trida pro ukazku prace s datovou schrankou.
 * 3.2.2012  v. 3.0
 * isds@602.cz
 */
public class Main {

  /**
   * Priklad je konstruovan pro pouziti s testovacim rozhranim.
   * Pokud budete kod pouzivat proti produkcnimu prostredi, pak zajistete spravnou
   * hodnotu anotaci wsdlLocation. Ty jsou nyni nasmerovany na testovaci prostredi.
   *
   */
  public static final String APP_TEST_BASIC = "https://ws1.czebox.cz";
  public static final String APP_TEST_SYSTEM_CERT = "https://ws1c.czebox.cz/cert";
  public static final String APP_TEST_BASIC_AND_CERT = "https://ws1c.czebox.cz/certds";
  public static final String APP_TEST_HSPIS = "https://ws1c.czebox.cz/hspis";

  /**
   * Vyhleda schranku podle ukazkove struktury dbOwnerInfo, kde vyplni jen polozku nazev a typ schranky.
   * Nazev firmy musi mit alespon 3 pismena.
   * @param dataBoxSearchPort
   * @throws java.lang.Exception
   */
  private static void findDataBox(DataBoxSearchPortType dataBoxSearchPort) throws Exception {
    System.out.println("Ukazka volani WS pro vyhledani schranky.");

    TDbOwnerInfo dbOwnerInfo = new TDbOwnerInfo();
    //vyplnime udaje pro vyhledavani
    dbOwnerInfo.setDbType(TDbType.OVM);
    dbOwnerInfo.setFirmName("Ministerstvo vnitra");//

    //ostatni prazdne
    dbOwnerInfo.setAdCity("");
    dbOwnerInfo.setAdNumberInMunicipality("");
    dbOwnerInfo.setAdNumberInStreet("");
    dbOwnerInfo.setAdState("");
    dbOwnerInfo.setAdStreet("");
    dbOwnerInfo.setAdZipCode("");
    dbOwnerInfo.setBiCity("");
    dbOwnerInfo.setBiCounty("");
    dbOwnerInfo.setBiState("");
    dbOwnerInfo.setPnFirstName("");
    dbOwnerInfo.setPnLastName("");

    DatatypeFactory dataTypeFactory = DatatypeFactory.newInstance();
    //ukazka vytvoreni data
    XMLGregorianCalendar bidate = dataTypeFactory.newXMLGregorianCalendar(
            1981, 3, 7, //rok, mesic, den
            0, 0, 0, 0, //hod, min, sec, msec
            0); //zone offset

    dbOwnerInfo.setBiDate(bidate);

    Holder<TDbOwnersArray> dbResults = new Holder<TDbOwnersArray>();
    Holder<TDbReqStatus> dbStatus = new Holder<TDbReqStatus>();

    dataBoxSearchPort.findDataBox(dbOwnerInfo, dbResults, dbStatus);
    System.out.println("Status volani: " + dbStatus.value.getDbStatusMessage());
    if (dbStatus.value.getDbStatusCode().startsWith("0")) { // status OK 
      System.out.println("Pocet vyhledanych schranek: " + dbResults.value.getDbOwnerInfo().size());
      for (TDbOwnerInfo ownInfo : dbResults.value.getDbOwnerInfo()) {
        System.out.println("Nazev: " + ownInfo.getFirmName() + ", ID schranky: " + ownInfo.getDbID());
      }
    }
  }

  /**
   * Vypise statistiku odeslanych zprav systemem.
   * @param isdsStatPort 
   */
  private static void getMessageStat(IsdsStatPortType isdsStatPort) {
    System.out.println("Ukazka volani WS pro statistiku odeslanych zprav.");

    Holder<XMLGregorianCalendar> calendar = new Holder<XMLGregorianCalendar>();
    Holder<BigInteger> cnt = new Holder<BigInteger>();
    Holder<TStatReqStatus> status = new Holder<TStatReqStatus>();

    isdsStatPort.numOfMessages(BigInteger.ZERO, cnt, calendar, status);

    System.out.println("Status volani: " + status.value.getDbStatusMessage());
    if (status.value.getDbStatusCode().startsWith("0")) { // status OK
      System.out.println("Pocet dodanych zprav systemem k " + XMLGregorianCalendarToString(calendar.value) + " je " + cnt.value + ".");
    }
  }

  /**
   * Vypise vybrane informace o schrance, do ktere jsme prihlaseni.
   * @param dataBoxAccesPort 
   */
  private static void getOwnerInfoFromLogin(DataBoxAccessPortType dataBoxAccesPort) {
    System.out.println("Ukazka volani WS pro ziskani informaci o schrance, do ktere jsme prihlaseni.");
    Holder<TDbOwnerInfo> ownerInfo = new Holder<TDbOwnerInfo>();
    Holder<TDbReqStatus> status = new Holder<TDbReqStatus>();

    dataBoxAccesPort.getOwnerInfoFromLogin(null, ownerInfo, status);
    System.out.println("Status volani: " + status.value.getDbStatusMessage());
    if (status.value.getDbStatusCode().startsWith("0")) { // status OK
      TDbOwnerInfo owner = ownerInfo.value;
      System.out.println("Informace o schrance do niz jste prihlaseni:");
      System.out.println("ID schranky: " + owner.getDbID());
      System.out.println("Nazev: " + owner.getFirmName());
      System.out.println("Typ: " + owner.getDbType().toString());
    }
  }

  /**
   * Zavola WS a vypise vybrane informace o prihlasenem uzivateli.
   * @param dataBoxAccesPort 
   */
  private static void getUserInfoFromLogin(DataBoxAccessPortType dataBoxAccesPort) {
    System.out.println("Ukazka volani WS pro ziskani informaci o prihlasenem uzivateli.");
    Holder<TDbUserInfo> userInfo = new Holder<TDbUserInfo>();
    Holder<TDbReqStatus> status = new Holder<TDbReqStatus>();

    dataBoxAccesPort.getUserInfoFromLogin(null, userInfo, status);
    System.out.println("Status volani: " + status.value.getDbStatusMessage());
    if (status.value.getDbStatusCode().startsWith("0")) { // status OK
      TDbUserInfo user = userInfo.value;
      System.out.println("Informace o prihlasenem uzivateli:");
      System.out.println("ID uzivatele: " + user.getUserID());
      System.out.println("Prijmeni: " + user.getPnLastName());
      System.out.println("Jmeno: " + user.getPnFirstName());
      System.out.println("Datum narozeni: " + XMLGregorianCalendarToString(user.getBiDate()));
    }
  }

  /**
   * Vytvori zpravu s konstantnimi hodnotami.
   * @param port
   * @param recipientID id schranky adresata
   * @throws Exception 
   */
  private static void createMessage(DmOperationsPortType port, String recipientID) throws Exception {
    System.out.println("Ukazka volani WS pro vytvoreni datove zpravy.");
    DmEnvelope dmEnvelope = new DmEnvelope();
    TFilesArray dmFiles = new TFilesArray();
    Holder<String> dmID = new Holder<String>();
    Holder<TStatus> dmStatus = new Holder<TStatus>();

    dmEnvelope.setDbIDRecipient(recipientID);
    dmEnvelope.setDmAllowSubstDelivery(false);
    dmEnvelope.setDmAnnotation("Testovaci zprava - Java");
    dmEnvelope.setDmLegalTitleLaw(BigInteger.valueOf(677));
    dmEnvelope.setDmLegalTitlePar("231");
    dmEnvelope.setDmLegalTitlePoint("179");
    dmEnvelope.setDmLegalTitleSect("331");
    dmEnvelope.setDmLegalTitleYear(BigInteger.valueOf(2010));
    dmEnvelope.setDmPersonalDelivery(false);
    dmEnvelope.setDmRecipientIdent("VZ-147");
    dmEnvelope.setDmRecipientOrgUnit("Vaše org. jednotka");
    dmEnvelope.setDmRecipientOrgUnitNum(BigInteger.valueOf(-1));
    dmEnvelope.setDmRecipientRefNumber("včj. 253");
    dmEnvelope.setDmSenderIdent("NZ-557");
    dmEnvelope.setDmSenderOrgUnit("Naše org. jednotka");
    //dmEnvelope.setDmSenderOrgUnitNum()
    dmEnvelope.setDmSenderRefNumber("nčj. 589");
    dmEnvelope.setDmToHands("K rukám p. Nováka");

    //pridej jedenu prilohu
    TFilesArray.DmFile file = new TFilesArray.DmFile();
    file.setDmFileDescr("test.txt");
    file.setDmFileGuid("");
    file.setDmFileMetaType("main");
    file.setDmFormat("");
    file.setDmMimeType("text/plain");
    file.setDmFileGuid("");
    file.setDmEncodedContent("Testovací obsah souboru v kódování utf-8.".getBytes("UTF-8"));
    dmFiles.getDmFile().add(file);

    port.createMessage(dmEnvelope, dmFiles, dmID, dmStatus);

    System.out.println("Status volani: " + dmStatus.value.getDmStatusMessage());
    if (dmStatus.value.getDmStatusCode().startsWith("0")) { // status OK
      System.out.println("Zprava odeslana. ID zpravy: " + dmID.value);
    }
  }

  /**
   * Vypise vybrane informace o dodanych datovych zpravach a vrati id jedne z nich.
   * @param port webove sluzby.
   * @return prijate zpravy.
   * @throws java.lang.Exception
   */
  private static String getReceivedMessages(DmInfoPortType port) throws Exception {
    System.out.println("Ukazka stazeni seznamu dodanych zprav.");
    DatatypeFactory dataTypeFactory = DatatypeFactory.newInstance();
    /*zajima nas obdobi od -7dni do soucasnosti*/
    //"do"
    GregorianCalendar gcTo = new GregorianCalendar();
    gcTo.setTimeInMillis(System.currentTimeMillis()); //konec intervalu je soucasny okamzik
    XMLGregorianCalendar xmlToTime = dataTypeFactory.newXMLGregorianCalendar(gcTo);

    //"od"
    GregorianCalendar gcFrom = new GregorianCalendar();
    gcFrom.setTimeInMillis(gcTo.getTimeInMillis());
    gcFrom.add(Calendar.DATE, -7); //zacatek intervalu pred 7 dny od soucasnosti
    XMLGregorianCalendar xmlFromTime = dataTypeFactory.newXMLGregorianCalendar(gcFrom);

    BigInteger dmRecipientOrgUnitNum = null;
    String dmStatusFilter = null;
    BigInteger dmOffset = BigInteger.valueOf(1);
    BigInteger dmLimit = BigInteger.valueOf(100);
    Holder<TRecordsArray> dmRecords = new Holder<TRecordsArray>();
    Holder<TStatus> dmStatus = new Holder<TStatus>();


    port.getListOfReceivedMessages(xmlFromTime, xmlToTime, dmRecipientOrgUnitNum,
            dmStatusFilter, dmOffset, dmLimit, dmRecords, dmStatus);

    System.out.println("od: " + XMLGregorianCalendarToString(xmlFromTime));
    System.out.println("do: " + XMLGregorianCalendarToString(xmlToTime));
    System.out.println("Status volani: " + dmStatus.value.getDmStatusMessage());
    String firsMessageId = null;
    if (dmStatus.value.getDmStatusCode().startsWith("0")) { // status OK
      System.out.println("Pocet dodanych zprav: " + dmRecords.value.getDmRecord().size());

      for (TRecord rec : dmRecords.value.getDmRecord()) {
        if (firsMessageId == null) {
          firsMessageId = rec.getDmID();
        }
        System.out.println("ID : " + rec.getDmID() + "; stav: " + rec.getDmMessageStatus()
                + "; adresa odesilatele: " + rec.getDmSenderAddress() + "; ID odesilatele: "
                + rec.getDbIDSender() + "; dorucena: " + rec.getDmAcceptanceTime()
                + "; dodana: " + rec.getDmDeliveryTime());
      }
    }
    return firsMessageId;
  }

  /**
   * Stahne zpravu v podepsanem tvaru a ulozi je do souboru.
   * @param port port webove sluzby.
   * @param messageId id zpravy
   * @throws java.lang.Exception
   */
  private static void downloadSignedMessage(DmOperationsPortType port, String messageId) throws Exception {
    System.out.println("Ukazka volani WS pro stazeni podepsane zpravy.");
    Holder<byte[]> dmSignature = new Holder<byte[]>();
    Holder<TStatus> dmStatus = new Holder<TStatus>();

    port.signedMessageDownload(messageId, dmSignature, dmStatus);
    System.out.println("Status volani: " + dmStatus.value.getDmStatusMessage());
    if (dmStatus.value.getDmStatusCode().startsWith("0")) { // status OK
      // vytvori soubor
      String fileName = "message_content.zfo";
      FileOutputStream fstream = new FileOutputStream(fileName);
      fstream.write(dmSignature.value);
      fstream.close();

      System.out.println("Zprava byla ulozena do: "
              + new File(".").getCanonicalPath() + File.separator + fileName);
    }
  }

  /**
   * Vypise seznam zmen stavu zprav za poslednich 7 dnu.
   * @param port DmInfoPort
   * @throws DatatypeConfigurationException
   */
  private static void getMessagesStateChanges(DmInfoPortType port) throws DatatypeConfigurationException {
    System.out.println("Ukazka volani WS pro zjisteni zmen stavu zprav.");
    DatatypeFactory dataTypeFactory = DatatypeFactory.newInstance();
    Holder<TStatus> status = new Holder<TStatus>();
    Holder<TStateChangesArray> changesArray = new Holder<TStateChangesArray>();

    /*zajima nas obdobi od soucasnosti-7dni do soucasnosti*/
    //"do"
    GregorianCalendar gcTo = new GregorianCalendar();
    gcTo.setTimeInMillis(System.currentTimeMillis()); //konec intervalu je soucasny okamzik
    XMLGregorianCalendar xmlToTime = dataTypeFactory.newXMLGregorianCalendar(gcTo);

    //"od"
    GregorianCalendar gcFrom = new GregorianCalendar();
    gcFrom.setTimeInMillis(gcTo.getTimeInMillis());
    gcFrom.add(Calendar.DATE, -7); //zacatek intervalu pred 7 dny od soucasnosti
    XMLGregorianCalendar xmlFromTime = dataTypeFactory.newXMLGregorianCalendar(gcFrom);

    System.out.println("od: " + XMLGregorianCalendarToString(xmlFromTime));
    System.out.println("do: " + XMLGregorianCalendarToString(xmlToTime));
    port.getMessageStateChanges(xmlFromTime, xmlToTime, changesArray, status);
    System.out.println("Status volani: " + status.value.getDmStatusMessage());

    if (status.value.getDmStatusCode().startsWith("0")) { // status OK
      System.out.println("Pocet obdrzenych zmen stavu zprav: " + changesArray.value.getDmRecord().size());
      //vypis vsech zmen
      for (TStateChangesRecord record : changesArray.value.getDmRecord()) {
        System.out.println("ID zpravy " + record.getDmID() + "; cas zmeny " + record.getDmEventTime() + "; stav " + record.getDmMessageStatus());
      }
    }
  }

  /*------- dalsi ukazky volani WS -------*/
  /**
   * Vypise stav ve kterem se schranka nachazi.
   * @param dataBoxSearchPort
   * @param dbID
   * @throws Exception 
   */
  public static void checkDatabox(DataBoxSearchPortType dataBoxSearchPort, String dbID) throws Exception {
    Boolean dbApproved = null;
    String dbExternRefNumber = null;
    Holder<Integer> dbState = new Holder<Integer>();
    Holder<TDbReqStatus> dbStatus = new Holder<TDbReqStatus>();

    dataBoxSearchPort.checkDataBox(dbID, dbApproved, dbExternRefNumber, dbState, dbStatus);
    System.out.println("Status volani: " + dbStatus.value.getDbStatusMessage());
    if (dbStatus.value.getDbStatusCode().startsWith("0")) { // status OK
      System.out.println("Stav schranky " + dbID + " je: " + dbState.value.toString());
    }
  }

  /**
   * Na vystup vypise "oddelovac".
   */
  private static void printSeparator() {
    System.out.println("--------------------------------------------------------------------------");
  }

  /**
   * Vrati datum z kalendare ve formatu "dd.MM.yyyy HH:mm:ss,SSS z".
   */
  private static String XMLGregorianCalendarToString(XMLGregorianCalendar xmlCal) {

    SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss,SSS z");
    GregorianCalendar gc = xmlCal.toGregorianCalendar();
    return dateFormat.format(new Date(gc.getTimeInMillis()));
  }

  /**
   * Příkldad pro použití s JAX-WS knihovnou
   * @param cr přihlašovací údaje.
   * @throws Exception
   */
  public static void runJaxWS(Credentials cr, String appUrl) throws Exception {
    //uri sluzeb
    String db_access_service_uri = appUrl + "/DS/DsManage";
    String db_search_service_uri = appUrl + "/DS/df";
    String dm_info_service_uri = appUrl + "/DS/dx";
    String dm_operations_service_uri = appUrl + "/DS/dz";
    String isds_info_service_uri = appUrl + "/DS/DsManage";

    // kontext pro volani sluzeb
    ServiceManager smng = ServiceManager.getServiceManager();

    // ziskame remote interface pro DataBoxAccess
    DataBoxAccess dataBoxAccessService = new DataBoxAccess();
    DataBoxAccessPortType dataBoxAccessPort = dataBoxAccessService.getDataBoxAccessPortType();
    // nastavime uri pro pripojeni (null, vezme se default hodnota) a autentizujeme sluzbu
    smng.setServiceUri((BindingProvider) dataBoxAccessPort, db_access_service_uri);
    smng.authenticate((BindingProvider) dataBoxAccessPort,
            cr.getLoginName1(),
            cr.getPassword1(),
            cr.getCliCertFilePath(),
            cr.getCliCertPassword());

    //ziskame remote interface pro DataBoxSearch
    DataBoxSearch dataBoxSearchService = new DataBoxSearch();
    DataBoxSearchPortType dataBoxSearchPort = dataBoxSearchService.getDataBoxSearchPortType();
    smng.setServiceUri((BindingProvider) dataBoxSearchPort, db_search_service_uri);
    smng.authenticate((BindingProvider) dataBoxSearchPort,
            cr.getLoginName1(),
            cr.getPassword1(),
            cr.getCliCertFilePath(),
            cr.getCliCertPassword());

    // ziskame remote interface pro DmInfo
    DmInfoWebService dmInfoService = new DmInfoWebService();
    DmInfoPortType dmInfoPort = dmInfoService.getDmInfoPortType();
    smng.setServiceUri((BindingProvider) dmInfoPort, dm_info_service_uri);
    smng.authenticate((BindingProvider) dmInfoPort,
            cr.getLoginName1(),
            cr.getPassword1(),
            cr.getCliCertFilePath(),
            cr.getCliCertPassword());

    // ziskame remote interface pro DmOperations
    DmOperationsWebService dmOperationsService = new DmOperationsWebService();
    DmOperationsPortType dmOperationsPort = dmOperationsService.getDmOperationsPortType();
    smng.setServiceUri((BindingProvider) dmOperationsPort, dm_operations_service_uri);
    smng.authenticate((BindingProvider) dmOperationsPort,
            cr.getLoginName1(),
            cr.getPassword1(),
            cr.getCliCertFilePath(),
            cr.getCliCertPassword());

    // ziskame remote interface pro IsdsStat
    IsdsStat isdsStatService = new IsdsStat();
    IsdsStatPortType isdsStatPort = isdsStatService.getIsdsStatPortType();
    smng.setServiceUri((BindingProvider) isdsStatPort, isds_info_service_uri);
    smng.authenticate((BindingProvider) isdsStatPort,
            cr.getLoginName1(),
            cr.getPassword1(),
            cr.getCliCertFilePath(),
            cr.getCliCertPassword());

    printSeparator();
    System.out.println("\r\n--- Ukazka volani webovych sluzeb. ---\r\n");

    int MAX_FAILURES = 3;
    //Cyklus se snaží zotavit se z chyb při volání operace. Neumí se zotavit z chyb při re-autentizaci.
    for (int failures = 0; failures < MAX_FAILURES; failures++) {
      try {
        //vyhledej schranku
        findDataBox(dataBoxSearchPort);
        break;
      } catch (Exception ex) {
        System.err.println(ex + " - trying again...");

        //pockej 20 vterin
        Thread.sleep(20 * 1000);

        //provedeme nove prihlaseni
        smng.authenticate((BindingProvider) dataBoxSearchPort,
                cr.getLoginName1(),
                cr.getPassword1(),
                cr.getCliCertFilePath(),
                cr.getCliCertPassword());
      }
    }
    printSeparator();

    //Další příklady volání jsou pro přehlednost bez cyklu pro zotavení se z chyb.
    //zjisteni statistiky o poctu odeslanych zprav
    getMessageStat(isdsStatPort);
    printSeparator();

    //vypise info o schrance
    getOwnerInfoFromLogin(dataBoxAccessPort);
    printSeparator();

    //vypise info o uzivateli
    getUserInfoFromLogin(dataBoxAccessPort);
    printSeparator();

    //poslání zprávy
    createMessage(dmOperationsPort, "sem doplnte ID schranky prijemce");
    printSeparator();

    //vylistuje dosle zpravy a vrati id jedne z nich
    String messageId = getReceivedMessages(dmInfoPort);
    printSeparator();

    //stahne podepsanou zpravu jejiz id jsme ziskali vyse
    if (messageId != null) {
      downloadSignedMessage(dmOperationsPort, messageId);
      printSeparator();
    }

    //stahne a vypise seznam zmen stavu odeslanych zprav
    getMessagesStateChanges(dmInfoPort);
  }

  public static void main(String[] args) throws Exception {
    /* Tip: Pro výpis odesílaných a přijatých SOAP zpráv je možné nastavit
     * -Dcom.sun.xml.ws.transport.http.client.HttpTransportPipe.dump=true
     *
     * POZOR: Priklad odkazuje na wsdl, ktere lezi na testovacim prostredi
     */

    //prihlasovaci udaje
    Credentials cr = new Credentials();
    
    //nacteni prihlasovacich udaju z konzole
    cr.loadCredentials();
    
    //volani WS
    runJaxWS(cr, APP_TEST_BASIC);
  }
}
