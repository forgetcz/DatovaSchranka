﻿/* Ukazkovy program (konzolova aplikace) demonstrujici moznosti prace s datovymi schrankami v 3.0
 *
 * Pripadne dotazy a pripominky zasilejte na: ISDS@602.cz
 */
using System;
using System.Text;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using ISDS;

namespace DemoISDS {
    class Program {
        /// <summary>
        /// Objekt reprezentujici pripojeni k prvni datove schrance
        /// </summary>
        static ISDSBox DataBox = null;
        static string LoginName1 = "";
        static string Password1 = "";
        static X509Certificate Certificate1 = null;

        /// <summary>
        /// Pomocna metoda
        /// </summary>
        static void Exit() {
            Console.WriteLine("Pro ukonceni programu stisknete <ENTER>");
            Console.ReadLine();
        }

        /// <summary>
        /// Pomocna metoda
        /// </summary>
        static void Separator() {
            Console.WriteLine("--------------------------------------------------------------------------");
        }

        /// <summary>
        /// Vyber certifikatu z uloziste
        /// </summary>
        /// <returns></returns>
        static X509Certificate SelectX509Certificate() {
            X509Store Store = new X509Store();
            Store.Open(OpenFlags.ReadOnly);
            X509CertificateCollection StoreCollection = (X509CertificateCollection)Store.Certificates;
            int NumOf = StoreCollection.Count;
            Console.WriteLine("Ve Vasem úlozisti se nachazeji tyto certifikaty:");
            for (int i = 0; i < NumOf; i++) {
                ConsoleColor CC = Console.ForegroundColor;
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("{0} ", i);
                Console.ForegroundColor = CC;
                Console.WriteLine("{0}", StoreCollection[i].Subject);
            }
            Console.WriteLine();
            int CertNum = -1;
            do {
                Console.WriteLine("Zadejte cislo certifikatu se kterym se chcete pripojit a stisknete <Enter>");
                try {
                    CertNum = Convert.ToInt32(Console.ReadLine());
                }
                catch {
                }
            } while ((CertNum < 0) || (CertNum >= NumOf));
            return StoreCollection[CertNum];
        }

        /// <summary>
        /// Hlavni procedura programu
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args) {
            Console.WriteLine("Ukazkovy program demonstrujici moznosti prace s datovymi schrankami");
            Console.WriteLine("Budete vyzvani k zadani prihlasovacich údaju ke schrance. " +
                "Muzete se pripojit buď jmenem a heslem, " +
                "nebo klientskym certifikatem vybranym z úloziste certifikatu.\n");
            Console.Write("Chcete se k datove schrance pripojit certifikatem ? (A/N)");
            LoginType LT = LoginType.Cert;

            if (Console.ReadKey().Key == ConsoleKey.A) {
                Console.WriteLine();
                Certificate1 = SelectX509Certificate();
            }
            else {
                LT = LoginType.Password;
                Console.WriteLine();
                Console.Write("Zadejte prihlasovaci jmeno k datove schrance a stisknete <Enter>: ");
                LoginName1 = Console.ReadLine();
                Console.Write("Zadejte heslo k datove schrance a stisknete <Enter>: ");
                ConsoleColor CC = Console.ForegroundColor;
                Console.ForegroundColor = ConsoleColor.Black;
                Console.CursorVisible = false;
                Password1 = Console.ReadLine();
                Console.ForegroundColor = CC;
                Console.CursorVisible = true;
            }
            try {
                Console.WriteLine("Probiha pripojovani k datove schrance...");
                DataBox = new ISDSBox(LT, PortalType.CZebox, LoginName1, Password1, "", Certificate1);
                DataBox.Connect();
                Console.WriteLine("Pripojovani probehlo v poradku\n");
            }
            catch (Exception ex) {
                Console.WriteLine("Behem pripojovani doslo k vyjimce: " + ex.Message);
                Exit();
                return;
            }

            //ukazky volani WS
            try {
                //vyhledani schranky
                DataBox.FindDataBox();
                Separator();

                //statistika odeslanych zprav systemem
                DataBox.GetISDSMsgsStat();
                Separator();

                //informace o schrance do niz jsme prihlaseni.
                DataBox.GetOwnerInfoFromLogin();
                Separator();

                //informace o prihlasenem uzivateli
                DataBox.GetUserInfoFromLogin();
                Separator();

                //vytvori a odesle datovou zpravu
                DataBox.createMessage("sem doplnte ID schranky prijemce");
                Separator();

                //vylistuje seznam dodanych zprav za posledni tyden
                string MessId = DataBox.GetListOfReceivedMessages();
                Separator();

                //ulozi zpravu v podepsanem tvaru do souboru
                if (MessId != null) {
                    DataBox.SignedMessageDownload(MessId);
                    Separator();
                }

                //zmeny stavu zprav za posledni tyden
                DataBox.GetMessagesChanges();
            }
            catch (Exception ex) {
                Console.WriteLine(ex.Message);
                Exit();
                return;
            }
        }
    }
}
