------------------------------------------------------
TATO VERZE JE URCENA PRO ALTERNATIVNI PRISTUP K ISDS
------------------------------------------------------

----------------------------------------------------------------------------------------------
Soucasti projektu
----------------------------------------------------------------------------------------------

ISDSBox.cs - trida reprezentujici datavou schranku - obsahuje ukazky volani WS
Program.cs - testovaci konzolova aplikace
app.Config, AssemblyInfo.cs, DemoISDS.csproj - standardni soucasti C# projektu
DataBoxSearch.cs, DataBoxAccess.cs, dmInfoWebService.cs, dmOperationsWebService.cs 
a IsdsStat.cs - vygenerovane proxy tridy pro jednotlivé služby
Readme.txt - tento soubor

----------------------------------------------------------------------------------------------
Instalace
----------------------------------------------------------------------------------------------

- vytvorte adresar
- nakopirujte do neho soucasti projektu
- ve Visual studiu 2008 otevrete DemoISDS.csproj

----------------------------------------------------------------------------------------------
Preklad a spusteni
----------------------------------------------------------------------------------------------

Pro spusteni demonstracniho programu budete potrebovat prihlasovaci udaje k datove schrance. 

Dotazy a pripominky k projektu muzete zasilat emailem na adresu isds@602.cz

----------------------------------------------------------------------------------------------
Moznosti prihlaseni
----------------------------------------------------------------------------------------------

Tento ukazkovy priklad umoznuje 4 druhy prihlaseni do datove schranky:

1. Jmenem a heslem - treba zadat uzivatelske jmeno a uzivatelske heslo
2. Pomoci systemoveho certifikatu - certifikat a heslo k certifikatu
3. Pomoci certifikatu hostovane spisove sluzby - misto login name se musi zadat id schranky, 
   dale pak certifikat, heslo k certifikatu
4. Jmenem, heslem a certifikatem - uzivatelske jmeno, uzivatelske heslo, certifikat a heslo 
   k certifikatu 

----------------------------------------------------------------------------------------------
Novinky ve verzi z 3.2.2012
----------------------------------------------------------------------------------------------

- priklad demostruje moznou praci s datovou schrankou 
- pri volani WS se kontroluje prvni znak navratoveho kodu - "status code",
  zacina-li kod "0" nedoslo k chybe. Ciselnik chyb/kodu je k dispozici na vyvojarskem 
  serveru.
- obsahuje ukazku volani zakladnich WS:


DbSearchWebService - FindDataBox - vyhledani schranky

IsdsStatService - NumOfMessages - statistika dodanych zprav systemem ISDS

AccessWebService - GetOwnerInfoFromLogin - informace o schrance, do ktere jsme prihlaseni
AccessWebService - GetUserInfoFromLogin - informace o prihlasenem uzivateli

OperationsWebService - CreateMessage - vytvoreni a odeslani datove zpravy
OperationsWebService - SignedMessageDownload - stazeni datove zpravy v podepsanem tvaru

InfoWebService - GetListOfReceivedMessages - vylistovani dodanych zprav
InfoWebService - GetMessageStateChanges - zjisteni zmen stavu zprav

Toto je pouze ukazka pouziti nekolika zakladnich WS. Ostatni jsou popsany v 
prislusne dokumentaci.