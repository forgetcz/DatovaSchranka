package com.jvr.datovaschranka.dbhelper

import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteException
import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import java.util.ArrayList

class NamePasswordModel: ModelElement<NamePasswordModel>() {
    @Parcelize
    data class Item (
        var id : Number? = null,
        var userId : Number? = null,
        var userName : String? = null,
        var userPassword : String? = null,
        var dateCreated : String? = null,
        var dateUpdated : String? = null,
        var isTest : Boolean = false
    ) : Parcelable

    companion object {
        private const val TABLE_NAME = "NamePassword"

        private const val COLUMN_ID = "id"
        private const val COLUMN_FK_USER_ID = "fkUserId"
        private const val COLUMN_DATE_CREATED = "dateCreated"
        private const val COLUMN_DATE_UPDATED = "dateUpdated"
        private const val COLUMN_USER_NAME = "userName"
        private const val COLUMN_PASSWORD = "Password"
    }

    var currentItem = Item()

    override fun getTableName(): String {
        return TABLE_NAME
    }

    override fun getCreateModel(): String {
        return "CREATE TABLE " + TABLE_NAME + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT" +
                "," + COLUMN_FK_USER_ID + " INTEGER NOT NULL" +
                "," + COLUMN_DATE_CREATED + " TEXT NOT NULL" +
                "," + COLUMN_DATE_UPDATED + " TEXT" +
                "," + COLUMN_USER_NAME + " TEXT NOT NULL" +
                "," + COLUMN_PASSWORD + " TEXT NOT NULL" +
                ")"

    }

    override fun select(): Boolean {
        var cursor: Cursor? = null
        try {
            cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME
                    + " WHERE " + COLUMN_FK_USER_ID + "='" + currentItem.userId + "'", null)
        } catch (e: SQLiteException) {
            cursor?.close()
            return false
        }

        if (cursor!!.moveToFirst()) {
            val iId = cursor.getColumnIndex(COLUMN_ID)
            val iUserId = cursor.getColumnIndex(COLUMN_FK_USER_ID)
            val iDateCreated = cursor.getColumnIndex(COLUMN_DATE_CREATED)
            val iDateUpdated = cursor.getColumnIndex(COLUMN_DATE_UPDATED)
            val iUserName = cursor.getColumnIndex(COLUMN_USER_NAME)
            val iUserPassword = cursor.getColumnIndex(COLUMN_PASSWORD)

            if (!cursor.isAfterLast) {
                currentItem.id = cursor.getInt(iId)
                currentItem.userId = cursor.getInt(iUserId)
                currentItem.dateCreated = cursor.getString(iDateCreated)
                currentItem.dateUpdated = cursor.getString(iDateUpdated)
                currentItem.userName = cursor.getString(iUserName)
                currentItem.userPassword = cursor.getString(iUserPassword)
            }
            return true
        }
        return false
    }

    override fun insert(): Boolean {
        TODO("Not yet implemented")
    }

    override fun update(): Boolean {
        TODO("Not yet implemented")
    }

    override fun delete(): Boolean {
        TODO("Not yet implemented")
    }

    override fun selectAll(): ArrayList<NamePasswordModel> {
        TODO("Not yet implemented")
    }

}