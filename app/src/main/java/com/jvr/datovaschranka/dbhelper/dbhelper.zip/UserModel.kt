package com.jvr.datovaschranka.dbhelper

import android.content.ContentValues
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteException
import android.os.Parcelable
import com.jvr.datovaschranka.constatns.Utils
import kotlinx.parcelize.Parcelize
import java.util.*

class UserModel : ModelElement<UserModel>() {
    @Parcelize
    data class Item (
        var id: Number? = null,
        var nickName: String? = null,
        var dateCreated : String? = null,
        var dateUpdated : String? = null
    ) : Parcelable

    private companion object {
        const val TABLE_NAME = "Users"

        const val COLUMN_ID = "id"
        const val COLUMN_NICK_NAME = "nickName"
        const val COLUMN_DATE_CREATED = "dateCreated"
        const val COLUMN_DATE_UPDATED = "dateUpdated"
    }

    var currentItem = Item()

    override fun getTableName(): String {
        return TABLE_NAME
    }

    override fun getCreateModel(): String {
        return "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT" +
                "," + COLUMN_DATE_CREATED + " TEXT NOT NULL" +
                "," + COLUMN_DATE_UPDATED + " TEXT" +
                "," + COLUMN_NICK_NAME + " TEXT NOT NULL UNIQUE" +
                ")"
    }

    override fun toString(): String {
        return "id:$currentItem.id;nickName:$currentItem.nickName"
    }

    /*
    private fun getMaxUserId() : Int {
        var cursor: Cursor? = null
        try {
            cursor = db.rawQuery("select max(" + COLUMN_ID + ") + 1"
                    + " as maxId from " + TABLE_NAME, null)
            cursor?.moveToFirst()
            val id = cursor.getInt(0)
            return id
        } catch (e: SQLiteException) {
            cursor?.close()
            return 0
        }
    }
    */

    /*override fun select(select: String): UserModel? {
        var cursor: Cursor? = null
        try {
            cursor = db.rawQuery("SELECT * FROM '$TABLE_NAME' WHERE $select", null)
        } catch (e: SQLiteException) {
            cursor?.close()
            return null
        }

        if (cursor!!.moveToFirst()) {
            val iId = cursor.getColumnIndex(COLUMN_ID)
            val iDateCreated = cursor.getColumnIndex(COLUMN_DATE_CREATED)
            val iDateUpdated = cursor.getColumnIndex(COLUMN_DATE_UPDATED)
            if (!cursor.isAfterLast) {
                return UserModel()
                currentItem.id = cursor.getInt(iId)
                currentItem.dateCreated = cursor.getString(iDateCreated)
                currentItem.dateUpdated = cursor.getString(iDateUpdated)
            }
            return true
        }
    }*/

    override fun select(): Boolean {
        var cursor: Cursor? = null
        try {
            cursor = db.rawQuery("SELECT * FROM '$TABLE_NAME' WHERE $COLUMN_NICK_NAME = "
                     + currentItem.nickName + "'", null)
        } catch (e: SQLiteException) {
            cursor?.close()
            return false
        }

        if (cursor!!.moveToFirst()) {
            val iId = cursor.getColumnIndex(COLUMN_ID)
            val iDateCreated = cursor.getColumnIndex(COLUMN_DATE_CREATED)
            val iDateUpdated = cursor.getColumnIndex(COLUMN_DATE_UPDATED)
            if (!cursor.isAfterLast) {
                currentItem.id = cursor.getInt(iId)
                currentItem.dateCreated = cursor.getString(iDateCreated)
                currentItem.dateUpdated = cursor.getString(iDateUpdated)
            }
            return true
        }
        return false
    }

    override fun insert(): Boolean {
        // Create a new map of values, where column names are the keys
        if (currentItem.id != null) {
            logger.w(getTag(),"Element already created")
            return false
        }
        if (currentItem.nickName == null) {
            logger.w(getTag(),"Element nickName can't be empty")
            return false
        }
        val values = ContentValues()

        val created = Utils().currentDateTimeString()
        values.put(COLUMN_DATE_CREATED, created)
        values.put(COLUMN_NICK_NAME, currentItem.nickName)

        // Insert the new row, returning the primary key value of the new row
        val newRowId = db.insert(TABLE_NAME, null, values)

        currentItem.id = newRowId
        currentItem.dateCreated = created

        return newRowId != 0L
    }

    override fun update() : Boolean {
        val values = ContentValues()

        if (currentItem.id == null) {
            logger.w(getTag(),"Element not yet exists!")
            return false
        }

        values.put(COLUMN_DATE_UPDATED, Utils().currentDateTimeString())
        values.put(COLUMN_NICK_NAME, currentItem.nickName)

        db.update(TABLE_NAME, values, "_id = ?", arrayOf(currentItem.id.toString()))

        return true
    }

    override fun delete(): Boolean {
        // Define 'where' part of query.
        val selection = "$COLUMN_ID LIKE ? "
        // Specify arguments in placeholder order.
        val selectionArgs = arrayOf(currentItem.id.toString())
        // Issue SQL statement.
        val deleteResult = db.delete(TABLE_NAME, selection, selectionArgs)

        return deleteResult == 0
    }

    override fun selectAll(): ArrayList<UserModel> {
        val users = ArrayList<UserModel>()
        var cursor: Cursor? = null
        try {
            cursor = db.rawQuery("select * from $TABLE_NAME", null)

            if (cursor.moveToFirst()) {
                val iId = cursor.getColumnIndex(COLUMN_ID)
                val iName = cursor.getColumnIndex(COLUMN_NICK_NAME)
                val iDateCreated = cursor.getColumnIndex(COLUMN_DATE_CREATED)
                val iDateUpdated = cursor.getColumnIndex(COLUMN_DATE_UPDATED)

                while (!cursor.isAfterLast) {
                    val id = cursor.getInt(iId)
                    val name = cursor.getString(iName)
                    val dateCreated = cursor.getString(iDateCreated)
                    val dateUpdated = cursor.getString(iDateUpdated)

                    val user = UserModel()
                    user.db = db
                    user.currentItem.nickName = name
                    user.currentItem.id = id
                    user.currentItem.dateCreated = dateCreated
                    user.currentItem.dateUpdated = dateUpdated

                    users.add(user)
                    cursor.moveToNext()
                }
            }
        } catch (e: SQLiteException) {

            cursor?.close()
            println(e.message)
            return ArrayList()
        }

        return users
    }

}