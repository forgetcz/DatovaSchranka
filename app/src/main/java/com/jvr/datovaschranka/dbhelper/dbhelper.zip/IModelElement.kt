package com.jvr.datovaschranka.dbhelper

import android.database.sqlite.SQLiteDatabase
import java.util.ArrayList

interface IModelElement<T> {
    fun onCreateElement(db: SQLiteDatabase)
    fun onUpgradeElement(db: SQLiteDatabase, oldVersion: Int, newVersion: Int)
    fun setDatabase(db: SQLiteDatabase)

    fun getTableName() : String
    fun getCreateModel() : String

    fun select(): Boolean
    fun insert(): Boolean
    fun update() : Boolean
    fun delete(): Boolean
    fun selectAll() : ArrayList<T>
    fun deleteAll()
}