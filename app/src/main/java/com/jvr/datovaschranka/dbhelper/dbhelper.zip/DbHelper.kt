package com.jvr.datovaschranka.dbhelper

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteDatabase.*
import android.database.sqlite.SQLiteOpenHelper
import com.jvr.common.lib.logger.BasicLogger
import com.jvr.common.lib.logger.ComplexLogger
import com.jvr.common.lib.logger.HistoryLogger

/**
 * https://www.geeksforgeeks.org/android-sqlite-database-in-kotlin/
 */
class DbHelper(context: Context, factory: CursorFactory?) :
    SQLiteOpenHelper(context, DATABASE_NAME, factory, DATABASE_VERSION) {
    //: SQLiteOpenHelper(context, DATABASE_NAME, factory, DATABASE_VERSION) {
    private fun getTag(): String {
        return javaClass.name
    }

    private val userModel = UserModel()
    private val timeModel = TimeModel()
    private val namePasswordModel = NamePasswordModel()

    private val modelElements: List<ModelElement<*>> =
        listOf(userModel, timeModel, namePasswordModel)

    val getUserModel: UserModel
        get() {
            return userModel
        }

    val getNamePasswordModel: NamePasswordModel
        get() {
            return namePasswordModel
        }

    val getTimeMode: TimeModel
        get() {
            return timeModel
        }

    private val logger: ComplexLogger = ComplexLogger(
        listOf(
            BasicLogger(), HistoryLogger()
        )
    )

    init {
        modelElements.forEach { fe -> fe.setDatabase(writableDatabase) }
    }

    override fun onCreate(db: SQLiteDatabase) {

        modelElements.forEach { fe -> fe.onCreateElement(db) }
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // This database is only a cache for online data, so its upgrade policy is
        // to simply to discard the data and start over
        //db.execSQL("DROP TABLE IF EXISTS " + NamePasswordModel.TABLE_NAME)
        modelElements.forEach { fe -> fe.onUpgradeElement(db, oldVersion, newVersion) }

        logger.i(getTag(), "onUpgrade:old:$oldVersion,new:$newVersion")
    }

    override fun onDowngrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        onUpgrade(db, oldVersion, newVersion)
    }

    companion object {
        // If you change the database schema, you must increment the database version.
        const val DATABASE_VERSION = 2
        const val DATABASE_NAME = "FeedReader.db"
    }


}