package com.jvr.datovaschranka.dbhelper

import android.database.sqlite.SQLiteDatabase
import com.jvr.common.lib.logger.BasicLogger
import com.jvr.common.lib.logger.ComplexLogger
import com.jvr.common.lib.logger.HistoryLogger
import java.text.SimpleDateFormat
import java.util.*

abstract class ModelElement<T> : IModelElement<T> {
    protected lateinit var db: SQLiteDatabase

    protected fun getTag(): String {
        return javaClass.name
    }

    protected val logger: ComplexLogger = ComplexLogger(
        listOf(
            BasicLogger(), HistoryLogger()
        )
    )

    override fun onCreateElement(db: SQLiteDatabase) {
        try {
            db.execSQL(getCreateModel())
            //val s1 = this::onCreateElement.name
            //val s2 = ::onCreateElement.name
            //val s3 = (object{}.javaClass.enclosingMethod?.name ?: "")
            //val s4 = Thread.currentThread().stackTrace[1].methodName
            //logger.d("${getTag()}:${::onCreateElement.name}", "${::onCreateElement.name}- OK")
        } catch (error : Exception){
            logger.e("${getTag()}:${::onCreateElement.name}", error)
        }
    }

    override fun onUpgradeElement(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        try {
            db.execSQL("DROP TABLE IF EXISTS ${getTableName()}")
            onCreateElement(db)
            //val s1 = this::onUpgradeElement.name
            //val s2 = ::onUpgradeElement.name
            //val s3 = (object{}.javaClass.enclosingMethod?.name ?: "")
            //val s4 = Thread.currentThread().stackTrace[1].methodName
            //logger.d(getTag(), "${::onUpgradeElement.name}- OK")
        } catch (error : Exception) {
            logger.e("${getTag()}:${::onUpgradeElement.name}", error)
        }
    }

    override fun setDatabase(db: SQLiteDatabase) {
        this.db = db
    }

    override fun deleteAll() {
        try {
            db.execSQL("DELETE FROM ${getTableName()}")
        } catch (error: Exception) {
            logger.e("${getTag()}:${::deleteAll.name}", error)
        }
    }
}